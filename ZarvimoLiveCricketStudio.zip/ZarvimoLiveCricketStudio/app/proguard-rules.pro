# Debug builds do not use minification. If you enable minifyEnabled for release,
# keep RootEncoder classes that are instantiated reflectively:
-keep class com.pedro.** { *; }
