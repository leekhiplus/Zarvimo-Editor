package com.zarvimo.cricket.scoring

/** Result of the coin toss as announced before the match. */
enum class TossDecision(val label: String) {
    NONE("Not decided"),
    BAT("Bat first"),
    BOWL("Bowl first")
}

data class MatchSetup(
    val teamA: String = "Team A",
    val teamB: String = "Team B",
    val title: String = "",
    val venue: String = "",
    val oversLimit: Int = 20,
    val ballsPerOver: Int = 6,
    val playersPerSide: Int = 11,
    val widePenalty: Int = 1,
    val noBallPenalty: Int = 1,
    val enforceFreeHit: Boolean = true,
    val allowConsecutiveOvers: Boolean = false,
    val maxOversPerBowler: Int? = null,
    /** Team that won the toss (must equal teamA or teamB); blank = not announced. */
    val tossWinner: String = "",
    val tossDecision: TossDecision = TossDecision.NONE,
    /** Free text shown on the pre-match card, e.g. "3:30 PM". */
    val startTime: String = ""
) {
    val maxWickets: Int get() = (playersPerSide - 1).coerceAtLeast(1)

    /** Team that bats first according to the toss, or null when the toss is not (fully) entered. */
    val battingFirstTeam: String?
        get() {
            val w = tossWinner.trim()
            if (w.isEmpty() || tossDecision == TossDecision.NONE) return null
            val other = if (w.equals(teamA.trim(), true)) teamB.trim() else teamA.trim()
            return if (tossDecision == TossDecision.BAT) w else other
        }

    /** Two lines for the pre-match graphic (null when there is nothing to announce). */
    fun preMatchLines(): Pair<String?, String?> {
        val w = tossWinner.trim()
        val first = if (w.isNotEmpty() && tossDecision != TossDecision.NONE) {
            "TOSS: ${w.uppercase()} WON AND CHOSE TO ${if (tossDecision == TossDecision.BAT) "BAT" else "BOWL"} FIRST"
        } else if (w.isNotEmpty()) {
            "TOSS: ${w.uppercase()} WON THE TOSS"
        } else null
        val parts = ArrayList<String>()
        battingFirstTeam?.let { parts += "${it.uppercase()} BAT FIRST" }
        if (startTime.isNotBlank()) parts += "MATCH STARTS ${startTime.trim().uppercase()}"
        val second = if (parts.isEmpty()) null else parts.joinToString("   \u2022   ")
        return Pair(first, second)
    }

    fun validate(): String? = when {
        teamA.isBlank() || teamB.isBlank() -> "Both team names are required"
        teamA.trim().equals(teamB.trim(), ignoreCase = true) -> "Team names must be different"
        oversLimit !in 1..100 -> "Overs must be between 1 and 100"
        ballsPerOver !in 1..10 -> "Balls per over must be between 1 and 10"
        playersPerSide !in 2..15 -> "Players per side must be between 2 and 15"
        else -> null
    }

    fun innings(target: Int?) = InningsConfig(
        oversLimit = oversLimit,
        ballsPerOver = ballsPerOver,
        maxWickets = maxWickets,
        widePenalty = widePenalty,
        noBallPenalty = noBallPenalty,
        enforceFreeHit = enforceFreeHit,
        allowConsecutiveOvers = allowConsecutiveOvers,
        maxOversPerBowler = maxOversPerBowler,
        target = target
    )
}

/** One innings: its setup plus the ordered event list and a redo stack. */
class InningsData(
    val setup: InningsSetup,
    var targetOverride: Int? = null,
    val events: MutableList<ScoreEvent> = mutableListOf(),
    val redoStack: ArrayDeque<ScoreEvent> = ArrayDeque()
)

/**
 * Holds the whole match. Every mutation is validated by replaying the candidate event list; if the
 * candidate is invalid the original list is left untouched, so the scorecard can never be corrupted.
 */
class MatchSession(val setup: MatchSetup) {

    val innings: MutableList<InningsData> = mutableListOf()
    private var nextId = 1L

    val currentIndex: Int get() = innings.lastIndex
    val current: InningsData? get() = innings.lastOrNull()

    fun newId(): Long = nextId++

    /** Re-seeds the id counter after loading a saved match. */
    fun restoreIds() {
        nextId = (innings.flatMap { it.events }.maxOfOrNull { it.id } ?: 0L) + 1L
    }

    fun targetFor(index: Int): Int? {
        if (index <= 0) return null
        val data = innings.getOrNull(index) ?: return null
        data.targetOverride?.let { return it }
        val first = stateOf(index - 1) ?: return null
        return first.runs + 1
    }

    /** Derived state of an innings, or null if the index is invalid / replay fails. */
    fun stateOf(index: Int): InningsState? {
        val data = innings.getOrNull(index) ?: return null
        val target = if (index == 0) null else (data.targetOverride ?: stateOfFirstRuns(index))
        return when (val r = ScoreEngine.replay(setup.innings(target), data.setup, data.events)) {
            is ReplayResult.Ok -> r.state
            is ReplayResult.Failed -> null
        }
    }

    private fun stateOfFirstRuns(index: Int): Int? {
        val prev = innings.getOrNull(index - 1) ?: return null
        val prevTarget = if (index - 1 == 0) null else (prev.targetOverride)
        val r = ScoreEngine.replay(setup.innings(prevTarget), prev.setup, prev.events)
        return (r as? ReplayResult.Ok)?.state?.runs?.plus(1)
    }

    val currentState: InningsState? get() = if (innings.isEmpty()) null else stateOf(currentIndex)

    fun startInnings(inningsSetup: InningsSetup, targetOverride: Int? = null): OpResult {
        ScoreEngine.validateSetup(inningsSetup)?.let { return OpResult.Error(it) }
        if (innings.size >= 2) return OpResult.Error("Both innings have already been created")
        if (innings.isNotEmpty()) {
            val prev = stateOf(innings.lastIndex)
            if (prev == null || !prev.ended) return OpResult.Error("End the first innings before starting the second")
        }
        innings.add(InningsData(inningsSetup, targetOverride))
        val st = stateOf(currentIndex) ?: return OpResult.Error("Could not build innings")
        return OpResult.Ok(st)
    }

    /** Adds an event built with a fresh id. */
    fun add(factory: (Long) -> ScoreEvent): OpResult {
        val data = current ?: return OpResult.Error("No innings in progress")
        val event = factory(newId())
        val candidate = data.events + event
        return when (val r = replayCandidate(currentIndex, candidate)) {
            is ReplayResult.Ok -> {
                data.events.add(event)
                data.redoStack.clear()
                OpResult.Ok(r.state)
            }
            is ReplayResult.Failed -> OpResult.Error(r.reason)
        }
    }

    fun undo(): OpResult {
        val data = current ?: return OpResult.Error("No innings in progress")
        if (data.events.isEmpty()) return OpResult.Error("Nothing to undo")
        val removed = data.events.removeAt(data.events.lastIndex)
        data.redoStack.addLast(removed)
        return stateResult()
    }

    fun redo(): OpResult {
        val data = current ?: return OpResult.Error("No innings in progress")
        val event = data.redoStack.lastOrNull() ?: return OpResult.Error("Nothing to redo")
        val candidate = data.events + event
        return when (val r = replayCandidate(currentIndex, candidate)) {
            is ReplayResult.Ok -> {
                data.redoStack.removeLast()
                data.events.add(event)
                OpResult.Ok(r.state)
            }
            is ReplayResult.Failed -> OpResult.Error(r.reason)
        }
    }

    /** Replace an earlier event (e.g. correct 1 -> 2 runs). Rejected if later events become invalid. */
    fun replaceEvent(eventId: Long, replacement: (Long) -> ScoreEvent): OpResult {
        val data = current ?: return OpResult.Error("No innings in progress")
        val idx = data.events.indexOfFirst { it.id == eventId }
        if (idx < 0) return OpResult.Error("Event not found")
        val candidate = data.events.toMutableList()
        candidate[idx] = replacement(eventId)
        return when (val r = replayCandidate(currentIndex, candidate)) {
            is ReplayResult.Ok -> {
                data.events[idx] = candidate[idx]
                data.redoStack.clear()
                OpResult.Ok(r.state)
            }
            is ReplayResult.Failed -> OpResult.Error("Edit rejected: ${r.reason}")
        }
    }

    fun deleteEvent(eventId: Long): OpResult {
        val data = current ?: return OpResult.Error("No innings in progress")
        val idx = data.events.indexOfFirst { it.id == eventId }
        if (idx < 0) return OpResult.Error("Event not found")
        val candidate = data.events.toMutableList()
        candidate.removeAt(idx)
        return when (val r = replayCandidate(currentIndex, candidate)) {
            is ReplayResult.Ok -> {
                data.events.removeAt(idx)
                data.redoStack.clear()
                OpResult.Ok(r.state)
            }
            is ReplayResult.Failed -> OpResult.Error("Delete rejected: ${r.reason}")
        }
    }

    fun setTargetOverride(index: Int, target: Int?): OpResult {
        val data = innings.getOrNull(index) ?: return OpResult.Error("Innings not found")
        if (index == 0) return OpResult.Error("The first innings has no target")
        if (target != null && target < 1) return OpResult.Error("Target must be at least 1")
        val old = data.targetOverride
        data.targetOverride = target
        val st = stateOf(index)
        if (st == null) {
            data.targetOverride = old
            return OpResult.Error("Target would invalidate the recorded events")
        }
        return OpResult.Ok(st)
    }

    private fun stateResult(): OpResult {
        val st = currentState ?: return OpResult.Error("State could not be rebuilt")
        return OpResult.Ok(st)
    }

    private fun replayCandidate(index: Int, events: List<ScoreEvent>): ReplayResult {
        val data = innings[index]
        val target = if (index == 0) null else (data.targetOverride ?: stateOfFirstRuns(index))
        return ScoreEngine.replay(setup.innings(target), data.setup, events)
    }
}
