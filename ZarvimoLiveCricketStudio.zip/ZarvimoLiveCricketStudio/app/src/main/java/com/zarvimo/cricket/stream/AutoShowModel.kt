package com.zarvimo.cricket.stream

import com.zarvimo.cricket.scoring.DismissalType
import kotlin.random.Random

/** Automatic on-air extras that react to the scoring (no operator action needed). */
data class AutoShowSettings(
    /** Full-screen FOUR / SIX / WICKET animation when the scorer records one. */
    val burstAnimations: Boolean = true,
    /** Spoken commentary (text-to-speech) for four / six / wicket. */
    val voiceEnabled: Boolean = false,
    /** Use Urdu lines (needs an Urdu voice installed in the phone's text-to-speech settings). */
    val voiceUrdu: Boolean = false,
    val voiceVolume: Float = 1f,
    val onFour: Boolean = true,
    val onSix: Boolean = true,
    val onWicket: Boolean = true,
    /** How long scorecard / player / partnership / graph panels stay on air before hiding themselves. */
    val panelSeconds: Int = 12
) {
    fun sanitized(): AutoShowSettings = copy(voiceVolume = voiceVolume.coerceIn(0f, 1.5f), panelSeconds = panelSeconds.coerceIn(4, 60))
}

enum class CommentaryEvent { FOUR, SIX, WICKET }

/** Builds the spoken line. Pure Kotlin so it can be unit-tested. */
object CommentaryLines {

    private val englishFour = listOf(
        "FOUR! %s finds the gap.",
        "That's a boundary. Four runs for %s.",
        "Beautiful shot from %s, and it races away for four."
    )
    private val englishSix = listOf(
        "SIX! %s sends it into the stands.",
        "Massive hit from %s. That is a six.",
        "Maximum! %s clears the rope."
    )
    private val urduFour = listOf(
        "چوکا! %s کا شاندار شاٹ۔",
        "باؤنڈری! %s نے چار رن بنا لیے۔"
    )
    private val urduSix = listOf(
        "چھکا! %s نے گیند کو سٹیڈیم سے باہر پہنچا دیا۔",
        "زبردست چھکا! %s کی کمال بیٹنگ۔"
    )

    fun dismissalEnglish(t: DismissalType?): String = when (t) {
        DismissalType.BOWLED -> "bowled"
        DismissalType.CAUGHT -> "caught"
        DismissalType.LBW -> "out, leg before wicket"
        DismissalType.STUMPED -> "stumped"
        DismissalType.HIT_WICKET -> "out, hit wicket"
        DismissalType.RUN_OUT -> "run out"
        DismissalType.OBSTRUCTING_FIELD -> "out, obstructing the field"
        DismissalType.HIT_BALL_TWICE -> "out, hit the ball twice"
        null -> "out"
    }

    fun dismissalUrdu(t: DismissalType?): String = when (t) {
        DismissalType.BOWLED -> "بولڈ"
        DismissalType.CAUGHT -> "کیچ آؤٹ"
        DismissalType.LBW -> "ایل بی ڈبلیو"
        DismissalType.STUMPED -> "اسٹمپ آؤٹ"
        DismissalType.HIT_WICKET -> "ہٹ وکٹ"
        DismissalType.RUN_OUT -> "رن آؤٹ"
        DismissalType.OBSTRUCTING_FIELD -> "فیلڈنگ میں رکاوٹ"
        DismissalType.HIT_BALL_TWICE -> "گیند دو بار ہٹ"
        null -> "آؤٹ"
    }

    /**
     * @param player  batter who scored the boundary / was dismissed
     * @param bowler  bowler (used for wickets)
     */
    fun line(
        event: CommentaryEvent,
        player: String,
        bowler: String?,
        dismissal: DismissalType?,
        urdu: Boolean,
        random: Random = Random.Default
    ): String {
        val name = player.ifBlank { if (urdu) "بلے باز" else "the batter" }
        return when (event) {
            CommentaryEvent.FOUR -> (if (urdu) urduFour else englishFour).random(random).format(name)
            CommentaryEvent.SIX -> (if (urdu) urduSix else englishSix).random(random).format(name)
            CommentaryEvent.WICKET -> {
                if (urdu) {
                    "آؤٹ! $name، ${dismissalUrdu(dismissal)}" + (if (!bowler.isNullOrBlank() && dismissal?.creditsBowler == true) "، بولر $bowler" else "") + "۔"
                } else {
                    "OUT! $name is ${dismissalEnglish(dismissal)}" + (if (!bowler.isNullOrBlank() && dismissal?.creditsBowler == true) ", bowler $bowler" else "") + "."
                }
            }
        }
    }
}
