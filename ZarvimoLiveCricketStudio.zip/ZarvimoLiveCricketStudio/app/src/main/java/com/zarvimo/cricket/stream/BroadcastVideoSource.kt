package com.zarvimo.cricket.stream

import android.content.Context
import android.graphics.Canvas
import android.graphics.SurfaceTexture
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.Surface
import com.pedro.encoder.input.sources.video.VideoSource
import com.zarvimo.cricket.graphics.BroadcastRenderer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * RootEncoder video source that feeds the app's own compositor into the library's GL pipeline.
 *
 * Frame pump: a dedicated thread produces frames at the configured fps into the Surface backed by the SurfaceTexture
 * RootEncoder hands us. RootEncoder's GL interface then fans those exact frames out to (a) the MediaCodec H.264 encoder
 * and (b) the on-screen preview SurfaceView. There is no second render path.
 *
 * Interchangeable backends (the user can switch live, preview and stream follow):
 *  - BACKGROUND: [BroadcastRenderer] draws background picture + graphics with a Canvas.
 *  - CAMERA_BACK / CAMERA_FRONT: [CameraGlCompositor] draws the camera with OpenGL and the same graphics on top.
 *  - BACKGROUND + camera bubble: the same OpenGL compositor draws the background picture, the camera inside a circle, then the graphics.
 * If the camera cannot be used the source falls back to the plain background picture and tells the caller why.
 *
 * RootEncoder-specific API usage is confined to this class and [StreamEngine].
 */
class BroadcastVideoSource(
    private val context: Context,
    private val broadcast: BroadcastState,
    private val onCompositorFps: (Int) -> Unit,
    private val onFatalError: (String) -> Unit,
    private val onModeFallback: (VideoSourceMode, String) -> Unit
) : VideoSource() {

    private var outW = 0
    private var outH = 0
    // Named pumpFps (not fps): RootEncoder 2.8.x VideoSource already declares a member called fps.
    private var pumpFps = 24

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var outTexture: SurfaceTexture? = null
    private var surface: Surface? = null
    private var gl: CameraGlCompositor? = null
    private var activeBackend: Backend? = null
    private val renderer = BroadcastRenderer()

    /** Which drawing path is in use: 0 = canvas (background picture), 1 = full-frame camera, 2 = background picture + camera bubble. */
    private data class Backend(val kind: Int, val front: Boolean)

    @Volatile private var desiredMode = VideoSourceMode.BACKGROUND
    @Volatile private var bubble = BubbleConfig.OFF
    @Volatile private var rotationOffset = 0
    @Volatile private var pendingProblem: String? = null

    @Volatile private var running = false
    private var nextFrameAt = 0L
    private var framesThisSecond = 0
    private var secondStart = 0L
    private var consecutiveErrors = 0

    /** Thread-safe; takes effect on the next frame (live switching). */
    fun setMode(mode: VideoSourceMode) {
        desiredMode = mode
    }

    /** Live: position / size changes apply on the next frame; switching the bubble on/off or front/back swaps the drawing path. */
    fun setBubble(b: BubbleConfig) {
        bubble = b
        gl?.bubble = b
    }

    private fun wantedBackend(): Backend {
        val m = desiredMode
        val b = bubble
        return when {
            m.isCamera -> Backend(1, m == VideoSourceMode.CAMERA_FRONT)
            b.enabled -> Backend(2, b.front)
            else -> Backend(0, false)
        }
    }

    fun setRotationOffset(degrees: Int) {
        rotationOffset = degrees
        gl?.rotationOffset = degrees
    }

    override fun create(width: Int, height: Int, fps: Int, rotation: Int): Boolean {
        outW = width
        outH = height
        this.pumpFps = fps.coerceIn(5, 60)
        return true
    }

    override fun start(surfaceTexture: SurfaceTexture) {
        if (running) return
        surfaceTexture.setDefaultBufferSize(outW, outH)
        outTexture = surfaceTexture
        val t = HandlerThread("BroadcastFramePump").also { it.start() }
        thread = t
        handler = Handler(t.looper)
        running = true
        consecutiveErrors = 0
        nextFrameAt = SystemClock.uptimeMillis()
        secondStart = nextFrameAt
        framesThisSecond = 0
        handler?.post(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            ensureBackend()
            drawFrame()
            val interval = 1000L / pumpFps
            nextFrameAt += interval
            val now = SystemClock.uptimeMillis()
            if (nextFrameAt < now - 2 * interval) nextFrameAt = now // fell behind: skip, never queue frames up
            handler?.postDelayed(this, max(0L, nextFrameAt - now))
        }
    }

    // ------------------------------------------------------------------------------------------ backends

    /** Runs on the pump thread before every frame: switches backend when the wanted one changed or the camera failed. */
    private fun ensureBackend() {
        val problem = pendingProblem
        if (problem != null) {
            pendingProblem = null
            if ((activeBackend?.kind ?: 0) != 0) {
                fallbackToBackground(problem)
                return
            }
        }
        val want = wantedBackend()
        if (activeBackend == want) return
        val st = outTexture ?: return
        teardownBackend()
        if (want.kind != 0) {
            val h = handler ?: return
            try {
                val s = Surface(st)
                surface = s
                val g = CameraGlCompositor(context, h) { msg -> pendingProblem = msg }
                g.rotationOffset = rotationOffset
                g.bubble = bubble
                g.start(s, outW, outH, pumpFps, want.front, bubbleMode = want.kind == 2)
                gl = g
                activeBackend = want
            } catch (e: Throwable) {
                fallbackToBackground("Camera could not start (${e.javaClass.simpleName}). Using the plain background picture instead.")
            }
        } else {
            surface = Surface(st)
            activeBackend = want
        }
    }

    private fun fallbackToBackground(message: String) {
        teardownBackend()
        desiredMode = VideoSourceMode.BACKGROUND
        bubble = BubbleConfig.OFF
        onModeFallback(VideoSourceMode.BACKGROUND, message)
        val st = outTexture ?: return
        surface = Surface(st)
        activeBackend = Backend(0, false)
    }

    private fun teardownBackend() {
        try {
            gl?.release()
        } catch (_: Exception) {
        }
        gl = null
        try {
            surface?.release()
        } catch (_: Exception) {
        }
        surface = null
        activeBackend = null
    }

    // ------------------------------------------------------------------------------------------ frames

    private fun drawFrame() {
        val backend = activeBackend ?: return
        val snap = broadcast.snapshot()
        if (backend.kind != 0) drawCameraFrame(snap, backend.kind == 2) else drawCanvasFrame(snap)
        val now = SystemClock.uptimeMillis()
        if (now - secondStart >= 1000) {
            onCompositorFps(framesThisSecond)
            framesThisSecond = 0
            secondStart = now
        }
    }

    private fun drawCameraFrame(snap: BroadcastState.Snapshot, bubbleMode: Boolean) {
        val g = gl ?: return
        try {
            val assets = broadcast.assets
            val base: ((Canvas) -> Unit)? = if (bubbleMode) {
                { canvas -> renderer.renderBackground(canvas, outW, outH, assets) }
            } else {
                null
            }
            g.drawFrame(assets.background, base) { canvas ->
                renderer.render(canvas, outW, outH, snap.overlay, snap.config, assets, SystemClock.uptimeMillis(), withBackground = false)
            }
            consecutiveErrors = 0
            framesThisSecond++
        } catch (e: Throwable) {
            consecutiveErrors++
            if (consecutiveErrors >= 10) {
                consecutiveErrors = 0
                fallbackToBackground("Camera rendering failed (${e.javaClass.simpleName}). Using the plain background picture instead.")
            }
        }
    }

    private fun drawCanvasFrame(snap: BroadcastState.Snapshot) {
        val s = surface ?: return
        if (!s.isValid) return
        var canvas: Canvas? = null
        try {
            canvas = try {
                s.lockHardwareCanvas()
            } catch (e: Exception) {
                s.lockCanvas(null)
            }
            renderer.render(canvas, outW, outH, snap.overlay, snap.config, broadcast.assets, SystemClock.uptimeMillis(), withBackground = true)
            consecutiveErrors = 0
            framesThisSecond++
        } catch (e: Exception) {
            consecutiveErrors++
            if (consecutiveErrors >= 20) {
                running = false
                onFatalError("Compositor stopped: ${e.javaClass.simpleName}")
            }
        } finally {
            if (canvas != null) {
                try {
                    s.unlockCanvasAndPost(canvas)
                } catch (e: Exception) {
                    consecutiveErrors++
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------ lifecycle

    override fun stop() {
        running = false
        val h = handler
        val t = thread
        if (h != null && t != null) {
            h.removeCallbacksAndMessages(null)
            // GL and camera objects must be released on the thread that owns the EGL context.
            val done = CountDownLatch(1)
            h.post {
                try {
                    teardownBackend()
                } finally {
                    done.countDown()
                }
            }
            try {
                done.await(1500, TimeUnit.MILLISECONDS)
            } catch (_: InterruptedException) {
            }
            t.quitSafely()
            try {
                t.join(500)
            } catch (_: InterruptedException) {
            }
        }
        thread = null
        handler = null
        outTexture = null
        onCompositorFps(0)
    }

    override fun release() {
        stop()
        renderer.release()
    }

    override fun isRunning(): Boolean = running
}
