package com.zarvimo.cricket.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.cricket.graphics.BroadcastLayout
import com.zarvimo.cricket.graphics.FontChoice
import com.zarvimo.cricket.graphics.Ref
import com.zarvimo.cricket.graphics.SafeArea
import com.zarvimo.cricket.graphics.ScoreboardTemplate
import com.zarvimo.cricket.stream.DurationFormat
import com.zarvimo.cricket.stream.ResolutionProfile
import com.zarvimo.cricket.stream.StatusLabels
import com.zarvimo.cricket.stream.StreamOptions
import com.zarvimo.cricket.stream.StreamState
import kotlinx.coroutines.delay
import java.util.Locale

private fun isActive(s: StreamState) = s != StreamState.IDLE && s != StreamState.ERROR
private fun f2(v: Float) = String.format(Locale.ROOT, "%.2f", v)

// ================================================================================================ D. PROGRAM PREVIEW

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 13.sp)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Gold)
    }
}

@Composable
fun LiveControls(vm: AppViewModel, onStartLive: () -> Unit) {
    val ss by vm.streamStatus.collectAsState()
    val audio by vm.audioState.collectAsState()
    val problems by vm.liveProblems.collectAsState()
    val active = isActive(ss.state)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (problems.isNotEmpty()) {
            SectionCard("Cannot start yet") { problems.forEach { Text("• $it", color = Color(0xFFFF6B6B), fontSize = 13.sp) } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton(
                when (ss.state) {
                    StreamState.ERROR -> "RETRY LIVE"
                    StreamState.IDLE -> "GO LIVE"
                    StreamState.STOPPING -> "STOPPING…"
                    else -> "STOP LIVE"
                },
                Modifier.weight(2f).height(60.dp),
                if (active) Color(0xFF8E1B1B) else Crimson,
                enabled = ss.state != StreamState.STOPPING
            ) { if (active) vm.stopLive() else onStartLive() }
            BigButton(
                if (audio.userMuted) "MIC MUTED" else "MIC ON",
                Modifier.weight(1f).height(60.dp), if (audio.userMuted) Color(0xFF6C7A89) else Color(0xFF1B5E20)
            ) { vm.setMuted(!audio.userMuted) }
        }
        if (audio.autoMuted) Text("Microphone auto-muted: another app or a call is using audio. It resumes when audio focus returns.", fontSize = 12.sp, color = Color(0xFFFFB74D))
        if (audio.micPermissionLost) Text("Microphone permission was revoked.", fontSize = 12.sp, color = Color(0xFFFF6B6B))
        if (ss.state == StreamState.ERROR) ss.errorMessage?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp) }
    }
}

// ================================================================================================ E. GRAPHICS EDITOR

@Composable
fun GraphicsScreen(vm: AppViewModel) {
    val g by vm.graphics.collectAsState()
    val settings by vm.stream.collectAsState()
    val pickBg = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.importMedia(u, MediaKind.BACKGROUND) } }
    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.importMedia(u, MediaKind.LOGO) } }
    val pickSponsor = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.importMedia(u, MediaKind.SPONSOR) } }

    PinnedPreviewScreen(
        vm,
        hint = "Drag on the preview to move the scoreboard. Every change is rendered by the real compositor.",
        previewOverlay = {
            Box(
                Modifier.matchParentSize().pointerInput(Unit) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        val cur = vm.graphics.value
                        val outH = vm.stream.value.profile.height
                        val p = BroadcastLayout.scoreboard(cur, outH)
                        val safe = BroadcastLayout.safeBox(cur)
                        val bottom = if (cur.showTicker) safe.bottom - Ref.TICKER_H - Ref.TICKER_GAP else safe.bottom
                        val availX = (safe.width - 2 * cur.marginPx) - p.box.width
                        val availY = (bottom - safe.top - 2 * cur.marginPx) - p.box.height
                        val dxRef = drag.x / size.width * Ref.W
                        val dyRef = drag.y / size.height * Ref.H
                        vm.updateGraphics {
                            it.copy(
                                posX = if (availX > 1f) it.posX + dxRef / availX else it.posX,
                                posY = if (availY > 1f) it.posY + dyRef / availY else it.posY
                            )
                        }
                    }
                }
            )
        }
    ) {
        SectionCard("Scoreboard template") {
            ChipChoice(ScoreboardTemplate.values().toList(), g.template, { it.label }) { t ->
                vm.updateGraphics { it.copy(template = t, posX = t.defaultPosX, posY = t.defaultPosY) }
            }
            Text("Picking a template puts it at its best position; drag the preview or use the sliders below to move it.", fontSize = 11.sp)
        }
        SectionCard("Position, size & safe area") {
            LabeledSlider("X position", g.posX, 0f..1f, f2(g.posX)) { v -> vm.updateGraphics { it.copy(posX = v) } }
            LabeledSlider("Y position", g.posY, 0f..1f, f2(g.posY)) { v -> vm.updateGraphics { it.copy(posY = v) } }
            LabeledSlider("Size", g.scale, 0.5f..1.6f, f2(g.scale)) { v -> vm.updateGraphics { it.copy(scale = v) } }
            LabeledSlider("Margin inside safe area", g.marginPx, 0f..80f, "${g.marginPx.toInt()} px") { v -> vm.updateGraphics { it.copy(marginPx = v) } }
            val sa = g.safeArea
            LabeledSlider("Safe area (all sides)", (sa.left + sa.right + sa.top + sa.bottom) / 4f * 100f, 0f..15f, "${((sa.left + sa.right + sa.top + sa.bottom) / 4f * 100f).toInt()} %") { v ->
                vm.updateGraphics { it.copy(safeArea = SafeArea(v / 100f, v / 100f * 1.5f, v / 100f, v / 100f * 1.5f)) }
            }
            BigButton("Reset position", Modifier.fillMaxWidth()) { vm.updateGraphics { it.copy(posX = 0.5f, posY = 1f, scale = 1f, marginPx = 8f) } }
        }
        SectionCard("Colours, font & panel") {
            ColorPicker("Panel colour", g.primaryColor) { c -> vm.updateGraphics { it.copy(primaryColor = c) } }
            ColorPicker("Accent colour", g.accentColor) { c -> vm.updateGraphics { it.copy(accentColor = c) } }
            ColorPicker("Text colour", g.textColor) { c -> vm.updateGraphics { it.copy(textColor = c) } }
            ColorPicker("Border colour", g.borderColor) { c -> vm.updateGraphics { it.copy(borderColor = c) } }
            LabeledSlider("Panel opacity", g.panelOpacity, 0.2f..1f, "${(g.panelOpacity * 100).toInt()} %") { v -> vm.updateGraphics { it.copy(panelOpacity = v) } }
            LabeledSlider("Border width", g.borderWidthPx, 0f..10f, "${g.borderWidthPx.toInt()} px") { v -> vm.updateGraphics { it.copy(borderWidthPx = v) } }
            Text("Font", fontSize = 12.sp)
            ChipChoice(FontChoice.values().toList(), g.font, { it.label }) { f -> vm.updateGraphics { it.copy(font = f) } }
        }
        SectionCard("Elements") {
            SwitchRow("Match title / venue tag", g.showMatchTitle) { v -> vm.updateGraphics { it.copy(showMatchTitle = v) } }
            SwitchRow("Team logos", g.showTeamLogos) { v -> vm.updateGraphics { it.copy(showTeamLogos = v) } }
            SwitchRow("Ticker", g.showTicker) { v -> vm.updateGraphics { it.copy(showTicker = v) } }
            if (g.showTicker) TextInput("Ticker text (blank = automatic match summary)", g.tickerText, { t -> vm.updateGraphics { it.copy(tickerText = t) } })
            SwitchRow("Sponsor logo", g.showSponsor) { v -> vm.updateGraphics { it.copy(showSponsor = v) } }
        }
        SectionCard("Background, channel logo & sponsor") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Import background", Modifier.weight(1f)) { pickBg.launch("image/*") }
                if (g.backgroundUri != null) BigButton("Use default", Modifier.weight(1f), Color(0xFF5A2A2A)) { vm.clearMedia(MediaKind.BACKGROUND) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Import channel logo", Modifier.weight(1f)) { pickLogo.launch("image/*") }
                if (g.logoUri != null) BigButton("Remove", Modifier.weight(1f), Color(0xFF5A2A2A)) { vm.clearMedia(MediaKind.LOGO) }
            }
            if (g.logoUri != null) {
                LabeledSlider("Logo X", g.logoX, 0f..1f, f2(g.logoX)) { v -> vm.updateGraphics { it.copy(logoX = v) } }
                LabeledSlider("Logo Y", g.logoY, 0f..1f, f2(g.logoY)) { v -> vm.updateGraphics { it.copy(logoY = v) } }
                LabeledSlider("Logo size", g.logoScale, 0.3f..3f, f2(g.logoScale)) { v -> vm.updateGraphics { it.copy(logoScale = v) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Import sponsor logo", Modifier.weight(1f)) { pickSponsor.launch("image/*") }
                if (g.sponsorUri != null) BigButton("Remove", Modifier.weight(1f), Color(0xFF5A2A2A)) { vm.clearMedia(MediaKind.SPONSOR) }
            }
            if (g.sponsorUri != null) {
                LabeledSlider("Sponsor X", g.sponsorX, 0f..1f, f2(g.sponsorX)) { v -> vm.updateGraphics { it.copy(sponsorX = v) } }
                LabeledSlider("Sponsor Y", g.sponsorY, 0f..1f, f2(g.sponsorY)) { v -> vm.updateGraphics { it.copy(sponsorY = v) } }
                LabeledSlider("Sponsor size", g.sponsorScale, 0.3f..3f, f2(g.sponsorScale)) { v -> vm.updateGraphics { it.copy(sponsorScale = v) } }
            }
            Text("You are responsible for holding the rights to any image you import.", fontSize = 11.sp)
        }
        Text("Presets: use “Saved & Presets” on the Home screen.", fontSize = 12.sp)
    }
}

// ================================================================================================ F. STREAM CONFIGURATION

@Composable
fun StreamConfigScreen(vm: AppViewModel, onStartLive: () -> Unit) {
    val s by vm.stream.collectAsState()
    val keyRemembered by vm.rememberKey.collectAsState()
    val ss by vm.streamStatus.collectAsState()
    var showKey by remember { mutableStateOf(false) }
    val locked = isActive(ss.state)
    val secure = s.serverUrl.trim().lowercase().startsWith("rtmps://")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StatusStrip(vm)
        SectionCard("Destination") {
            Text("A valid ingest server URL and an ACTIVE stream key are both required. For YouTube: YouTube Studio → Go Live → Stream, then copy the Stream URL and Stream key.", fontSize = 12.sp)
            TextInput("Server URL (rtmp:// or rtmps://)", s.serverUrl, { v -> vm.updateStream { it.copy(serverUrl = v) } })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("YouTube RTMP", Modifier.weight(1f)) { vm.updateStream { it.copy(serverUrl = StreamOptions.YOUTUBE_RTMP) } }
                BigButton("YouTube RTMPS", Modifier.weight(1f)) { vm.updateStream { it.copy(serverUrl = StreamOptions.YOUTUBE_RTMPS) } }
            }
            Text(if (secure) "RTMPS: connection is encrypted (TLS)." else "RTMP: not encrypted. Use RTMPS where your provider supports it.", fontSize = 12.sp)
            TextInput("Stream key", s.streamKey, { v -> vm.updateStream { it.copy(streamKey = v) } }, secret = !showKey)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton(if (showKey) "Hide key" else "Show key", Modifier.weight(1f)) { showKey = !showKey }
                BigButton("Clear key", Modifier.weight(1f), Color(0xFF5A2A2A)) { vm.updateStream { it.copy(streamKey = "") }; vm.setRememberKey(false) }
            }
            SwitchRow("Remember key on this device (encrypted, off by default)", keyRemembered) { vm.setRememberKey(it) }
            Text("Never share the key or screenshot it. Anyone with the key can broadcast to your channel.", fontSize = 11.sp, color = Color(0xFFFFB74D))
        }
        SectionCard("Video") {
            if (locked) Text("Resolution and frame rate are locked while a session is active. Stop Live to change them.", fontSize = 12.sp, color = Color(0xFFFFB74D))
            Text("Resolution", fontSize = 12.sp)
            ChipChoice(ResolutionProfile.values().toList(), s.profile, { "${it.label} ${it.width}×${it.height}" }) { p ->
                if (!locked) vm.updateStream { it.copy(profile = p, videoBitrateKbps = p.defaultKbps) }
            }
            Text("Frame rate", fontSize = 12.sp)
            ChipChoice(StreamOptions.fpsOptions, s.fps, { "$it fps" }) { f -> if (!locked) vm.updateStream { it.copy(fps = f) } }
            LabeledSlider("Video bitrate", s.videoBitrateKbps.toFloat(), s.profile.minKbps.toFloat()..s.profile.maxKbps.toFloat(), "${s.videoBitrateKbps} kbps") { v ->
                val k = s.profile.clampBitrate(v.toInt())
                vm.updateStream { it.copy(videoBitrateKbps = k) }
                if (locked) vm.engineRef().setVideoBitrateOnFly(k)
            }
            Text("Starting points only (360p ≈ 400–800, 480p ≈ 700–1500, 720p ≈ 1500–3000 kbps). They do not guarantee a stable stream on a weak uplink: your upload speed must comfortably exceed video + audio bitrate.", fontSize = 11.sp)
            SwitchRow("Lower bitrate 25% automatically on each reconnect", s.lowerBitrateOnReconnect) { v -> vm.updateStream { it.copy(lowerBitrateOnReconnect = v) } }
            SwitchRow("Adaptive bitrate (lowers quality on a weak network, restores it when the network recovers)", s.adaptiveBitrate) { v -> vm.updateStream { it.copy(adaptiveBitrate = v) } }
            SwitchRow("Save a copy of the broadcast on this phone while live", s.recordLocally) { v -> vm.updateStream { it.copy(recordLocally = v) } }
            if (s.recordLocally) Text("Recordings are saved in Movies/Zarvimo (Android 10+) or in the app's Movies folder. Needs free storage: about 0.5 GB per hour at 480p and 1 GB at 720p.", fontSize = 11.sp)
        }
        SectionCard("Audio") {
            Text("Audio bitrate (AAC-LC, ${StreamOptions.AUDIO_SAMPLE_RATE} Hz)", fontSize = 12.sp)
            ChipChoice(StreamOptions.audioBitrateOptionsKbps, s.audioBitrateKbps, { "$it kbps" }) { a -> if (!locked) vm.updateStream { it.copy(audioBitrateKbps = a) } }
            SwitchRow("Stereo (phone microphones are usually mono)", s.stereo) { v -> if (!locked) vm.updateStream { it.copy(stereo = v) } }
        }
        LiveControls(vm, onStartLive)
    }
}

// ================================================================================================ G. LIVE STREAMING MONITOR

