package com.zarvimo.cricket.ui

import android.content.Context
import android.media.MediaCodecList
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.cricket.graphics.MatchVisuals
import com.zarvimo.cricket.graphics.OverlayBuilder
import com.zarvimo.cricket.scoring.InningsSetup
import com.zarvimo.cricket.scoring.MatchSetup
import com.zarvimo.cricket.scoring.TossDecision
import com.zarvimo.cricket.stream.ResolutionProfile
import java.text.DateFormat
import java.util.Date

// ================================================================================================ A. HOME

@Composable
fun HomeScreen(vm: AppViewModel, onNavigate: (String) -> Unit, onStartLive: () -> Unit) {
    val m by vm.match.collectAsState()
    val st = m.state
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StatusStrip(vm)
        Text("Zarvimo Live Cricket Studio", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Gold)
        SectionCard("Match dashboard") {
            Text("${m.setup.teamA}  vs  ${m.setup.teamB}", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            if (m.setup.title.isNotBlank() || m.setup.venue.isNotBlank()) Text(listOf(m.setup.title, m.setup.venue).filter { it.isNotBlank() }.joinToString(" • "), fontSize = 13.sp)
            if (st != null) {
                Text("${st.battingTeam}  ${st.scoreText}  (${st.oversText}/${st.oversLimit} ov)", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                st.target?.let { Text("Target $it • need ${st.requiredRuns ?: 0} from ${st.ballsRemaining} balls") }
                if (st.ended) Text("Innings ended: ${st.endReason}", color = Gold)
            } else {
                Text("No innings in progress. Open Match Setup to start.", fontSize = 14.sp)
            }
            m.firstInningsText?.let { Text("1st innings: $it", fontSize = 13.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton("Match Setup", Modifier.weight(1f).height(56.dp)) { onNavigate("setup") }
            BigButton("Score Console", Modifier.weight(1f).height(56.dp), Gold, Color.Black) { onNavigate("score") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton("🎛 Studio\n(camera, music, graphics)", Modifier.weight(1f).height(64.dp)) { onNavigate("preview") }
            BigButton("💬 Viewers & comments", Modifier.weight(1f).height(64.dp)) { onNavigate("chat") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton("🎨 Scoreboard design", Modifier.weight(1f).height(56.dp)) { onNavigate("graphics") }
            BigButton("📡 Stream settings", Modifier.weight(1f).height(56.dp)) { onNavigate("stream") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton("📈 Live status", Modifier.weight(1f).height(56.dp)) { onNavigate("monitor") }
            BigButton("💾 Saved & presets", Modifier.weight(1f).height(56.dp)) { onNavigate("saved") }
        }
        BigButton("⚙ Settings & diagnostics", Modifier.fillMaxWidth().height(52.dp)) { onNavigate("settings") }
        val ss by vm.streamStatus.collectAsState()
        val active = ss.state != com.zarvimo.cricket.stream.StreamState.IDLE && ss.state != com.zarvimo.cricket.stream.StreamState.ERROR
        BigButton(if (active) "STOP LIVE" else "GO LIVE", Modifier.fillMaxWidth().height(64.dp), if (active) Color(0xFF8E1B1B) else Crimson) {
            if (active) vm.stopLive() else onStartLive()
        }
        SectionCard("Important") {
            Text("Preview ≠ streaming. The PREVIEW chip only means the on-device compositor is rendering. The stream chip turns LIVE STREAMING only after the server accepts the connection.", fontSize = 12.sp)
            Text("Live streaming needs a reliable mobile uplink. Lower profiles use less bandwidth but nothing here guarantees an uninterrupted stream.", fontSize = 12.sp)
        }
    }
}

// ================================================================================================ B. MATCH SETUP

@Composable
fun SetupScreen(vm: AppViewModel, onNavigate: (String) -> Unit) {
    val m by vm.match.collectAsState()
    val st = m.state
    var teamA by remember(m.matchId, m.setup) { mutableStateOf(m.setup.teamA) }
    var teamB by remember(m.matchId, m.setup) { mutableStateOf(m.setup.teamB) }
    var title by remember(m.matchId, m.setup) { mutableStateOf(m.setup.title) }
    var venue by remember(m.matchId, m.setup) { mutableStateOf(m.setup.venue) }
    var overs by remember(m.matchId, m.setup) { mutableStateOf(m.setup.oversLimit.toString()) }
    var players by remember(m.matchId, m.setup) { mutableStateOf(m.setup.playersPerSide.toString()) }
    var freeHit by remember(m.matchId, m.setup) { mutableStateOf(m.setup.enforceFreeHit) }
    var tossWinner by remember(m.matchId, m.setup) { mutableStateOf(m.setup.tossWinner) }
    var tossDecision by remember(m.matchId, m.setup) { mutableStateOf(m.setup.tossDecision) }
    var startTime by remember(m.matchId, m.setup) { mutableStateOf(m.setup.startTime) }
    var colorA by remember(m.matchId) { mutableStateOf(m.visuals.teamAColor) }
    var colorB by remember(m.matchId) { mutableStateOf(m.visuals.teamBColor) }
    var confirmReset by remember { mutableStateOf(false) }
    var saveName by remember { mutableStateOf("") }

    val pickA = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.importMedia(u, MediaKind.TEAM_A) } }
    val pickB = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.importMedia(u, MediaKind.TEAM_B) } }

    fun currentSetup() = m.setup.copy(
        teamA = teamA.trim(), teamB = teamB.trim(), title = title.trim(), venue = venue.trim(),
        oversLimit = overs.toIntOrNull() ?: 0, playersPerSide = players.toIntOrNull() ?: 0, enforceFreeHit = freeHit,
        tossWinner = tossWinner.trim(), tossDecision = tossDecision, startTime = startTime.trim()
    )
    fun currentVisuals() = MatchVisuals(colorA, colorB, m.visuals.teamAShort, m.visuals.teamBShort)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StatusStrip(vm)
        SectionCard("Teams") {
            TextInput("Team A name", teamA, { teamA = it })
            ColorPicker("Team A colour", colorA) { colorA = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Team A logo", Modifier.weight(1f)) { pickA.launch("image/*") }
                if (m.teamALogoPath != null) BigButton("Remove", Modifier.weight(1f), Color(0xFF5A2A2A)) { vm.clearMedia(MediaKind.TEAM_A) }
            }
            TextInput("Team B name", teamB, { teamB = it })
            ColorPicker("Team B colour", colorB) { colorB = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Team B logo", Modifier.weight(1f)) { pickB.launch("image/*") }
                if (m.teamBLogoPath != null) BigButton("Remove", Modifier.weight(1f), Color(0xFF5A2A2A)) { vm.clearMedia(MediaKind.TEAM_B) }
            }
        }
        SectionCard("Match") {
            TextInput("Match title", title, { title = it }, placeholder = "e.g. Final • Quarter Final")
            TextInput("Venue", venue, { venue = it })
            Text("Format", fontSize = 12.sp)
            ChipChoice(
                listOf(10, 20, 50, 0), overs.toIntOrNull()?.takeIf { it == 10 || it == 20 || it == 50 } ?: 0,
                { when (it) { 10 -> "T10"; 20 -> "T20"; 50 -> "ODI 50"; else -> "Custom" } }
            ) { if (it > 0) overs = it.toString() }
            TextInput("Overs per innings (custom allowed)", overs, { overs = it }, numeric = true)
            TextInput("Players per side (wickets = players − 1)", players, { players = it }, numeric = true)
            SwitchRow("Free hit after a no-ball", freeHit) { freeHit = it }
            val lockedNote = st != null
            if (lockedNote) Text("The match has started: overs / players / rules are locked. Title, venue and colours can still change.", fontSize = 12.sp, color = Color(0xFFFFB74D))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton(if (m.state == null && m.inningsIndex < 0) "Create / update match" else "Update labels & colours", Modifier.weight(1f), Gold, Color.Black) {
                    if (m.inningsIndex < 0) vm.newMatch(currentSetup(), currentVisuals()) else vm.updateSetup(currentSetup(), currentVisuals())
                }
            }
        }

        InningsSetupCard(vm, m, onNavigate)

        SectionCard("Toss & start time (pre-match card)") {
            Text("Shown on air before the first ball: who won the toss, what they chose, and when the match starts.", fontSize = 12.sp)
            Text("Toss won by", fontSize = 12.sp)
            val winnerOptions = listOf("") + listOf(teamA.trim(), teamB.trim()).filter { it.isNotEmpty() }.distinct()
            ChipChoice(winnerOptions, tossWinner.trim().let { w -> winnerOptions.firstOrNull { it.equals(w, true) } ?: "" }, { if (it.isEmpty()) "Not announced" else it }) { tossWinner = it }
            Text("Decision", fontSize = 12.sp)
            ChipChoice(TossDecision.values().toList(), tossDecision, { it.label }) { tossDecision = it }
            TextInput("Match start time", startTime, { startTime = it }, placeholder = "e.g. 3:30 PM")
            BigButton("Update pre-match card", Modifier.fillMaxWidth(), Gold, Color.Black) {
                if (m.inningsIndex < 0) vm.newMatch(currentSetup(), currentVisuals()) else vm.updateSetup(currentSetup(), currentVisuals())
            }
        }
        SectionCard("Save / reset") {
            TextInput("Save as", saveName, { saveName = it }, placeholder = "${m.setup.teamA} vs ${m.setup.teamB}")
            BigButton("Save match", Modifier.fillMaxWidth()) { vm.saveMatchAs(saveName); saveName = "" }
            BigButton("Reset match…", Modifier.fillMaxWidth(), Color(0xFF8E1B1B)) { confirmReset = true }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset the whole match?") },
            text = { Text("All scoring events of this match will be removed from the console. Save the match first if you may need it again.") },
            confirmButton = { TextButton(onClick = { vm.resetMatch(); confirmReset = false }) { Text("Reset", color = Crimson) } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun InningsSetupCard(vm: AppViewModel, m: MatchUi, onNavigate: (String) -> Unit) {
    val st = m.state
    val secondInnings = st != null && st.ended && m.inningsIndex == 0
    val firstInnings = m.inningsIndex < 0
    if (!(firstInnings || secondInnings)) return

    // The toss (when entered) decides who bats first.
    val defaultBat = if (secondInnings) st!!.bowlingTeam else (m.setup.battingFirstTeam ?: m.setup.teamA)
    var battingA by remember(m.matchId, secondInnings, m.setup.tossWinner, m.setup.tossDecision) {
        mutableStateOf(defaultBat.trim().equals(m.setup.teamA.trim(), true))
    }
    var striker by remember(m.matchId, secondInnings) { mutableStateOf("") }
    var nonStriker by remember(m.matchId, secondInnings) { mutableStateOf("") }
    var bowler by remember(m.matchId, secondInnings) { mutableStateOf("") }
    var target by remember(m.matchId, secondInnings) { mutableStateOf("") }
    val bat = if (battingA) m.setup.teamA else m.setup.teamB
    val bowl = if (battingA) m.setup.teamB else m.setup.teamA

    SectionCard(if (secondInnings) "Start 2nd innings" else "Start 1st innings") {
        if (firstInnings && m.setup.validate() != null) Text("Create the match above first.", color = Color(0xFFFFB74D))
        Text("Batting team", fontSize = 12.sp)
        ChipChoice(listOf(true, false), battingA, { if (it) m.setup.teamA else m.setup.teamB }) { battingA = it }
        TextInput("Opening striker", striker, { striker = it })
        TextInput("Opening non-striker", nonStriker, { nonStriker = it })
        TextInput("Opening bowler ($bowl)", bowler, { bowler = it })
        if (secondInnings) {
            TextInput("Target override (optional, e.g. revised target)", target, { target = it }, numeric = true)
            Text("Default target = ${(st?.runs ?: 0) + 1}", fontSize = 12.sp)
        }
        val ready = striker.isNotBlank() && nonStriker.isNotBlank() && bowler.isNotBlank()
        BigButton("Start innings", Modifier.fillMaxWidth(), Gold, Color.Black, enabled = ready) {
            vm.startInnings(InningsSetup(bat, bowl, striker.trim(), nonStriker.trim(), bowler.trim()), target.toIntOrNull())
            onNavigate("score")
        }
        m.message?.let { Text("⚠ $it", color = Color(0xFFFF6B6B)) }
    }
}

// ================================================================================================ H. SAVED & PRESETS

@Composable
fun SavedScreen(vm: AppViewModel, onNavigate: (String) -> Unit) {
    val matches by vm.savedMatches.collectAsState()
    val presets by vm.presets.collectAsState()
    var presetName by remember { mutableStateOf("") }
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StatusStrip(vm)
        SectionCard("Saved matches") {
            if (matches.isEmpty()) Text("Nothing saved yet. Use “Save match” in Match Setup.", fontSize = 13.sp)
            matches.forEach { sm ->
                val ov = OverlayBuilder.from(sm.setup, sm.session, sm.visuals)
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text(sm.name, fontWeight = FontWeight.Bold)
                    Text("${sm.setup.teamA} vs ${sm.setup.teamB} • ${ov.battingShort} ${ov.score} (${ov.overs} ov) • ${fmt.format(Date(sm.updatedAtMs))}", fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BigButton("Resume", Modifier.weight(1f), Gold, Color.Black) { vm.loadMatch(sm); onNavigate("score") }
                        BigButton("Delete", Modifier.weight(1f), Color(0xFF5A2A2A)) { vm.deleteMatch(sm.id) }
                    }
                }
            }
        }
        SectionCard("Graphics presets") {
            TextInput("Preset name", presetName, { presetName = it })
            BigButton("Save current graphics as preset", Modifier.fillMaxWidth(), enabled = presetName.isNotBlank()) { vm.savePreset(presetName); presetName = "" }
            if (presets.isEmpty()) Text("No presets yet.", fontSize = 13.sp)
            presets.forEach { p ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.Bold)
                        Text(p.template.label, fontSize = 12.sp)
                    }
                    TextButton(onClick = { vm.applyPreset(p) }) { Text("Load") }
                    TextButton(onClick = { vm.deletePreset(p.name) }) { Text("Delete", color = Crimson) }
                }
            }
        }
    }
}

// ================================================================================================ I. SETTINGS & DIAGNOSTICS

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val info = remember { Diagnostics.collect(ctx) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StatusStrip(vm)
        SectionCard("Diagnostics (no secrets included)") {
            info.forEach { Text(it, fontSize = 12.sp) }
        }
        SectionCard("Privacy & stream key") {
            Text("• The stream key is masked by default, never written to logs, and only stored if you enable “Remember” (AES-256-GCM, Android Keystore).", fontSize = 12.sp)
            Text("• Audio is captured and transmitted only between Start Live and Stop Live, and only after you grant the microphone permission.", fontSize = 12.sp)
            Text("• Android may still terminate the app under memory pressure. After a process kill the app never resumes transmitting by itself; you must press Go Live again.", fontSize = 12.sp)
        }
        SectionCard("Not implemented (honest list)") {
            Text("• Streaming to two platforms at once from the phone is not implemented (it would double the upload). Use a restreaming service: send ONE stream to it and let it forward to YouTube and Facebook.", fontSize = 12.sp)
            Text("• Retired batter, super over and substitute handling are not in the scoring engine yet. DLS: only the revised-target arithmetic is provided (you enter the resource percentages from the official table).", fontSize = 12.sp)
            Text("• Dropped-frame counters are shown as “unavailable” until the transport reports them.", fontSize = 12.sp)
        }
    }
}

object Diagnostics {
    fun collect(ctx: Context): List<String> {
        val out = mutableListOf<String>()
        out += "Device: ${Build.MANUFACTURER} ${Build.MODEL}"
        out += "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        out += "App: ${com.zarvimo.cricket.BuildConfig.VERSION_NAME}"
        out += "Microphone permission: " + if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) "granted" else "not granted"
        try {
            val list = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            val h264 = list.filter { it.isEncoder && it.supportedTypes.any { t -> t.equals("video/avc", true) } }
            if (h264.isEmpty()) out += "H.264 encoder: NONE FOUND (streaming impossible on this device)"
            h264.forEach { info ->
                val hw = if (Build.VERSION.SDK_INT >= 29) (if (info.isHardwareAccelerated) "hardware" else "software") else "hardware?"
                val caps = info.getCapabilitiesForType("video/avc").videoCapabilities
                val sizes = ResolutionProfile.values().joinToString(", ") { p -> "${p.label}:" + if (caps.isSizeSupported(p.width, p.height)) "ok" else "NO" }
                out += "H.264 encoder ${info.name} ($hw) — $sizes"
            }
            val aac = list.filter { it.isEncoder && it.supportedTypes.any { t -> t.equals("audio/mp4a-latm", true) } }
            out += "AAC encoders: " + (if (aac.isEmpty()) "NONE FOUND" else aac.joinToString { it.name })
        } catch (e: Exception) {
            out += "Codec query failed: ${e.javaClass.simpleName}"
        }
        return out
    }
}
