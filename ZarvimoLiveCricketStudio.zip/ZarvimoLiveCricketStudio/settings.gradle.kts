pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // RootEncoder (RTMP/RTMPS + MediaCodec helpers) is published via JitPack.
        maven(url = "https://jitpack.io")
    }
}
rootProject.name = "ZarvimoLiveCricketStudio"
include(":app")
