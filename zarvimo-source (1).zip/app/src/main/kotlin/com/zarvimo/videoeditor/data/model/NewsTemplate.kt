package com.zarvimo.videoeditor.data.model

/**
 * A ready-made set of text overlays styled for a specific news-video look —
 * an accent badge, a bold lower-third headline banner, and a small channel
 * tag — so a news clip gets a professional-looking graphic in one tap
 * instead of authoring each overlay by hand.
 *
 * Every overlay a template creates is a perfectly ordinary [TextOverlay]:
 * once applied, each one can be tapped and edited (text, color, position,
 * timing, even deleted) through the exact same overlay sheet as any
 * manually-added overlay — "template" only describes how it starts out, not
 * a separate kind of object the rest of the app has to special-case. That is
 * also why there is no stored "this project uses template X" flag anywhere:
 * applying a template is just a convenient way to add three [TextOverlay]s
 * at once.
 */
enum class NewsTemplate(val label: String, val description: String) {
    BREAKING_NEWS(
        label = "Breaking News",
        description = "Red \"BREAKING NEWS\" badge + bold bottom headline banner"
    ),
    HEADLINE_UPDATE(
        label = "Headline Update",
        description = "Violet \"UPDATE\" kicker + clean lower-third headline banner"
    ),
    ENTERTAINMENT_FLASH(
        label = "Entertainment Flash",
        description = "Magenta/gold flash badge for celebrity & entertainment news"
    );

    /**
     * Builds this template's overlays anchored at [startTimeUs], each
     * lasting [durationUs] (clamped to a sane minimum so a near-zero span
     * never produces an unusable sliver). [channelTag] is the small,
     * persistent credit line — defaults to [DEFAULT_CHANNEL_TAG] so a
     * repeat user doesn't have to retype it every time, but like everything
     * else here it is just a starting value the overlay sheet can edit or
     * remove afterward.
     */
    fun buildOverlays(
        startTimeUs: Long,
        durationUs: Long = DEFAULT_DURATION_US,
        channelTag: String = DEFAULT_CHANNEL_TAG
    ): List<TextOverlay> {
        val clampedDurationUs = durationUs.coerceAtLeast(MIN_DURATION_US)
        val endTimeUs = startTimeUs + clampedDurationUs
        val tag = TextOverlay(
            text = channelTag,
            colorArgb = ARGB_GOLD,
            backgroundColorArgb = null,
            startTimeUs = startTimeUs,
            endTimeUs = endTimeUs,
            xFraction = 0.84f,
            yFraction = 0.95f,
            fontSizeSp = 16f,
            animation = TextAnimation.FADE_IN
        )

        return when (this) {
            BREAKING_NEWS -> listOf(
                TextOverlay(
                    text = "BREAKING NEWS",
                    colorArgb = ARGB_WHITE,
                    backgroundColorArgb = ARGB_RED,
                    startTimeUs = startTimeUs,
                    endTimeUs = endTimeUs,
                    xFraction = 0.28f,
                    yFraction = 0.14f,
                    fontSizeSp = 22f,
                    bold = true,
                    animation = TextAnimation.POP
                ),
                TextOverlay(
                    text = "Your headline here",
                    colorArgb = ARGB_WHITE,
                    backgroundColorArgb = ARGB_BANNER,
                    startTimeUs = startTimeUs,
                    endTimeUs = endTimeUs,
                    xFraction = 0.5f,
                    yFraction = 0.86f,
                    fontSizeSp = 30f,
                    bold = true,
                    animation = TextAnimation.SLIDE_UP
                ),
                tag
            )

            HEADLINE_UPDATE -> listOf(
                TextOverlay(
                    text = "UPDATE",
                    colorArgb = ARGB_WHITE,
                    backgroundColorArgb = ARGB_VIOLET,
                    startTimeUs = startTimeUs,
                    endTimeUs = endTimeUs,
                    xFraction = 0.2f,
                    yFraction = 0.14f,
                    fontSizeSp = 20f,
                    bold = true,
                    animation = TextAnimation.FADE_IN
                ),
                TextOverlay(
                    text = "Your headline here",
                    colorArgb = ARGB_WHITE,
                    backgroundColorArgb = ARGB_BANNER,
                    startTimeUs = startTimeUs,
                    endTimeUs = endTimeUs,
                    xFraction = 0.5f,
                    yFraction = 0.84f,
                    fontSizeSp = 30f,
                    bold = true,
                    animation = TextAnimation.FADE_IN
                ),
                tag.copy(colorArgb = ARGB_ELECTRIC_BLUE, xFraction = 0.5f, yFraction = 0.93f)
            )

            ENTERTAINMENT_FLASH -> listOf(
                TextOverlay(
                    text = "ENTERTAINMENT",
                    colorArgb = ARGB_WHITE,
                    backgroundColorArgb = ARGB_MAGENTA,
                    startTimeUs = startTimeUs,
                    endTimeUs = endTimeUs,
                    xFraction = 0.3f,
                    yFraction = 0.14f,
                    fontSizeSp = 20f,
                    bold = true,
                    italic = true,
                    animation = TextAnimation.POP
                ),
                TextOverlay(
                    text = "Your headline here",
                    colorArgb = ARGB_WHITE,
                    backgroundColorArgb = ARGB_BANNER,
                    startTimeUs = startTimeUs,
                    endTimeUs = endTimeUs,
                    xFraction = 0.5f,
                    yFraction = 0.86f,
                    fontSizeSp = 30f,
                    bold = true,
                    animation = TextAnimation.POP
                ),
                tag
            )
        }
    }

    companion object {
        const val DEFAULT_CHANNEL_TAG = "Pak Celeb Insider"
        const val DEFAULT_DURATION_US = 5_000_000L
        private const val MIN_DURATION_US = 1_000_000L

        // Spelled out as plain ARGB ints (matching TextOverlay.colorArgb's own
        // plain-Int shape, and TextOverlayRenderer's existing 0x99000000.toInt()
        // shadow-color idiom below) rather than importing Compose's Color type
        // into this data-layer file. Values mirror ui/theme/Color.kt.
        private const val ARGB_WHITE = 0xFFFFFFFF.toInt()
        private const val ARGB_RED = 0xFFFF4D6D.toInt() // ZarvimoDanger
        private const val ARGB_VIOLET = 0xFF8B5CF6.toInt() // ZarvimoViolet
        private const val ARGB_MAGENTA = 0xFFFF2D9E.toInt() // ZarvimoMagenta
        private const val ARGB_ELECTRIC_BLUE = 0xFF00D9FF.toInt() // ZarvimoElectricBlue
        private const val ARGB_GOLD = 0xFFFFC947.toInt() // ZarvimoGold

        // A semi-transparent black banner behind headline text so it stays
        // readable over any footage without fully blocking the frame.
        private const val ARGB_BANNER = 0xCC000000.toInt()
    }
}
