package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.data.model.NewsTemplate
import com.zarvimo.videoeditor.ui.components.NeonCard
import com.zarvimo.videoeditor.ui.theme.ZarvimoDanger
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoMagenta
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextPrimary
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary
import com.zarvimo.videoeditor.ui.theme.ZarvimoViolet

/**
 * Bottom sheet listing the ready-made [NewsTemplate] presets. Tapping one
 * applies it immediately (at the current playhead) and closes the sheet —
 * there is no separate preview/apply step, because every overlay a template
 * creates is just an ordinary, editable
 * [com.zarvimo.videoeditor.data.model.TextOverlay] afterward: picking the
 * wrong one and tapping another, or editing the result in place, costs
 * nothing.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsTemplateSheet(
    onApply: (NewsTemplate) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
            Text(
                text = stringResource(id = R.string.news_templates_title),
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = stringResource(id = R.string.news_templates_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
            )

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                NewsTemplate.entries.forEach { template ->
                    NewsTemplateRow(
                        template = template,
                        accentColor = accentColorFor(template),
                        onClick = {
                            onApply(template)
                            onDismiss()
                        }
                    )
                }
            }
        }
    }
}

private fun accentColorFor(template: NewsTemplate): Color = when (template) {
    NewsTemplate.BREAKING_NEWS -> ZarvimoDanger
    NewsTemplate.HEADLINE_UPDATE -> ZarvimoViolet
    NewsTemplate.ENTERTAINMENT_FLASH -> ZarvimoMagenta
}

@Composable
private fun NewsTemplateRow(
    template: NewsTemplate,
    accentColor: Color,
    onClick: () -> Unit
) {
    NeonCard(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(modifier = Modifier.size(14.dp).clip(CircleShape).background(accentColor)) {}
            Column(modifier = Modifier.weight(1f).padding(start = 14.dp)) {
                Text(
                    text = template.label,
                    style = MaterialTheme.typography.titleSmall,
                    color = ZarvimoTextPrimary
                )
                Text(
                    text = template.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = ZarvimoTextSecondary,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = ZarvimoElectricBlue,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
