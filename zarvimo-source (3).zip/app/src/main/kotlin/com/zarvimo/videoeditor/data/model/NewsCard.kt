package com.zarvimo.videoeditor.data.model

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * One procedurally-rendered "news card" — a full-frame animated graphic
 * (headline banner, match-score panel, player comparison, etc.) that is
 * composited as a project-level overlay on top of whatever is on the
 * primary track at its [startTimeUs]..[endTimeUs] window. Because every
 * template paints its own opaque background, an active card visually
 * *replaces* whatever real footage is underneath for that stretch of the
 * timeline — exactly like inserting a generated "slide" into the video —
 * while a [NewsTicker]/[NewsChannelBadge] can still keep showing on top
 * of it, same as they would over real footage.
 *
 * This is a port of the per-card JSON shape from the "ZCH NewsCard Studio"
 * reference web app, adapted to Zarvimo's serializable, fraction/microsecond
 * based overlay model. [fieldA]..[fieldD] are generic slots whose on-screen
 * meaning depends on [template] — see [NewsCardTemplate.fieldLabels] for the
 * exact prompt to show for each slot in the editor UI (an empty label means
 * that slot is unused by this template).
 *
 * Scope note (honest, not hidden): the reference app also supports a
 * multi-photo slideshow *within* a single card (several images, each with
 * its own in/out transition) and per-card sound effects. This port instead
 * gives each card up to two still images ([imageUri]/[imageUri2], the second
 * only used by templates that need a side-by-side/versus layout) with a Ken
 * Burns pan/zoom ([imageAnimation]) — the single-photo case the large
 * majority of real cards actually use. Multi-photo slideshow-per-card and
 * procedural sound effects are tracked as a follow-up, not implemented here.
 */
@Serializable
data class NewsCard(
    val id: String = UUID.randomUUID().toString(),
    val template: NewsCardTemplate,
    val startTimeUs: Long,
    val endTimeUs: Long,
    val headline: String = "",
    val description: String = "",
    val fieldA: String = "",
    val fieldB: String = "",
    val fieldC: String = "",
    val fieldD: String = "",
    val imageUri: String? = null,
    val imageUri2: String? = null,
    val textColorArgb: Int = DEFAULT_TEXT_COLOR,
    val backgroundColorArgb: Int = DEFAULT_BACKGROUND_COLOR,
    val textAnimation: NewsCardTextAnimation = NewsCardTextAnimation.FADE_IN,
    val imageAnimation: NewsCardImageAnimation = NewsCardImageAnimation.ZOOM_IN,
    /** A brief extra zoom "punch" in the first ~0.4s a photo is shown, layered on top of [imageAnimation]. */
    val punchZoomOnEntry: Boolean = false
) {
    val durationUs: Long get() = (endTimeUs - startTimeUs).coerceAtLeast(0L)

    fun isVisibleAt(positionUs: Long): Boolean = positionUs in startTimeUs until endTimeUs

    /** Seconds since this card's own start, clamped to non-negative — what every drawing helper animates against. */
    fun localTimeSecondsAt(positionUs: Long): Float =
        (positionUs - startTimeUs).coerceAtLeast(0L) / 1_000_000f

    companion object {
        const val DEFAULT_DURATION_US = 5_000_000L
        const val MIN_DURATION_US = 1_000_000L
        const val DEFAULT_TEXT_COLOR = 0xFFFFFFFF.toInt()
        const val DEFAULT_BACKGROUND_COLOR = 0xFF0A1630.toInt()

        /** How long a card's entrance animation takes to settle, mirroring the reference app's default. */
        const val ENTRANCE_ANIMATION_SECONDS = 0.7f
    }
}

/**
 * The 8 card layouts ported in this round out of the reference app's 22 —
 * chosen to exercise every shared drawing primitive at least once (full
 * image + banner strip, gradient + circular flags, parallelogram panels,
 * side-by-side split, stat bars, player-comparison blocks) so the remaining
 * 14 are mechanical repeats of already-proven building blocks in a future
 * round, not new risk. See [NewsCardRenderer] for the actual drawing code.
 */
@Serializable
enum class NewsCardTemplate(val label: String, val fieldLabels: List<String>) {
    CLASSIC_BREAKING_NEWS(
        label = "Classic Breaking News",
        fieldLabels = listOf("", "", "", "")
    ),
    PROFESSIONAL_TV_BULLETIN(
        label = "Professional TV Bulletin",
        fieldLabels = listOf("", "", "", "")
    ),
    CRICKET_VERSUS(
        label = "Cricket Sports News (VS)",
        fieldLabels = listOf("Team A", "Team B", "Score line", "Info line")
    ),
    MATCH_SCORE_UPDATE(
        label = "Match Score Update",
        fieldLabels = listOf("Team A", "Team B", "Score (e.g. 187/4)", "Overs / wickets / status")
    ),
    TOP_BANNER_IMAGE(
        label = "Top Banner + Image",
        fieldLabels = listOf("Strip label (e.g. TOP STORIES)", "Banner headline strip text", "Strip text (optional)", "")
    ),
    PLAYER_DUEL_SIDE_BY_SIDE(
        label = "Player Duel (Side by Side)",
        fieldLabels = listOf("Player A name", "Player B name", "Player A stat (e.g. 58)", "Player B stat (e.g. 42)")
    ),
    PLAYER_STAT_BARS(
        label = "Player Stat Bars",
        fieldLabels = listOf("Player A name", "Player B name", "Player A value (number)", "Player B value (number)")
    ),
    WINNER_HIGHLIGHT(
        label = "Winner Highlight",
        fieldLabels = listOf("Player A name", "Player B name", "Player A value (number)", "Player B value (number)")
    )
}

/**
 * Entrance animations applied to every block of text a template draws
 * (headline, description, stat labels, ...). Faithfully ported from the
 * reference app's 14-mode `ta` animation set (opacity ramp plus a
 * translate/scale/rotate/clip-wipe transform that settles by
 * [NewsCard.ENTRANCE_ANIMATION_SECONDS]). [NONE] skips the ramp entirely —
 * every other mode still fades in even if it has no transform of its own.
 */
@Serializable
enum class NewsCardTextAnimation(val label: String) {
    FADE_IN("Fade in"),
    SLIDE_FROM_RIGHT("Slide from right"),
    SLIDE_FROM_LEFT("Slide from left"),
    SLIDE_FROM_BOTTOM("Slide from bottom"),
    POP_IN("Pop in"),
    ZOOM_IN("Zoom in"),
    SLIDE_FROM_TOP("Slide from top"),
    ZOOM_OUT("Zoom out"),
    BOUNCE_DROP("Bounce drop"),
    SPIN_IN("Spin in"),
    FLIP_IN("Flip in"),
    WIPE_RIGHT_TO_LEFT("Wipe right to left"),
    WIPE_LEFT_TO_RIGHT("Wipe left to right"),
    NONE("None")
}

/**
 * Ken Burns-style pan/zoom animations applied to a card's own photo while
 * it's on screen, ported from the reference app's `ia` animation set.
 */
@Serializable
enum class NewsCardImageAnimation(val label: String) {
    ZOOM_IN("Zoom in"),
    ZOOM_OUT("Zoom out"),
    PAN_LEFT("Pan left"),
    PAN_RIGHT("Pan right"),
    PAN_UP("Pan up"),
    PAN_DOWN("Pan down"),
    ZOOM_IN_PAN_RIGHT("Zoom in + pan right"),
    ZOOM_OUT_PAN_LEFT("Zoom out + pan left"),
    SUBTLE_PULSE("Subtle pulse"),
    DRAMATIC_ZOOM("Dramatic zoom"),
    NONE("None")
}

/**
 * A scrolling news ticker burned across the bottom of the frame, independent
 * of any single card — it can run for the whole project or a custom range,
 * over real footage, over a card, or both. Project-level, like
 * [NewsChannelBadge]; there is at most one of each per [Project].
 */
@Serializable
data class NewsTicker(
    val enabled: Boolean = true,
    val text: String = "بریکنگ نیوز • تازہ ترین خبریں",
    val speedPxPerSecondAt720p: Float = 120f,
    val textColorArgb: Int = 0xFFFFFFFF.toInt(),
    val backgroundColorArgb: Int = 0xFFC8102E.toInt(),
    /** true scrolls right-to-left (natural for Urdu/Arabic), false scrolls left-to-right. */
    val rightToLeft: Boolean = true,
    val startTimeUs: Long = 0L,
    val endTimeUs: Long = Long.MAX_VALUE
) {
    fun isActiveAt(positionUs: Long): Boolean = enabled && positionUs in startTimeUs until endTimeUs
}

/** Where a [NewsChannelBadge] sits in the frame. */
@Serializable
enum class BadgeCorner { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }

/**
 * A small persistent channel logo or name pill, drawn in a corner of the
 * frame — same "always on top, independent of cards" role as [NewsTicker].
 * If [logoUri] is null, a generated colored pill with [channelName] is drawn
 * instead (the reference app's fallback when no logo image is uploaded).
 */
@Serializable
data class NewsChannelBadge(
    val enabled: Boolean = true,
    val channelName: String = "",
    val logoUri: String? = null,
    val corner: BadgeCorner = BadgeCorner.TOP_RIGHT,
    val sizeFraction: Float = 0.14f,
    val opacity: Float = 0.9f,
    val startTimeUs: Long = 0L,
    val endTimeUs: Long = Long.MAX_VALUE
) {
    fun isActiveAt(positionUs: Long): Boolean = enabled && positionUs in startTimeUs until endTimeUs
}
