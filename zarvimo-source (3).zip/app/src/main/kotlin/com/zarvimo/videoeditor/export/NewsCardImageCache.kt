package com.zarvimo.videoeditor.export

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.util.concurrent.ConcurrentHashMap

/**
 * Decodes a news-card photo URI once and reuses the [Bitmap] for every
 * subsequent frame that needs it. [NewsCardRenderer.renderScene] is called
 * once per *exported* frame (it needs each frame's exact Ken Burns pan/zoom
 * position), so without this cache a multi-second card would re-decode the
 * same source image from disk dozens of times a second. Call [clear] when a
 * project is unloaded so these bitmaps don't outlive it.
 */
object NewsCardImageCache {

    private val cache = ConcurrentHashMap<String, Bitmap>()

    /** Returns a loader function bound to [context], suitable for [NewsCardRenderer.renderScene]'s `loadImage` parameter. */
    fun loaderFor(context: Context): (String) -> Bitmap? = { uri -> get(context, uri) }

    fun get(context: Context, uriString: String): Bitmap? {
        cache[uriString]?.let { return it }
        val decoded = runCatching {
            context.contentResolver.openInputStream(Uri.parse(uriString))?.use {
                BitmapFactory.decodeStream(it)
            }
        }.getOrNull() ?: return null
        cache[uriString] = decoded
        return decoded
    }

    fun clear() {
        cache.clear()
    }
}
