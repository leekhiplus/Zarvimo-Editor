package com.zarvimo.videoeditor.export

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.zarvimo.videoeditor.data.model.BadgeCorner
import com.zarvimo.videoeditor.data.model.NewsCard
import com.zarvimo.videoeditor.data.model.NewsCardImageAnimation
import com.zarvimo.videoeditor.data.model.NewsCardTemplate
import com.zarvimo.videoeditor.data.model.NewsCardTextAnimation
import com.zarvimo.videoeditor.data.model.NewsChannelBadge
import com.zarvimo.videoeditor.data.model.NewsTicker
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws a [NewsCard] (plus the independent [NewsTicker]/[NewsChannelBadge]
 * overlays) onto an `android.graphics.Canvas`, faithfully ported — drawing
 * primitive by drawing primitive — from the "ZCH NewsCard Studio" reference
 * web app's hand-coded Canvas 2D template functions. The exact same code
 * path is used by both the live Compose preview and the frame-accurate
 * export overlay ([NewsSceneOverlay]), so what the editor shows is always
 * what gets exported — there is no separate "preview-only" rendering here,
 * unlike [TextOverlayRenderer]'s animation.
 *
 * Scope note: this round ports 8 of the reference app's 22 templates — one
 * representative of every shared drawing primitive (full-bleed image +
 * banner strip, gradient backgrounds, circular flag badges, parallelogram
 * label chips, side-by-side split layouts, stat bars, player-comparison
 * blocks) — so the remaining 14 are mechanical repeats of already-working
 * building blocks for a follow-up round, not new risk. A card's own photo
 * is a single still image with a Ken Burns pan/zoom, not the reference
 * app's multi-photo slideshow-per-card; procedural sound effects and the
 * "fit with blurred letterbox" image mode are not ported. All of this is
 * intentional and documented, not silently dropped.
 */
object NewsCardRenderer {

    /** The reference app lays every template out against a 720px-tall canvas; everything scales from that. */
    private const val REFERENCE_HEIGHT = 720f

    private data class Scene(val canvas: Canvas, val w: Float, val h: Float, val s: Float)

    /**
     * Renders one frame of the "news scene" at [projectTimeUs] (absolute
     * project time, not clip-local — callers are responsible for the
     * conversion, same as [TextOverlayRenderer]'s callers are): [activeCard]
     * if one is showing (pass null when none is), then [ticker] and [badge]
     * on top of it if they're active at this instant. The canvas is assumed
     * freshly transparent; a card paints its own full-frame opaque
     * background, intentionally replacing whatever is drawn under this
     * overlay for as long as it is on screen (see [NewsCard]'s doc comment).
     */
    fun renderScene(
        canvas: Canvas,
        widthPx: Int,
        heightPx: Int,
        projectTimeUs: Long,
        activeCard: NewsCard?,
        ticker: NewsTicker?,
        badge: NewsChannelBadge?,
        loadImage: (String) -> Bitmap?
    ) {
        val w = widthPx.coerceAtLeast(1).toFloat()
        val h = heightPx.coerceAtLeast(1).toFloat()
        val scene = Scene(canvas, w, h, h / REFERENCE_HEIGHT)

        val tickerOn = ticker?.isActiveAt(projectTimeUs) == true
        val tickerHeight = if (tickerOn) 0.075f * h else 0f
        val bodyHeight = h - tickerHeight

        if (activeCard != null) {
            val localTimeSec = activeCard.localTimeSecondsAt(projectTimeUs)
            val image1 = activeCard.imageUri?.let(loadImage)
            val image2 = activeCard.imageUri2?.let(loadImage)
            drawCard(scene, activeCard, localTimeSec, bodyHeight, image1, image2)
        }
        if (tickerOn && ticker != null) {
            drawTicker(scene, ticker, projectTimeUs, bodyHeight)
        }
        if (badge?.isActiveAt(projectTimeUs) == true) {
            drawBadge(scene, badge, badge.logoUri?.let(loadImage), tickerHeight)
        }
    }

    // -------------------------------------------------------------------
    // Templates
    // -------------------------------------------------------------------

    private fun drawCard(
        scene: Scene,
        card: NewsCard,
        t: Float,
        body: Float,
        image1: Bitmap?,
        image2: Bitmap?
    ) {
        val w = scene.w
        val h = scene.h
        val s = scene.s
        val tc = card.textColorArgb
        val durationSec = (card.durationUs / 1_000_000f).coerceAtLeast(0.1f)

        // Every template starts by owning the whole frame with its background
        // color — an active card fully replaces whatever is behind it.
        fillRect(scene, 0f, 0f, w, h, card.backgroundColorArgb)

        when (card.template) {
            NewsCardTemplate.CLASSIC_BREAKING_NEWS -> {
                val ih = body * 0.52f
                drawImageKenBurns(scene, image1, 0f, 0f, w, ih, t, durationSec, card.imageAnimation, card.punchZoomOnEntry)
                fillRect(scene, 0f, ih, w, body * 0.28f, 0xFFC8102E.toInt())
                drawShineSweep(scene, 0f, ih, w, body * 0.28f, t)
                fillRect(scene, 0f, ih, w, 6f * s, 0xFFF5C518.toInt())
                labelBadge(scene, "BREAKING NEWS", 0.03f * w, 0.03f * body, 260f * s, 48f * s, 0xFFC8102E.toInt(), Color.WHITE)
                drawWrappedText(scene, card.headline, 0.04f * w, ih + 0.025f * body, 0.92f * w, 50f, tc, true, false, t, card.textAnimation)
                drawWrappedText(scene, card.description, 0.04f * w, ih + body * 0.29f, 0.92f * w, 28f, Color.WHITE, false, false, t, card.textAnimation)
            }

            NewsCardTemplate.PROFESSIONAL_TV_BULLETIN -> {
                fillRect(scene, 0f, 0f, w, body * 0.2f, 0xFF0D2A6B.toInt())
                drawShineSweep(scene, 0f, 0f, w, body * 0.2f, t)
                fillRect(scene, 0f, body * 0.2f, w, 5f * s, 0xFFF5C518.toInt())
                drawWrappedText(scene, card.headline, 0.04f * w, 0.03f * body, 0.92f * w, 44f, tc, true, false, t, card.textAnimation)
                val ih = body * 0.4f
                drawImageKenBurns(scene, image1, 0.06f * w, body * 0.24f, 0.88f * w, ih, t, durationSec, card.imageAnimation, card.punchZoomOnEntry)
                drawWrappedText(scene, card.description, 0.06f * w, body * 0.27f + ih, 0.88f * w, 28f, Color.WHITE, false, false, t, card.textAnimation)
            }

            NewsCardTemplate.CRICKET_VERSUS -> {
                fillGradient(scene, 0f, 0f, 0f, h, 0xFF0A1630.toInt(), 0xFF16398A.toInt())
                drawImageKenBurns(scene, image1, 0f, 0f, w, body * 0.38f, t, durationSec, card.imageAnimation, card.punchZoomOnEntry)
                val r = min(w, h) * 0.075f
                drawFlagBadge(scene, card.fieldA, w * 0.25f, body * 0.46f, r)
                drawFlagBadge(scene, card.fieldB, w * 0.75f, body * 0.46f, r)
                val vsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFFF5C518.toInt()
                    textSize = 44f * s
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.CENTER
                }
                drawCentered(scene.canvas, "VS", w / 2f, body * 0.46f, vsPaint)
                val headH = drawWrappedText(scene, card.headline, 0.04f * w, body * 0.58f, 0.92f * w, 42f, tc, true, false, t, card.textAnimation)
                val py = body * 0.58f + headH
                fillRect(scene, 0.05f * w, py + 0.01f * body, 0.9f * w, 0.2f * body, 0x73000000, 16f * s)
                drawShineSweep(scene, 0.05f * w, py + 0.01f * body, 0.9f * w, 0.2f * body, t)
                drawWrappedText(scene, card.fieldC, 0.06f * w, py + 0.015f * body, 0.88f * w, 40f, 0xFFF5C518.toInt(), true, false, t, card.textAnimation)
                drawWrappedText(scene, card.fieldD, 0.06f * w, py + 0.11f * body, 0.88f * w, 26f, Color.WHITE, false, false, t, card.textAnimation)
            }

            NewsCardTemplate.MATCH_SCORE_UPDATE -> {
                fillGradient(scene, 0f, 0f, w, h, 0xFF0A1630.toInt(), 0xFF1B3A8C.toInt())
                labelBadge(scene, "MATCH UPDATE", 0.04f * w, 0.03f * body, 260f * s, 46f * s, 0xFFE10600.toInt(), Color.WHITE)
                drawWrappedText(scene, card.headline, 0.04f * w, 0.12f * body, 0.92f * w, 34f, tc, true, false, t, card.textAnimation)
                val r = min(w, h) * 0.11f
                drawFlagBadge(scene, card.fieldA, w * 0.2f, body * 0.45f, r)
                drawFlagBadge(scene, card.fieldB, w * 0.8f, body * 0.45f, r)
                drawWrappedText(scene, card.fieldC, 0.3f * w, body * 0.37f, 0.4f * w, 80f, 0xFFF5C518.toInt(), true, false, t, card.textAnimation)
                drawWrappedText(scene, card.fieldD, 0.05f * w, body * 0.7f, 0.9f * w, 32f, Color.WHITE, false, false, t, card.textAnimation)
                drawWrappedText(scene, card.description, 0.05f * w, body * 0.8f, 0.9f * w, 24f, 0xFFC9D6FF.toInt(), false, false, t, card.textAnimation)
            }

            NewsCardTemplate.TOP_BANNER_IMAGE -> {
                val tb = max(0.09f * body, 54f * s)
                topBannerBarClassic(scene, card.fieldB.ifBlank { "BREAKING NEWS" }, tb, t)
                val ih = (body - tb) * 0.55f
                val y0 = tb + 4f * s
                drawImageKenBurns(scene, image1, 0f, y0, w, ih, t, durationSec, card.imageAnimation, card.punchZoomOnEntry)
                val y = y0 + ih + 0.03f * body
                val headH = drawWrappedText(scene, card.headline, 0.04f * w, y, 0.92f * w, 46f, tc, true, false, t, card.textAnimation)
                drawWrappedText(scene, card.description, 0.04f * w, y + headH + 0.01f * body, 0.92f * w, 26f, 0xFFE6E6E6.toInt(), false, false, t, card.textAnimation)
                stripBar(scene, card, body, t, 0xFF0A1630.toInt(), 0xFFF5C518.toInt(), 0xFF0A1630.toInt(), Color.WHITE)
            }

            NewsCardTemplate.PLAYER_DUEL_SIDE_BY_SIDE -> {
                val hw = w / 2f
                val ph = body * 0.5f
                drawImageKenBurns(scene, image1, 0f, 0f, hw, ph, t, durationSec, card.imageAnimation, card.punchZoomOnEntry)
                drawImageKenBurns(scene, image2, hw, 0f, hw, ph, t, durationSec, card.imageAnimation, card.punchZoomOnEntry)
                fillRect(scene, hw - 3f * s, 0f, 6f * s, ph, Color.WHITE)
                fillRect(scene, 0f, ph - 0.1f * body, w, 0.1f * body, 0xA6000000.toInt())
                drawWrappedText(scene, card.fieldA, 0f, ph - 0.085f * body, hw, 34f, 0xFFF5C518.toInt(), true, false, t, card.textAnimation)
                drawWrappedText(scene, card.fieldB, hw, ph - 0.085f * body, hw, 34f, 0xFFF5C518.toInt(), true, false, t, card.textAnimation)
                val vr = min(w, h) * 0.06f
                val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE10600.toInt() }
                scene.canvas.drawCircle(w / 2f, ph, vr, circlePaint)
                val vsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    textSize = vr * 0.9f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.CENTER
                }
                drawCentered(scene.canvas, "VS", w / 2f, ph, vsPaint)
                val y = ph + 0.05f * body
                val headH = drawWrappedText(scene, card.headline, 0.04f * w, y, 0.92f * w, 40f, tc, true, false, t, card.textAnimation)
                drawWrappedText(scene, card.fieldC, 0f, y + headH + 0.03f * body, hw, 64f, 0xFF25F4EE.toInt(), true, false, t, card.textAnimation)
                drawWrappedText(scene, card.fieldD, hw, y + headH + 0.03f * body, hw, 64f, 0xFFF5C518.toInt(), true, false, t, card.textAnimation)
                drawWrappedText(scene, card.description, 0.04f * w, y + headH + 0.03f * body + 0.15f * body, 0.92f * w, 26f, 0xFFC9D6FF.toInt(), false, false, t, card.textAnimation)
            }

            NewsCardTemplate.PLAYER_STAT_BARS -> {
                val tb = 0.16f * body
                fillRect(scene, 0f, 0f, w, tb, 0xFFE10600.toInt())
                fillRect(scene, 0f, tb, w, 4f * s, 0xFFF5C518.toInt())
                val headH = drawWrappedText(scene, card.headline, 0.04f * w, tb * 0.12f, 0.92f * w, 36f, Color.WHITE, true, false, t, card.textAnimation)
                drawWrappedText(scene, card.description, 0.04f * w, tb * 0.12f + headH + 6f * s, 0.92f * w, 24f, 0xFFFFE6A8.toInt(), false, false, t, card.textAnimation)
                val valueA = parseNumericValue(card.fieldC)
                val valueB = parseNumericValue(card.fieldD)
                val maxValue = max(valueA, valueB).let { if (it <= 0f) 1f else it }
                val rows = listOf(
                    Triple(card.fieldA, valueA to card.fieldC, 0xFF25F4EE.toInt()),
                    Triple(card.fieldB, valueB to card.fieldD, 0xFFF5C518.toInt())
                )
                rows.forEachIndexed { index, (name, valueAndRaw, barColor) ->
                    val (value, raw) = valueAndRaw
                    val y = tb + 0.12f * body + index * 0.3f * body
                    val barH = 0.1f * body
                    val barW = max(barH, 0.92f * w * value / maxValue)
                    drawWrappedText(scene, name, 0.04f * w, y, 0.92f * w, 38f, Color.WHITE, true, true, t, card.textAnimation)
                    fillRect(scene, 0.04f * w, y + 0.12f * body, 0.92f * w, barH, 0x1FFFFFFF, barH / 2f)
                    fillRect(scene, 0.04f * w, y + 0.12f * body, barW, barH, barColor, barH / 2f)
                    val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.BLACK
                        textSize = barH * 0.6f
                        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                        textAlign = Paint.Align.RIGHT
                    }
                    drawCentered(scene.canvas, raw.ifBlank { "0" }, 0.04f * w + barW - barH * 0.3f, y + 0.12f * body + barH / 2f, valuePaint)
                }
            }

            NewsCardTemplate.WINNER_HIGHLIGHT -> {
                val tb = 0.14f * body
                fillRect(scene, 0f, 0f, w, tb, 0xFF0A1630.toInt())
                fillRect(scene, 0f, tb, w, 4f * s, 0xFFF5C518.toInt())
                drawWrappedText(scene, card.headline, 0.04f * w, tb * 0.2f, 0.92f * w, 38f, tc, true, false, t, card.textAnimation)
                val valueA = parseNumericValue(card.fieldC)
                val valueB = parseNumericValue(card.fieldD)
                val cw = (w - 0.12f * w) / 2f
                val cy = tb + 0.08f * body
                val ch = body - cy - 0.06f * body
                playerCompareBlock(scene, card, t, 0.04f * w, cy, cw, ch, card.fieldA, card.fieldC, valueA > valueB, image1)
                playerCompareBlock(scene, card, t, w - 0.04f * w - cw, cy, cw, ch, card.fieldB, card.fieldD, valueB > valueA, image2)
                drawWrappedText(scene, card.description, 0.04f * w, body - 0.05f * body, 0.92f * w, 24f, 0xFFC9D6FF.toInt(), false, false, t, card.textAnimation)
            }
        }
    }

    // -------------------------------------------------------------------
    // Shared drawing primitives (ported from the reference app's R/LB/PG/
    // IT/T_/IMG/FLAG/SP/BN/PC/shine helpers)
    // -------------------------------------------------------------------

    private fun fillRect(scene: Scene, x: Float, y: Float, w: Float, h: Float, color: Int, cornerRadius: Float = 0f) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        if (cornerRadius > 0f) {
            scene.canvas.drawRoundRect(RectF(x, y, x + w, y + h), cornerRadius, cornerRadius, paint)
        } else {
            scene.canvas.drawRect(x, y, x + w, y + h, paint)
        }
    }

    private fun fillGradient(scene: Scene, x0: Float, y0: Float, x1: Float, y1: Float, colorStart: Int, colorEnd: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(x0, y0, x1, y1, colorStart, colorEnd, Shader.TileMode.CLAMP)
        }
        scene.canvas.drawRect(0f, 0f, scene.w, scene.h, paint)
    }

    private fun drawCentered(canvas: Canvas, text: String, x: Float, y: Float, paint: Paint) {
        val fm = paint.fontMetrics
        canvas.drawText(text, x, y - (fm.ascent + fm.descent) / 2f, paint)
    }

    private fun labelBadge(scene: Scene, text: String, x: Float, y: Float, w: Float, h: Float, bg: Int, fg: Int) {
        fillRect(scene, x, y, w, h, bg, h / 4f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = fg
            textSize = h * 0.52f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        drawCentered(scene.canvas, text, x + w / 2f, y + h / 2f, paint)
    }

    private fun parallelogram(
        scene: Scene,
        x: Float, y: Float, w: Float, h: Float, skew: Float,
        fill: Int,
        strokeColor: Int? = null,
        strokeWidth: Float = 0f
    ) {
        val path = Path().apply {
            moveTo(x + skew, y)
            lineTo(x + w + skew, y)
            lineTo(x + w, y + h)
            lineTo(x, y + h)
            close()
        }
        scene.canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fill })
        if (strokeColor != null) {
            scene.canvas.drawPath(
                path,
                Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    this.strokeWidth = strokeWidth
                    color = strokeColor
                }
            )
        }
    }

    private fun italicLabel(scene: Scene, text: String, x: Float, y: Float, fontSizePx: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = fontSizePx
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
            textAlign = Paint.Align.CENTER
        }
        drawCentered(scene.canvas, text, x, y, paint)
    }

    private data class WrapResult(val lines: List<String>, val isRtl: Boolean, val lineHeight: Float)

    private fun wrap(text: String, maxWidth: Float, fontSizePx: Float, bold: Boolean): WrapResult {
        val rtl = isRtl(text)
        val measurePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = fontSizePx
            typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        val lines = mutableListOf<String>()
        text.split("\n").forEach { paragraph ->
            val words = paragraph.split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (words.isEmpty()) {
                lines += ""
            } else {
                var line = ""
                words.forEach { word ->
                    val candidate = if (line.isEmpty()) word else "$line $word"
                    if (line.isNotEmpty() && measurePaint.measureText(candidate) > maxWidth) {
                        lines += line
                        line = word
                    } else {
                        line = candidate
                    }
                }
                lines += line
            }
        }
        val lineHeightFactor = if (rtl) 1.8f else 1.3f
        return WrapResult(lines, rtl, fontSizePx * lineHeightFactor)
    }

    /** Returns the total rendered height, like the reference app's `T_`. */
    private fun drawWrappedText(
        scene: Scene,
        text: String,
        x: Float, y: Float, w: Float, fontSizePxUnscaled: Float,
        color: Int,
        bold: Boolean,
        alignToEdge: Boolean,
        localTimeSec: Float,
        animation: NewsCardTextAnimation
    ): Float {
        if (text.isBlank()) return 0f
        val fontSizePx = fontSizePxUnscaled * scene.s
        val wrapped = wrap(text, w, fontSizePx, bold)
        val totalHeight = wrapped.lines.size * wrapped.lineHeight
        val centerX = x + w / 2f
        val centerY = y + totalHeight / 2f

        val canvas = scene.canvas
        canvas.save()
        val alphaFactor = applyEntranceAnimation(scene, localTimeSec, animation, centerX, centerY)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            alpha = (Color.alpha(color) * alphaFactor).toInt().coerceIn(0, 255)
            textSize = fontSizePx
            typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
            textAlign = if (alignToEdge) {
                if (wrapped.isRtl) Paint.Align.RIGHT else Paint.Align.LEFT
            } else {
                Paint.Align.CENTER
            }
        }
        val drawX = if (alignToEdge) {
            if (wrapped.isRtl) x + w else x
        } else {
            centerX
        }
        val fm = paint.fontMetrics
        wrapped.lines.forEachIndexed { i, line ->
            val baselineY = y + wrapped.lineHeight * (i + 0.5f) - (fm.ascent + fm.descent) / 2f
            canvas.drawText(line, drawX, baselineY, paint)
        }
        canvas.restore()
        return totalHeight
    }

    /**
     * Applies this animation's canvas transform (the caller has already
     * `save()`d) and returns the alpha multiplier to apply to what gets
     * drawn next — a faithful port of the reference app's `anim()`.
     */
    private fun applyEntranceAnimation(
        scene: Scene,
        localTimeSec: Float,
        animation: NewsCardTextAnimation,
        centerX: Float,
        centerY: Float
    ): Float {
        if (animation == NewsCardTextAnimation.NONE) return 1f
        val u = (localTimeSec / NewsCard.ENTRANCE_ANIMATION_SECONDS).coerceIn(0f, 1f)
        val p = easeOutCubic(u)
        val canvas = scene.canvas
        val w = scene.w
        val h = scene.h
        val isWipe = animation == NewsCardTextAnimation.WIPE_RIGHT_TO_LEFT ||
            animation == NewsCardTextAnimation.WIPE_LEFT_TO_RIGHT
        when (animation) {
            NewsCardTextAnimation.SLIDE_FROM_RIGHT -> canvas.translate((1f - p) * w * 0.5f, 0f)
            NewsCardTextAnimation.SLIDE_FROM_LEFT -> canvas.translate(-(1f - p) * w * 0.5f, 0f)
            NewsCardTextAnimation.SLIDE_FROM_BOTTOM -> canvas.translate(0f, (1f - p) * h * 0.3f)
            NewsCardTextAnimation.SLIDE_FROM_TOP -> canvas.translate(0f, -(1f - p) * h * 0.3f)
            NewsCardTextAnimation.BOUNCE_DROP -> canvas.translate(0f, -(1f - bounceOut(u)) * h * 0.35f)
            NewsCardTextAnimation.WIPE_RIGHT_TO_LEFT -> canvas.clipRect(w * (1f - p), 0f, w, h)
            NewsCardTextAnimation.WIPE_LEFT_TO_RIGHT -> canvas.clipRect(0f, 0f, w * p, h)
            NewsCardTextAnimation.FLIP_IN -> {
                canvas.translate(centerX, centerY)
                canvas.scale(max(0.02f, p), 1f)
                canvas.translate(-centerX, -centerY)
            }
            NewsCardTextAnimation.SPIN_IN -> {
                canvas.translate(centerX, centerY)
                canvas.rotate(-(1f - p) * 0.9f * RAD_TO_DEG)
                val q = 0.4f + 0.6f * p
                canvas.scale(q, q)
                canvas.translate(-centerX, -centerY)
            }
            NewsCardTextAnimation.POP_IN -> {
                canvas.translate(centerX, centerY)
                val inv = p - 1f
                val q = 1f + 2.70158f * inv * inv * inv + 1.70158f * inv * inv
                canvas.scale(q, q)
                canvas.translate(-centerX, -centerY)
            }
            NewsCardTextAnimation.ZOOM_IN -> {
                canvas.translate(centerX, centerY)
                val q = 0.6f + 0.4f * p
                canvas.scale(q, q)
                canvas.translate(-centerX, -centerY)
            }
            NewsCardTextAnimation.ZOOM_OUT -> {
                canvas.translate(centerX, centerY)
                val q = 1.6f - 0.6f * p
                canvas.scale(q, q)
                canvas.translate(-centerX, -centerY)
            }
            NewsCardTextAnimation.FADE_IN, NewsCardTextAnimation.NONE -> Unit
        }
        return if (isWipe) 1f else p
    }

    private fun drawImageKenBurns(
        scene: Scene,
        bitmap: Bitmap?,
        x: Float, y: Float, w: Float, h: Float,
        localTimeSec: Float,
        cardDurationSec: Float,
        animation: NewsCardImageAnimation,
        punchZoomOnEntry: Boolean
    ) {
        val canvas = scene.canvas
        canvas.save()
        canvas.clipRect(x, y, x + w, y + h)
        if (bitmap == null) {
            fillGradientRect(canvas, x, y, w, h, 0xFF1C2F66.toInt(), 0xFF0A1630.toInt())
            canvas.restore()
            return
        }
        val p = (localTimeSec / cardDurationSec).coerceIn(0f, 1f)
        var zoom = when (animation) {
            NewsCardImageAnimation.ZOOM_IN -> 1f + 0.15f * p
            NewsCardImageAnimation.ZOOM_OUT -> 1.15f - 0.15f * p
            NewsCardImageAnimation.PAN_LEFT, NewsCardImageAnimation.PAN_RIGHT,
            NewsCardImageAnimation.PAN_UP, NewsCardImageAnimation.PAN_DOWN -> 1.2f
            NewsCardImageAnimation.ZOOM_IN_PAN_RIGHT -> 1f + 0.2f * p
            NewsCardImageAnimation.ZOOM_OUT_PAN_LEFT -> 1.2f - 0.2f * p
            NewsCardImageAnimation.SUBTLE_PULSE -> 1.06f + 0.04f * sin(localTimeSec * 2.5f)
            NewsCardImageAnimation.DRAMATIC_ZOOM -> 1f + 0.35f * easeOutCubic((localTimeSec / 1.5f).coerceIn(0f, 1f))
            NewsCardImageAnimation.NONE -> 1f
        }
        var panX = 0f
        var panY = 0f
        when (animation) {
            NewsCardImageAnimation.PAN_LEFT -> panX = -(p - 0.5f) * 0.18f * w
            NewsCardImageAnimation.PAN_RIGHT -> panX = (p - 0.5f) * 0.18f * w
            NewsCardImageAnimation.PAN_UP -> panY = -(p - 0.5f) * 0.18f * h
            NewsCardImageAnimation.PAN_DOWN -> panY = (p - 0.5f) * 0.18f * h
            NewsCardImageAnimation.ZOOM_IN_PAN_RIGHT -> panX = (p - 0.5f) * 0.12f * w
            NewsCardImageAnimation.ZOOM_OUT_PAN_LEFT -> panX = -(p - 0.5f) * 0.12f * w
            else -> Unit
        }
        if (punchZoomOnEntry) {
            zoom *= 1f + 0.07f * max(0f, 1f - localTimeSec / 0.4f)
        }
        val coverScale = max(w / bitmap.width, h / bitmap.height) * zoom
        val dw = bitmap.width * coverScale
        val dh = bitmap.height * coverScale
        val left = x + (w - dw) / 2f + panX
        val top = y + (h - dh) / 2f + panY
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(bitmap, null, RectF(left, top, left + dw, top + dh), paint)
        canvas.restore()
    }

    private fun fillGradientRect(canvas: Canvas, x: Float, y: Float, w: Float, h: Float, colorStart: Int, colorEnd: Int) {
        val paint = Paint().apply {
            shader = LinearGradient(x, y, x + w, y + h, colorStart, colorEnd, Shader.TileMode.CLAMP)
        }
        canvas.drawRect(x, y, x + w, y + h, paint)
    }

    private val RTL_REGEX = Regex("[؀-ۿݐ-ݿﭐ-﷿ﹰ-﻿]")
    private fun isRtl(text: String): Boolean = RTL_REGEX.containsMatchIn(text)

    private fun drawFlagBadge(scene: Scene, name: String, cx: Float, cy: Float, radius: Float) {
        val canvas = scene.canvas
        val s = scene.s
        canvas.save()
        val clipPath = Path().apply { addCircle(cx, cy, radius, Path.Direction.CW) }
        canvas.clipPath(clipPath)
        if (Regex("(?i)pak|پاک").containsMatchIn(name)) {
            canvas.drawRect(cx - radius, cy - radius, cx + radius, cy + radius, Paint().apply { color = 0xFF01411C.toInt() })
            canvas.drawRect(cx - radius, cy - radius, cx - radius + radius * 0.5f, cy + radius, Paint().apply { color = Color.WHITE })
            canvas.drawCircle(cx + radius * 0.1f, cy, radius * 0.5f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
            canvas.drawCircle(cx + radius * 0.25f, cy - radius * 0.08f, radius * 0.42f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF01411C.toInt() })
            val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = radius * 0.4f
                textAlign = Paint.Align.CENTER
            }
            drawCentered(canvas, "★", cx + radius * 0.42f, cy - radius * 0.3f, starPaint)
        } else {
            canvas.drawRect(cx - radius, cy - radius, cx + radius, cy + radius, Paint().apply { color = 0xFF24418F.toInt() })
            val initials = name.replace(" ", "").take(3).uppercase().ifEmpty { "?" }
            val initialsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = radius * 0.6f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            drawCentered(canvas, initials, cx, cy, initialsPaint)
        }
        canvas.restore()

        canvas.drawCircle(
            cx, cy, radius,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 3f * s
                color = 0xFFF5C518.toInt()
            }
        )

        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 24f * s
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        drawCentered(canvas, name, cx, cy + radius + 26f * s, namePaint)
    }

    private fun drawShineSweep(scene: Scene, x: Float, y: Float, w: Float, h: Float, localTimeSec: Float) {
        val startDelay = 0.9f
        val period = 2.4f
        if (localTimeSec < startDelay) return
        val progress = ((localTimeSec - startDelay) % period) / 0.9f
        if (progress > 1f) return
        val canvas = scene.canvas
        canvas.save()
        canvas.clipRect(x, y, x + w, y + h)
        val barWidth = max(0.22f * w, 60f * scene.s)
        val barX = x - w * 0.25f + w * 1.5f * progress
        val paint = Paint().apply {
            shader = LinearGradient(
                barX, 0f, barX + barWidth, 0f,
                intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(127, 255, 255, 255), Color.argb(0, 255, 255, 255)),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        val path = Path().apply {
            moveTo(barX + h * 0.3f, y)
            lineTo(barX + barWidth + h * 0.3f, y)
            lineTo(barX + barWidth, y + h)
            lineTo(barX, y + h)
            close()
        }
        canvas.drawPath(path, paint)
        canvas.restore()
    }

    private fun parseNumericValue(raw: String): Float =
        raw.filter { it.isDigit() || it == '.' }.toFloatOrNull() ?: 0f

    private fun stripBar(
        scene: Scene,
        card: NewsCard,
        body: Float,
        localTimeSec: Float,
        barColor: Int,
        chipColor: Int,
        chipTextColor: Int,
        secondaryTextColor: Int
    ) {
        val w = scene.w
        val h = scene.h
        val s = scene.s
        val stripHeight = 0.06f * h
        val chipWidth = max(0.22f * w, 220f * s)
        fillRect(scene, 0f, body, w, stripHeight, barColor)
        parallelogram(scene, w - chipWidth - stripHeight * 0.3f, body, chipWidth, stripHeight, stripHeight * 0.3f, chipColor)
        val chipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = chipTextColor
            textSize = stripHeight * 0.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        drawCentered(scene.canvas, card.fieldA, w - chipWidth / 2f - stripHeight * 0.15f, body + stripHeight / 2f, chipPaint)
        if (card.fieldC.isNotBlank()) {
            val rtl = isRtl(card.fieldC)
            val secondaryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = secondaryTextColor
                textSize = stripHeight * 0.42f
                textAlign = if (rtl) Paint.Align.RIGHT else Paint.Align.LEFT
            }
            val x = if (rtl) w - chipWidth - stripHeight * 0.6f else 0.03f * w
            val fm = secondaryPaint.fontMetrics
            scene.canvas.drawText(card.fieldC, x, body + stripHeight / 2f - (fm.ascent + fm.descent) / 2f, secondaryPaint)
        }
        drawShineSweep(scene, 0f, body, w, stripHeight, localTimeSec)
    }

    private fun topBannerBarClassic(scene: Scene, text: String, bannerHeight: Float, localTimeSec: Float) {
        val w = scene.w
        val s = scene.s
        fillRect(scene, 0f, 0f, w, bannerHeight, 0xFFC8102E.toInt())
        fillRect(scene, 0f, bannerHeight, w, 4f * s, 0xFFF5C518.toInt())
        italicLabel(scene, text, w / 2f, bannerHeight / 2f, bannerHeight * 0.55f, Color.WHITE)
        drawShineSweep(scene, 0f, 0f, w, bannerHeight, localTimeSec)
    }

    private fun playerCompareBlock(
        scene: Scene,
        card: NewsCard,
        localTimeSec: Float,
        x: Float, y: Float, w: Float, h: Float,
        name: String,
        value: String,
        isWinner: Boolean,
        bitmap: Bitmap?
    ) {
        val s = scene.s
        if (isWinner) {
            fillRect(scene, x - 5f * s, y - 5f * s, w + 10f * s, h + 10f * s, 0xFFF5C518.toInt(), 18f * s)
        }
        fillRect(scene, x, y, w, h, 0xFF141C33.toInt(), 14f * s)
        drawImageKenBurns(
            scene, bitmap, x, y, w, h * 0.6f, localTimeSec,
            (card.durationUs / 1_000_000f).coerceAtLeast(0.1f), card.imageAnimation, card.punchZoomOnEntry
        )
        drawWrappedText(scene, name, x, y + h * 0.62f, w, 40f, Color.WHITE, true, false, localTimeSec, card.textAnimation)
        drawWrappedText(
            scene, value, x, y + h * 0.62f + 56f * s, w, 64f,
            if (isWinner) 0xFFF5C518.toInt() else Color.WHITE, true, false, localTimeSec, card.textAnimation
        )
        if (isWinner) {
            labelBadge(scene, "WINNER", x + w / 2f - 110f * s, y + h * 0.6f - 24f * s, 220f * s, 48f * s, 0xFFF5C518.toInt(), 0xFF0A1630.toInt())
        }
    }

    // -------------------------------------------------------------------
    // Ticker + channel badge (global, independent of any single card)
    // -------------------------------------------------------------------

    private fun drawTicker(scene: Scene, ticker: NewsTicker, projectTimeUs: Long, body: Float) {
        val w = scene.w
        val h = scene.h
        val s = scene.s
        val barHeight = 0.075f * h
        val y = body
        fillRect(scene, 0f, y, w, barHeight, ticker.backgroundColorArgb)
        fillRect(scene, 0f, y, w, 3f * s, 0xFFF5C518.toInt())
        drawShineSweep(scene, 0f, y, w, barHeight, projectTimeUs / 1_000_000f)

        val text = ticker.text
        if (text.isBlank()) return
        val canvas = scene.canvas
        canvas.save()
        canvas.clipRect(0f, y, w, y + barHeight)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ticker.textColorArgb
            textSize = barHeight * 0.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
        }
        val fm = paint.fontMetrics
        val baselineY = y + barHeight / 2f - (fm.ascent + fm.descent) / 2f
        val textWidth = paint.measureText(text)
        val gap = w * 0.2f
        val cycle = (textWidth + gap).coerceAtLeast(1f)
        val elapsedSec = projectTimeUs / 1_000_000f
        val speedPxPerSec = ticker.speedPxPerSecondAt720p * s
        val travelled = (elapsedSec * speedPxPerSec) % cycle
        val repeatsNeeded = (w / cycle).toInt() + 2
        if (ticker.rightToLeft) {
            var x = w - travelled
            repeat(repeatsNeeded) {
                canvas.drawText(text, x, baselineY, paint)
                x -= cycle
            }
        } else {
            var x = -textWidth + travelled
            repeat(repeatsNeeded) {
                canvas.drawText(text, x, baselineY, paint)
                x += cycle
            }
        }
        canvas.restore()
    }

    private fun drawBadge(scene: Scene, badge: NewsChannelBadge, logo: Bitmap?, reservedBottomHeight: Float) {
        val w = scene.w
        val h = scene.h
        val s = scene.s
        val canvas = scene.canvas
        val margin = 0.025f * w
        val alpha255 = (badge.opacity.coerceIn(0f, 1f) * 255).toInt()
        val isTop = badge.corner == BadgeCorner.TOP_LEFT || badge.corner == BadgeCorner.TOP_RIGHT
        val isRight = badge.corner == BadgeCorner.TOP_RIGHT || badge.corner == BadgeCorner.BOTTOM_RIGHT

        if (logo != null) {
            val boxWidth = badge.sizeFraction * w
            val boxHeight = boxWidth * logo.height / logo.width.coerceAtLeast(1)
            val x = if (isRight) w - margin - boxWidth else margin
            val y = if (isTop) margin else h - margin - reservedBottomHeight - boxHeight
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = alpha255 }
            canvas.drawBitmap(logo, null, RectF(x, y, x + boxWidth, y + boxHeight), paint)
        } else if (badge.channelName.isNotBlank()) {
            val fontSize = 26f * s * badge.sizeFraction / 0.14f
            val measurePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = fontSize
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val boxWidth = measurePaint.measureText(badge.channelName) + 30f * s
            val boxHeight = fontSize * 1.9f
            val x = if (isRight) w - margin - boxWidth else margin
            val y = if (isTop) margin else h - margin - reservedBottomHeight - boxHeight
            val cornerRadius = boxHeight / 5f
            fillRect(scene, x, y, boxWidth, boxHeight, withAlpha(0xFFC8102E.toInt(), alpha255), cornerRadius)
            canvas.drawRoundRect(
                RectF(x, y, x + boxWidth, y + boxHeight), cornerRadius, cornerRadius,
                Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 2f * s
                    color = withAlpha(0xFFF5C518.toInt(), alpha255)
                }
            )
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = withAlpha(Color.WHITE, alpha255)
                textSize = fontSize
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            drawCentered(canvas, badge.channelName, x + boxWidth / 2f, y + boxHeight / 2f, textPaint)
        }
    }

    private fun withAlpha(color: Int, alpha255: Int): Int = (color and 0x00FFFFFF) or (alpha255.coerceIn(0, 255) shl 24)

    // -------------------------------------------------------------------
    // Easing
    // -------------------------------------------------------------------

    private const val RAD_TO_DEG = 57.29578f

    private fun easeOutCubic(p: Float): Float {
        val inv = 1f - p
        return 1f - inv * inv * inv
    }

    private fun bounceOut(xIn: Float): Float {
        var x = xIn
        return when {
            x < 1f / 2.75f -> 7.5625f * x * x
            x < 2f / 2.75f -> { x -= 1.5f / 2.75f; 7.5625f * x * x + 0.75f }
            x < 2.5f / 2.75f -> { x -= 2.25f / 2.75f; 7.5625f * x * x + 0.9375f }
            else -> { x -= 2.625f / 2.75f; 7.5625f * x * x + 0.984375f }
        }
    }
}
