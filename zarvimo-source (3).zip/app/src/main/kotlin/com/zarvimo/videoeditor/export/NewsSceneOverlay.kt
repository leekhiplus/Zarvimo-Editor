package com.zarvimo.videoeditor.export

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlaySettings
import com.zarvimo.videoeditor.data.model.NewsCard
import com.zarvimo.videoeditor.data.model.NewsChannelBadge
import com.zarvimo.videoeditor.data.model.NewsTicker

/**
 * Renders the project's news cards / ticker / channel badge for one clip, one
 * frame at a time, via [NewsCardRenderer.renderScene] — the same frame-exact
 * approach [FadeToBlackOverlay] uses, extended from a one-off solid-color
 * fade to a fully animated scene. [presentationTimeUs] is this clip's own
 * local time (0 at the clip's first frame, same contract documented on
 * [FadeToBlackOverlay]); [clipTimelineStartUs] converts that to the
 * project-absolute time every [NewsCard]/[NewsTicker]/[NewsChannelBadge] is
 * authored against.
 *
 * A fresh, fully transparent bitmap is allocated every call so a moment with
 * no active card (and no ticker/badge) leaves the real video frame
 * underneath untouched — see [NewsCard]'s doc comment for why an *active*
 * card instead fully replaces it.
 */
class NewsSceneOverlay(
    private val context: Context,
    private val newsCards: List<NewsCard>,
    private val ticker: NewsTicker?,
    private val badge: NewsChannelBadge?,
    private val clipTimelineStartUs: Long,
    private val widthPx: Int,
    private val heightPx: Int
) : BitmapOverlay() {

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val projectTimeUs = clipTimelineStartUs + presentationTimeUs
        val activeCard = newsCards.lastOrNull { it.isVisibleAt(projectTimeUs) }
        val bitmap = Bitmap.createBitmap(
            widthPx.coerceAtLeast(1),
            heightPx.coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        NewsCardRenderer.renderScene(
            canvas = Canvas(bitmap),
            widthPx = widthPx,
            heightPx = heightPx,
            projectTimeUs = projectTimeUs,
            activeCard = activeCard,
            ticker = ticker,
            badge = badge,
            loadImage = NewsCardImageCache.loaderFor(context)
        )
        return bitmap
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        OverlaySettings.Builder().build()

    companion object {
        /** True if there is anything for this overlay to possibly draw during `[windowStartUs, windowEndUs)`. */
        fun isActiveDuring(
            newsCards: List<NewsCard>,
            ticker: NewsTicker?,
            badge: NewsChannelBadge?,
            windowStartUs: Long,
            windowEndUs: Long
        ): Boolean {
            val cardActive = newsCards.any { it.startTimeUs < windowEndUs && it.endTimeUs > windowStartUs }
            val tickerActive = ticker != null && ticker.enabled &&
                ticker.startTimeUs < windowEndUs && ticker.endTimeUs > windowStartUs
            val badgeActive = badge != null && badge.enabled &&
                badge.startTimeUs < windowEndUs && badge.endTimeUs > windowStartUs
            return cardActive || tickerActive || badgeActive
        }
    }
}
