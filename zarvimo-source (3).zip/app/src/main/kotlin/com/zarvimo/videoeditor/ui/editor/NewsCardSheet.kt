package com.zarvimo.videoeditor.ui.editor

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.data.model.NewsCard
import com.zarvimo.videoeditor.data.model.NewsCardImageAnimation
import com.zarvimo.videoeditor.data.model.NewsCardTemplate
import com.zarvimo.videoeditor.data.model.NewsCardTextAnimation
import com.zarvimo.videoeditor.ui.components.NeonGradientButton
import com.zarvimo.videoeditor.ui.theme.ZarvimoDanger
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoGold
import com.zarvimo.videoeditor.ui.theme.ZarvimoMagenta
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextPrimary
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary
import com.zarvimo.videoeditor.ui.theme.ZarvimoViolet

private val TEXT_COLOR_CHOICES = listOf(Color.White, ZarvimoGold, ZarvimoElectricBlue, ZarvimoViolet, ZarvimoMagenta)
private val BACKGROUND_COLOR_CHOICES = listOf(
    Color(0xFF0A1630.toInt()), Color(0xFFC8102E.toInt()), Color(0xFF1B3A8C.toInt()), Color(0xFF141C33.toInt()), Color.Black
)

/**
 * Bottom sheet to create a new [NewsCard] at [currentPlayheadUs] (5s default
 * duration) or edit/remove an existing one. Which of [NewsCard.fieldA]..
 * [NewsCard.fieldD] are shown, and their prompts, come straight from
 * [NewsCardTemplate.fieldLabels] — a blank label hides that slot since this
 * template doesn't use it.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsCardSheet(
    existingCard: NewsCard?,
    currentPlayheadUs: Long,
    onSave: (NewsCard) -> Unit,
    onRemove: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var template by remember(existingCard) { mutableStateOf(existingCard?.template ?: NewsCardTemplate.CLASSIC_BREAKING_NEWS) }
    var headline by remember(existingCard) { mutableStateOf(existingCard?.headline ?: "") }
    var description by remember(existingCard) { mutableStateOf(existingCard?.description ?: "") }
    var fieldA by remember(existingCard) { mutableStateOf(existingCard?.fieldA ?: "") }
    var fieldB by remember(existingCard) { mutableStateOf(existingCard?.fieldB ?: "") }
    var fieldC by remember(existingCard) { mutableStateOf(existingCard?.fieldC ?: "") }
    var fieldD by remember(existingCard) { mutableStateOf(existingCard?.fieldD ?: "") }
    var imageUri by remember(existingCard) { mutableStateOf(existingCard?.imageUri) }
    var imageUri2 by remember(existingCard) { mutableStateOf(existingCard?.imageUri2) }
    var textColor by remember(existingCard) { mutableStateOf(existingCard?.textColorArgb?.let { Color(it) } ?: Color.White) }
    var backgroundColor by remember(existingCard) {
        mutableStateOf(existingCard?.backgroundColorArgb?.let { Color(it) } ?: Color(0xFF0A1630.toInt()))
    }
    var textAnimation by remember(existingCard) { mutableStateOf(existingCard?.textAnimation ?: NewsCardTextAnimation.FADE_IN) }
    var imageAnimation by remember(existingCard) { mutableStateOf(existingCard?.imageAnimation ?: NewsCardImageAnimation.ZOOM_IN) }
    val startUs = existingCard?.startTimeUs ?: currentPlayheadUs
    var durationSeconds by remember(existingCard) {
        mutableFloatStateOf(
            existingCard?.durationUs?.let { it / 1_000_000f }?.coerceIn(2f, 15f) ?: 5f
        )
    }

    val pickImage1Launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) imageUri = uri.toString()
    }
    val pickImage2Launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) imageUri2 = uri.toString()
    }

    val needsSecondImage = template == NewsCardTemplate.PLAYER_DUEL_SIDE_BY_SIDE || template == NewsCardTemplate.WINNER_HIGHLIGHT

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Text(text = "News Card", style = MaterialTheme.typography.titleMedium)
            Text(
                text = "A full-screen animated news graphic placed on the timeline — it replaces whatever's underneath while it's showing.",
                style = MaterialTheme.typography.bodySmall,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 4f.dp, bottom = 12.dp)
            )

            Text(text = "Template", style = MaterialTheme.typography.bodyMedium, color = ZarvimoTextSecondary)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(top = 6.dp, bottom = 4.dp)
            ) {
                NewsCardTemplate.entries.forEach { option ->
                    FilterChip(
                        selected = template == option,
                        onClick = { template = option },
                        label = { Text(option.label) },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                    )
                }
            }

            OutlinedTextField(
                value = headline,
                onValueChange = { headline = it },
                label = { Text("Headline") },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            )
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )

            val labels = template.fieldLabels
            if (labels.getOrElse(0) { "" }.isNotEmpty()) {
                OutlinedTextField(
                    value = fieldA,
                    onValueChange = { fieldA = it },
                    label = { Text(labels[0]) },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
            if (labels.getOrElse(1) { "" }.isNotEmpty()) {
                OutlinedTextField(
                    value = fieldB,
                    onValueChange = { fieldB = it },
                    label = { Text(labels[1]) },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
            if (labels.getOrElse(2) { "" }.isNotEmpty()) {
                OutlinedTextField(
                    value = fieldC,
                    onValueChange = { fieldC = it },
                    label = { Text(labels[2]) },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
            if (labels.getOrElse(3) { "" }.isNotEmpty()) {
                OutlinedTextField(
                    value = fieldD,
                    onValueChange = { fieldD = it },
                    label = { Text(labels[3]) },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }

            Text(
                text = if (needsSecondImage) "Photos" else "Photo",
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 16.dp, bottom = 6.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NeonGradientButton(
                    text = if (imageUri == null) "Pick photo" else "Change photo",
                    onClick = { pickImage1Launcher.launch("image/*") },
                    modifier = Modifier.weight(1f)
                )
                if (needsSecondImage) {
                    NeonGradientButton(
                        text = if (imageUri2 == null) "Pick 2nd photo" else "Change 2nd photo",
                        onClick = { pickImage2Launcher.launch("image/*") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Text(
                text = "Headline color",
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TEXT_COLOR_CHOICES.forEach { swatch ->
                    ColorSwatch(swatch, textColor == swatch) { textColor = swatch }
                }
            }

            Text(
                text = "Background color",
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BACKGROUND_COLOR_CHOICES.forEach { swatch ->
                    ColorSwatch(swatch, backgroundColor == swatch) { backgroundColor = swatch }
                }
            }

            Text(
                text = "Text animation",
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 16.dp, bottom = 6.dp)
            )
            Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                NewsCardTextAnimation.entries.forEach { option ->
                    FilterChip(
                        selected = textAnimation == option,
                        onClick = { textAnimation = option },
                        label = { Text(option.label) },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                    )
                }
            }

            Text(
                text = "Photo animation",
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 16.dp, bottom = 6.dp)
            )
            Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                NewsCardImageAnimation.entries.forEach { option ->
                    FilterChip(
                        selected = imageAnimation == option,
                        onClick = { imageAnimation = option },
                        label = { Text(option.label) },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                    )
                }
            }

            Text(
                text = "Duration: ${durationSeconds.toInt()}s",
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 16.dp)
            )
            Slider(
                value = durationSeconds,
                onValueChange = { durationSeconds = it },
                valueRange = 2f..15f,
                steps = 12
            )

            if (onRemove != null) {
                Divider(modifier = Modifier.padding(vertical = 12.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = { onRemove(); onDismiss() }) {
                        Text("Remove card", color = ZarvimoDanger)
                    }
                }
            }

            NeonGradientButton(
                text = if (existingCard == null) "Add card" else "Update card",
                onClick = {
                    val endUs = startUs + (durationSeconds * 1_000_000L).toLong()
                    onSave(
                        NewsCard(
                            id = existingCard?.id ?: java.util.UUID.randomUUID().toString(),
                            template = template,
                            startTimeUs = startUs,
                            endTimeUs = endUs,
                            headline = headline,
                            description = description,
                            fieldA = fieldA,
                            fieldB = fieldB,
                            fieldC = fieldC,
                            fieldD = fieldD,
                            imageUri = imageUri,
                            imageUri2 = imageUri2,
                            textColorArgb = textColor.toArgb(),
                            backgroundColorArgb = backgroundColor.toArgb(),
                            textAnimation = textAnimation,
                            imageAnimation = imageAnimation
                        )
                    )
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
            )
        }
    }
}

@Composable
private fun ColorSwatch(color: Color, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(color)
            .border(
                width = if (selected) 3.dp else 1.dp,
                color = if (selected) ZarvimoElectricBlue else ZarvimoTextSecondary,
                shape = CircleShape
            )
            .clickable(onClick = onClick)
    ) {}
}
