package com.zarvimo.videoeditor.ui.editor

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.data.model.BadgeCorner
import com.zarvimo.videoeditor.data.model.NewsChannelBadge
import com.zarvimo.videoeditor.data.model.NewsTicker
import com.zarvimo.videoeditor.ui.components.NeonGradientButton
import com.zarvimo.videoeditor.ui.theme.ZarvimoDanger
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

/**
 * Project-level settings for the scrolling [NewsTicker] and the corner
 * [NewsChannelBadge] — unlike a [com.zarvimo.videoeditor.data.model.NewsCard],
 * there is at most one of each per project, and by default both run across
 * the whole timeline (same as a watermark would).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsTickerBadgeSheet(
    ticker: NewsTicker?,
    badge: NewsChannelBadge?,
    onSave: (NewsTicker?, NewsChannelBadge?) -> Unit,
    onDismiss: () -> Unit
) {
    var tickerEnabled by remember { mutableStateOf(ticker?.enabled ?: false) }
    var tickerText by remember { mutableStateOf(ticker?.text ?: "بریکنگ نیوز • تازہ ترین خبریں") }
    var tickerRtl by remember { mutableStateOf(ticker?.rightToLeft ?: true) }
    var tickerSpeed by remember { mutableFloatStateOf(ticker?.speedPxPerSecondAt720p ?: 120f) }

    var badgeEnabled by remember { mutableStateOf(badge?.enabled ?: false) }
    var channelName by remember { mutableStateOf(badge?.channelName ?: "") }
    var logoUri by remember { mutableStateOf(badge?.logoUri) }
    var corner by remember { mutableStateOf(badge?.corner ?: BadgeCorner.TOP_RIGHT) }

    val pickLogoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) logoUri = uri.toString()
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(24.dp)) {
            Text(text = "News Ticker & Logo", style = MaterialTheme.typography.titleMedium)
            Text(
                text = "These run across the whole video, over footage and over cards alike.",
                style = MaterialTheme.typography.bodySmall,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
            )

            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(text = "Scrolling ticker", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                FilterChip(
                    selected = tickerEnabled,
                    onClick = { tickerEnabled = !tickerEnabled },
                    label = { Text(if (tickerEnabled) "On" else "Off") },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                )
            }
            if (tickerEnabled) {
                OutlinedTextField(
                    value = tickerText,
                    onValueChange = { tickerText = it },
                    label = { Text("Ticker text") },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
                Row(modifier = Modifier.padding(top = 8.dp)) {
                    FilterChip(
                        selected = tickerRtl,
                        onClick = { tickerRtl = true },
                        label = { Text("Scroll right → left") },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                    )
                    FilterChip(
                        selected = !tickerRtl,
                        onClick = { tickerRtl = false },
                        label = { Text("Scroll left → right") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                    )
                }
                Text(
                    text = "Speed",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ZarvimoTextSecondary,
                    modifier = Modifier.padding(top = 12.dp)
                )
                Slider(value = tickerSpeed, onValueChange = { tickerSpeed = it }, valueRange = 40f..300f)
            }

            Divider(modifier = Modifier.padding(vertical = 16.dp))

            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(text = "Channel logo / badge", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                FilterChip(
                    selected = badgeEnabled,
                    onClick = { badgeEnabled = !badgeEnabled },
                    label = { Text(if (badgeEnabled) "On" else "Off") },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                )
            }
            if (badgeEnabled) {
                OutlinedTextField(
                    value = channelName,
                    onValueChange = { channelName = it },
                    label = { Text("Channel name (used if no logo image is picked)") },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
                NeonGradientButton(
                    text = if (logoUri == null) "Pick logo image" else "Change logo image",
                    onClick = { pickLogoLauncher.launch("image/*") },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
                Text(
                    text = "Position",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ZarvimoTextSecondary,
                    modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        BadgeCorner.TOP_LEFT to "Top left",
                        BadgeCorner.TOP_RIGHT to "Top right",
                        BadgeCorner.BOTTOM_LEFT to "Bottom left",
                        BadgeCorner.BOTTOM_RIGHT to "Bottom right"
                    ).forEach { (option, label) ->
                        FilterChip(
                            selected = corner == option,
                            onClick = { corner = option },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                        )
                    }
                }
            }

            NeonGradientButton(
                text = "Save",
                onClick = {
                    val newTicker = if (tickerEnabled) {
                        NewsTicker(
                            enabled = true,
                            text = tickerText,
                            speedPxPerSecondAt720p = tickerSpeed,
                            textColorArgb = ticker?.textColorArgb ?: NewsTicker().textColorArgb,
                            backgroundColorArgb = ticker?.backgroundColorArgb ?: NewsTicker().backgroundColorArgb,
                            rightToLeft = tickerRtl,
                            startTimeUs = ticker?.startTimeUs ?: 0L,
                            endTimeUs = ticker?.endTimeUs ?: Long.MAX_VALUE
                        )
                    } else {
                        null
                    }
                    val newBadge = if (badgeEnabled) {
                        NewsChannelBadge(
                            enabled = true,
                            channelName = channelName,
                            logoUri = logoUri,
                            corner = corner,
                            sizeFraction = badge?.sizeFraction ?: 0.14f,
                            opacity = badge?.opacity ?: 0.9f,
                            startTimeUs = badge?.startTimeUs ?: 0L,
                            endTimeUs = badge?.endTimeUs ?: Long.MAX_VALUE
                        )
                    } else {
                        null
                    }
                    onSave(newTicker, newBadge)
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
            )
        }
    }
}
