package com.zarvimo.videoeditor

import com.zarvimo.videoeditor.data.model.NewsCard
import com.zarvimo.videoeditor.data.model.NewsCardTemplate
import com.zarvimo.videoeditor.data.model.NewsChannelBadge
import com.zarvimo.videoeditor.data.model.NewsTicker
import com.zarvimo.videoeditor.data.model.Project
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NewsCardTest {

    private fun card(startUs: Long, endUs: Long) = NewsCard(
        template = NewsCardTemplate.CLASSIC_BREAKING_NEWS,
        startTimeUs = startUs,
        endTimeUs = endUs
    )

    @Test
    fun `isVisibleAt is true only within the card's own time window`() {
        val c = card(1_000_000, 3_000_000)
        assertFalse(c.isVisibleAt(500_000))
        assertTrue(c.isVisibleAt(1_000_000))
        assertTrue(c.isVisibleAt(2_999_999))
        assertFalse(c.isVisibleAt(3_000_000))
    }

    @Test
    fun `localTimeSecondsAt is zero before the card starts and counts up after`() {
        val c = card(2_000_000, 7_000_000)
        assertEquals(0f, c.localTimeSecondsAt(1_000_000))
        assertEquals(0f, c.localTimeSecondsAt(2_000_000))
        assertEquals(1.5f, c.localTimeSecondsAt(3_500_000))
    }

    @Test
    fun `a news card that ends after every clip and audio track extends totalDurationUs`() {
        val project = Project(
            name = "t",
            newsCards = listOf(card(0, 12_000_000))
        )
        assertEquals(12_000_000L, project.totalDurationUs)
    }

    @Test
    fun `totalDurationUs is the latest of clips, audio and news cards`() {
        val project = Project(
            name = "t",
            clips = listOf(
                com.zarvimo.videoeditor.data.model.VideoClip(sourceUri = "a", sourceDurationUs = 5_000_000, order = 0)
            ),
            newsCards = listOf(card(0, 3_000_000), card(3_000_000, 9_000_000))
        )
        assertEquals(9_000_000L, project.totalDurationUs)
    }

    @Test
    fun `a disabled ticker is never active even inside its own time window`() {
        val ticker = NewsTicker(enabled = false, startTimeUs = 0L, endTimeUs = 10_000_000L)
        assertFalse(ticker.isActiveAt(5_000_000))
    }

    @Test
    fun `an enabled ticker is active only within its time window`() {
        val ticker = NewsTicker(enabled = true, startTimeUs = 1_000_000L, endTimeUs = 4_000_000L)
        assertFalse(ticker.isActiveAt(500_000))
        assertTrue(ticker.isActiveAt(2_000_000))
        assertFalse(ticker.isActiveAt(4_000_000))
    }

    @Test
    fun `channel badge honors its own enabled flag and time window`() {
        val badge = NewsChannelBadge(enabled = true, startTimeUs = 0L, endTimeUs = 1_000_000L)
        assertTrue(badge.isActiveAt(0L))
        assertFalse(badge.isActiveAt(1_000_000L))
        assertFalse(badge.copy(enabled = false).isActiveAt(0L))
    }
}
