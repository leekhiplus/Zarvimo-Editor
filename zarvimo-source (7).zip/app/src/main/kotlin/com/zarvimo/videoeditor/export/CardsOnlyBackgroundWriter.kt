package com.zarvimo.videoeditor.export

import android.graphics.Bitmap
import android.graphics.Color
import java.io.File
import java.io.FileOutputStream

/**
 * Writes a tiny, solid-black PNG into the cache directory, used as the
 * primary track's "source" for a cards-only export — a project with news
 * cards/ticker/badge but zero real video clips on the timeline.
 *
 * Media3 Transformer's image-input support ([android.net.Uri] +
 * `MediaItem.Builder.setImageDurationMs`) lets a single still image stand in
 * for a video source of a given duration. Every
 * [com.zarvimo.videoeditor.data.model.NewsCard] template always paints an
 * opaque full-frame background first (see `NewsCard`'s own doc comment), so
 * this base image is never actually visible in the output — it only exists
 * to give Transformer something real and decodable to seed the sequence
 * with, while [NewsSceneOverlay] does all the real drawing on top of it, one
 * frame at a time, exactly as it already does for a real clip underneath.
 * This is what lets a cards-only project export at all without a bespoke
 * frame-exact encoder.
 *
 * A fixed small size (not the export's target resolution) keeps this cheap
 * to generate and decode — [androidx.media3.effect.Presentation] upscales it
 * to the real target size the same way it would an undersized real clip.
 */
object CardsOnlyBackgroundWriter {
    private const val SIZE_PX = 16

    /** Writes (or overwrites) the background PNG in [directory] and returns it. */
    fun writeBlackFrame(directory: File, fileName: String = "zarvimo_cards_only_bg.png"): File {
        directory.mkdirs()
        val file = File(directory, fileName)
        val bitmap = Bitmap.createBitmap(SIZE_PX, SIZE_PX, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(Color.BLACK)
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        bitmap.recycle()
        return file
    }
}
