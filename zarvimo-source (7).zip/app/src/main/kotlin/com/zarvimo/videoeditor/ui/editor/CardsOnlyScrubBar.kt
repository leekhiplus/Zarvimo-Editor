package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.data.model.NewsCard
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoSurface
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextPrimary

/**
 * Stands in for [TimelineView] when a project has news cards but no real
 * video clips — [TimelineView] only knows how to lay out [VideoClip]s, and a
 * cards-only project has none. Each card gets a segment sized proportionally
 * to its own duration (brighter while it's the one active at [positionUs]);
 * tapping anywhere scrubs to that fraction of [totalDurationUs], and the
 * thin progress bar underneath mirrors the exact playhead position the same
 * way it would for a real clip's timeline.
 */
@Composable
fun CardsOnlyScrubBar(
    newsCards: List<NewsCard>,
    totalDurationUs: Long,
    positionUs: Long,
    onSeekUs: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val orderedCards = newsCards.sortedBy { it.startTimeUs }
    val safeDurationUs = totalDurationUs.coerceAtLeast(1L)
    val playedFraction = (positionUs.toFloat() / safeDurationUs.toFloat()).coerceIn(0f, 1f)

    Column(
        modifier = modifier
            .background(ZarvimoSurface)
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .pointerInput(safeDurationUs) {
                detectTapGestures { offset ->
                    val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                    onSeekUs((fraction * safeDurationUs).toLong())
                }
            }
    ) {
        Row(modifier = Modifier.fillMaxWidth().weight(1f)) {
            orderedCards.forEach { card ->
                val isActive = card.isVisibleAt(positionUs)
                val weight = card.durationUs.coerceAtLeast(1L).toFloat()
                Box(
                    modifier = Modifier
                        .weight(weight)
                        .fillMaxSize()
                        .padding(horizontal = 1.5.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (isActive) ZarvimoElectricBlue else ZarvimoElectricBlue.copy(alpha = 0.3f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    val label = card.headline.ifBlank { card.template.name.replace('_', ' ') }
                    Text(
                        text = label,
                        maxLines = 1,
                        style = MaterialTheme.typography.labelSmall,
                        color = ZarvimoTextPrimary,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            }
        }
        LinearProgressIndicator(
            progress = { playedFraction },
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            color = ZarvimoElectricBlue
        )
    }
}
