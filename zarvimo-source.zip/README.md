# Zarvimo Video Editor

A real, working Android video editor built with Kotlin, Jetpack Compose, Gradle
Kotlin DSL, and AndroidX Media3. Premium black/navy UI with electric-blue,
violet and magenta neon accents.

> **Brand note:** this project was originally scaffolded as "Zafronix" and was
> renamed to **Zarvimo** at the user's request — the application ID, package
> name (`com.zarvimo.videoeditor`), app name, launcher icon, splash screen and
> all in-app text use **Zarvimo** throughout.

## What's implemented

**Architecture:** one primary video track (ordered, trimmed clips) plus
independent overlay layers — background audio tracks, image overlays, text
overlays — rather than true parallel multi-video-track compositing. This was
a deliberate choice to build on the proven Phase 1 player/export pipeline
instead of a much larger, harder-to-verify rewrite; see "Known limitations"
below for exactly what that does and doesn't cover.

- **Splash screen** — animated Zarvimo "Z" logo + wordmark, then routes to the dashboard.
- **Dashboard** — list of saved projects (name, duration, last-edited date), create/delete, empty state.
- **Media picker** — browses on-device videos via `MediaStore` + the standard permission flow (`READ_MEDIA_VIDEO` on API 33+, `READ_EXTERNAL_STORAGE` below), multi-select grid with thumbnails and durations.
- **Editor workspace**
  - Live video preview (Media3 `ExoPlayer` + `PlayerView`) with play/pause, prev/next-clip, and a playhead synced to the timeline.
  - Timeline: add clips, **reorder** (long-press + drag), **trim** (drag edge handles), **split** at the playhead, **duplicate**, **delete**.
  - Per-clip **crop** (drag-free, slider-driven edge margins), **rotate** (90° steps), **flip** (horizontal/vertical), **speed** (0.25x–4x, with the video/audio trade-off explained below), **brightness/contrast/saturation/temperature**, and a curated set of real **filters** (Vivid, Mono, Sepia, Cool, Warm, Fade, Noir) — every filter and slider is backed by an actual color-matrix effect, not a label with nothing behind it.
  - **Transitions**: fade-through-black between adjacent clips is real, in both preview and export. A true cross-dissolve between two clips' actual frames is intentionally **not** offered — see "Known limitations".
  - **Background audio tracks**: add music independent of the video clips, with its own start position on the timeline, trim range, volume, and fade in/out — previewed on a second synced player and baked into the export.
  - **Image overlays**: position, size, rotation and opacity, timed independently of the video clips.
  - **Text overlays**: position, size, color, bold/italic, an optional background chip, and an entrance animation (fade in / slide up / pop) — the animation previews live; see "Known limitations" for why it isn't baked into the exported file.
  - **Aspect ratio** picker (16:9, 9:16, 1:1, 4:3), affecting both preview and export framing.
  - **Undo/redo** across every edit above.
  - **Local project save** — JSON on disk, no cloud dependency; every new field has a default so an old Phase 1 project file still loads correctly.
  - **Export** — renders a real H.264/AAC `.mp4` via Media3 `Transformer`: quality picker (720p/1080p/4K), frame rate picker (24/30/60fps), live progress, cancel, an optional save-to destination (Storage Access Framework) alongside the app's own exports folder, and share-sheet on completion.
- **Architecture** — UI (Compose screens/components), timeline (`TimelineView` + gesture handling), project data (`data/model`, `ProjectRepository`, `UndoRedoManager`, `ClipOrdering`), playback (`PlayerManager`), and export (`VideoExporter` plus one small single-purpose file per effect: `ColorMatrixFactory`/`ZarvimoRgbMatrix`, `EffectsFactory`, `TransitionMath`/`FadeToBlackOverlay`, `ConstantSpeedProvider`, `SilenceWavWriter`, `VolumeAudioProcessor`/`FadeAudioProcessor`, `TextOverlayRenderer`/`ImageOverlayRenderer`) are separate, single-purpose modules under `app/src/main/kotlin/com/zarvimo/videoeditor/`. Every file with real Media3 logic is paired with a dependency-free "pure" file holding the actual math (matrix math, transition alpha, WAV header bytes), specifically so that math is unit-testable without Media3 — see "Honesty about what was verified" below.

## Known limitations

These are deliberate, documented scope boundaries — not things that were
forgotten:

- **Overlay burn-in isn't frame-accurate within a clip.** A text or image
  overlay is burned into the exported file for the entire duration of every
  clip it timeline-overlaps, not clipped to its exact start/end time inside
  that clip (the live preview *does* show it at its exact configured time).
  This also doesn't yet account for a clip's own speed when computing that
  overlap window. See `VideoExporter.buildOverlayEffects`'s doc comment.
- **A text overlay's entrance animation (fade in / slide up / pop) previews
  live but is not baked into the exported file** — the export always renders
  the overlay at its fully-settled position/opacity. Animating a burned-in
  overlay needs a time-varying bitmap per frame, which the current "one
  bitmap per clip" overlay architecture doesn't support yet. See
  `TextOverlayRenderer`'s doc comment.
- **Only fade-through-black is offered as a transition.** A true
  cross-dissolve between two clips' actual frames needs multi-source frame
  blending that Media3 Transformer's sequential composition model doesn't
  give directly, so it's intentionally not offered rather than faked.
- **A sped-up/slowed-down clip's own embedded audio is muted on export**
  (0.25x–4x), while the live preview plays that audio pitch-shifted via
  `PlaybackParameters` so scrubbing still has sound. Pairing a video speed
  change with a matching audio speed change in the *exported* file would need
  an uncertain Media3 API combination; muting it in that one file is an
  explicit, documented trade-off rather than a silent gap. Background music
  tracks are unaffected either way. See `ConstantSpeedProvider`'s doc comment.
- **Background audio preview sync is approximate, export sync is exact.**
  Each background track previews on its own `ExoPlayer`, kept roughly in step
  with the primary player by the timeline ticker (correcting drift past
  ~150ms rather than constantly reseeking, which would stutter). The
  *exported* file's audio timing is sample-accurate, built from a generated
  silent WAV placed before the real audio in the same track's Transformer
  sequence. See `PlayerManager`'s and `SilenceWavWriter`'s doc comments.
- **"Merge Videos" and "Reverse Video" are not offered.** Every clip already
  concatenates into one timeline on export, so a separate "merge" step would
  be redundant busywork; true frame-accurate reverse playback isn't something
  Media3 Transformer's sequential composition model gives directly. Both
  remain visible in the UI as clearly-labeled "coming soon" actions rather
  than disappearing or silently doing nothing.
- **True multi-video-track compositing (picture-in-picture video, overlapping
  video layers) isn't implemented** — see the architecture note above. Image
  overlays cover the picture-in-picture/watermark use case without it.

## Editor layout

The editor screen follows the "Zafronix/Zarvimo" branding poster the project
started from: a left tool rail, a large preview with its own transport
controls, and a bottom quick-action strip.

- **Left sidebar** (`EditorSidebarRail`): Media (open the picker), Audio
  (background tracks), Text (overlays), Effects (filters/color/transition),
  Stickers (image overlays), Transform (crop/rotate/flip/speed), Adjust
  (per-clip volume). Every item opens a real, working sheet. Effects and
  Transform operate on the selected clip, so tapping them with nothing
  selected prompts "select a clip on the timeline first" rather than
  appearing dimmed.
- **Preview** (`PreviewPlayerView`): current/total timestamp and prev-clip /
  play-pause / next-clip controls drawn over the bottom of the frame, plus
  the live text and image overlay layers.
- **Top bar**: aspect ratio picker, Undo/Redo, Save.
- **Bottom quick-action strip** (`EditorControlsBar`): Trim & Cut, Delete, Add
  Music, Apply Filters and Slow Motion are all real (the last two jump to the
  Effects/Transform sheets, prompting for a clip selection if needed). Merge
  Videos and Reverse Video remain dimmed "coming soon" placeholders for the
  reasons in "Known limitations" above, never silently doing nothing. Export
  is a full-width gradient button below the strip, standing in for the
  reference's "Download Now" button.

## Project structure

```
zarvimo-video-editor/
├── .github/workflows/android-build.yml   # CI: test + build debug APK on push/dispatch
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── kotlin/com/zarvimo/videoeditor/
│       │   │   ├── MainActivity.kt, ZarvimoApplication.kt
│       │   │   ├── data/            # models (data/model), ProjectRepository, UndoRedoManager, ClipOrdering
│       │   │   ├── playback/        # PlayerManager (ExoPlayer wrapper + synced background-audio players)
│       │   │   ├── export/          # VideoExporter (Media3 Transformer) + one file per effect
│       │   │   ├── navigation/      # ZarvimoNavGraph
│       │   │   ├── util/            # TimeFormat, MediaUtils
│       │   │   └── ui/              # theme, splash, dashboard, picker, editor (screen + sidebar + controls + sheets), shared components
│       │   └── res/                 # colors, strings, themes, launcher icon, splash drawable
│       └── test/kotlin/com/zarvimo/videoeditor/   # unit tests
├── gradle/
│   ├── libs.versions.toml           # version catalog
│   └── wrapper/                     # gradle-wrapper.jar + .properties
├── gradlew / gradlew.bat
├── settings.gradle.kts
├── build.gradle.kts
└── gradle.properties
```

## Building it — phone-friendly, no computer or terminal needed

You only need **one file**: `zarvimo-source.zip`. It is a single, plain zip —
**not** a zip containing another zip — so there's nothing to extract or pick
apart before uploading it. There are two ways to get it into a GitHub repo
and building; pick whichever is easier. Both end with the APK appearing
under your repo's **Releases** tab.

### Option A — easiest on a phone, zero extraction

GitHub does not auto-extract an uploaded zip, but this repo's workflow does
it *for* you on GitHub's own servers, so you never touch a zip file yourself.

1. On github.com, create a **new repository**.
2. Tap **Add file → Create new file**. In the filename box, type the full
   path `.github/workflows/android-build.yml` (typing the slashes makes
   GitHub create those folders automatically). Paste in the workflow code
   below, then **Commit new file**.
3. Go back to the repo's main page → **Add file → Upload files** → choose
   `zarvimo-source.zip` exactly as it was sent to you — **do not extract it
   first** → **Commit changes**.
4. Open the **Actions** tab → **Android Build** → **Run workflow**.
5. Wait for the green checkmark (first run takes ~10–15 minutes). Then open
   your repo's **Releases** (right sidebar on the repo's main page, or
   `github.com/<you>/<repo>/releases`) — the APK is attached there.

> **If a build ever fails at the "Extract project source" step** saying
> `settings.gradle.kts still not found`: it almost always means the wrong
> file got uploaded (e.g. an old zip, or a zip-of-a-zip from an earlier
> delivery) and is still sitting at the repo root. Delete that stray file
> from the repo (its three-dot menu → **Delete file**) and re-upload the
> current `zarvimo-source.zip` from step 3. The extraction step *does*
> tolerate a zip that itself contains another zip (it unwraps up to 5 layers
> automatically), but it can only find one *valid* project — a leftover bad
> file alongside the real one will still confuse it.

### Option B — normal repo, extract once

1. Extract `zarvimo-source.zip` fully (on a computer, or any phone zip app
   that extracts everything at once).
2. Upload the extracted contents — `app/`, `gradle/`, `.github/`,
   `settings.gradle.kts`, `gradlew`, etc. — to a new GitHub repo's root
   (drag-and-drop on desktop, or `git add . && git commit && git push`).
   The workflow's extraction step quietly skips itself when
   `settings.gradle.kts` is already there.
3. Same as Option A from step 4 onward: run the workflow, then check
   **Releases** for the APK.

### The workflow, in full

This is exactly what's committed at `.github/workflows/android-build.yml` —
shown here so you can copy it directly if you're using Option A. The
test → build → upload-artifact → publish-release pipeline itself is
**unchanged from Phase 1**: no new third-party dependency was introduced by
this update (Media3's effect/transformer artifacts, Coil, and
`activity-compose` were already pulled in). Only the very first step — the
one that unpacks an uploaded zip before Gradle runs — was hardened this
round, to also unwrap a zip that itself contains another zip (see the note
in Option A above).

```yaml
name: Android Build

on:
  workflow_dispatch:
  push:
    branches:
      - main

permissions:
  contents: write

jobs:
  build:
    name: Build and release debug APK
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Extract project source (if zipped)
        run: |
          echo "Repository root contents:"
          ls -la

          for i in 1 2 3 4 5; do
            if [ -f settings.gradle.kts ]; then
              echo "settings.gradle.kts found at the repo root — nothing more to extract."
              break
            fi

            ZIP_FILE=$(find . -maxdepth 1 -iname "*.zip" | head -n 1)
            if [ -z "$ZIP_FILE" ]; then
              echo "No zip file found at repo root to extract (pass $i)."
              break
            fi

            echo "Pass $i: extracting $ZIP_FILE"
            unzip -o "$ZIP_FILE" -d .
            rm -f "$ZIP_FILE"
          done

          if [ ! -f settings.gradle.kts ]; then
            NESTED=$(find . -maxdepth 3 -name 'settings.gradle.kts' -print -quit)
            if [ -n "$NESTED" ]; then
              NESTED_DIR=$(dirname "$NESTED")
              echo "Found the project one folder down, in $NESTED_DIR — moving its contents up to the repo root."
              shopt -s dotglob
              mv "$NESTED_DIR"/* .
              shopt -u dotglob
            fi
          fi

          test -f settings.gradle.kts || {
            echo "::error::settings.gradle.kts still not found after extraction. Files currently at repo root:"
            ls -la
            exit 1
          }
          chmod +x gradlew

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"
          cache: gradle

      - name: Accept Android SDK licenses and install required packages
        run: |
          SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
          if [ ! -x "$SDKMANAGER" ]; then
            SDKMANAGER="sdkmanager"
          fi
          yes | "$SDKMANAGER" --licenses || true
          "$SDKMANAGER" "platform-tools" "platforms;android-35" "build-tools;35.0.0"

      - name: Run unit tests
        run: ./gradlew testDebugUnitTest --stacktrace

      - name: Show failing test details
        if: failure()
        run: |
          echo "========== JUnit test reports =========="
          REPORTS=$(find app/build/test-results -name "*.xml" 2>/dev/null)
          if [ -z "$REPORTS" ]; then
            echo "No JUnit XML reports were found — the tests likely never ran because of a compile error. Re-check the 'Run unit tests' step's own log above this one for a Kotlin compiler error."
          else
            for f in $REPORTS; do
              echo "---- $f ----"
              cat "$f"
              echo ""
            done
          fi

      - name: Build debug APK
        run: ./gradlew assembleDebug --stacktrace

      - name: Upload test results
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: unit-test-results
          path: app/build/reports/tests/testDebugUnitTest/
          if-no-files-found: ignore

      - name: Upload debug APK as workflow artifact
        uses: actions/upload-artifact@v4
        with:
          name: zarvimo-debug-apk
          path: app/build/outputs/apk/debug/*.apk
          if-no-files-found: error

      - name: Publish APK to GitHub Releases
        uses: softprops/action-gh-release@v2
        with:
          tag_name: build-${{ github.run_number }}
          name: Zarvimo Debug Build #${{ github.run_number }}
          prerelease: true
          files: app/build/outputs/apk/debug/*.apk
```

Every workflow run creates its own Release (tagged `build-1`, `build-2`, …),
so re-running never overwrites an earlier APK. The APK also stays available
as a 90-day workflow artifact either way, as a backup.

Locally (if you have a computer with a JDK 17 + Android SDK): extract the
zip and run `./gradlew testDebugUnitTest assembleDebug`.

### Honesty about what was verified in this environment

This project was built in a sandboxed environment with **no access to Maven
Central, Google's Maven repository, or the Gradle plugin portal** — only a
small package-manager allowlist and GitHub. That means a full
`./gradlew assembleDebug` (which needs to download the Android Gradle Plugin,
Compose, and Media3 artifacts) could not be run or verified end-to-end here,
for this update any more than for Phase 1. What *was* verified directly, with
the real project files, before packaging:

- **Every pure-Kotlin file — no Android or Media3 dependency — compiles
  cleanly** against the real Kotlin 2.0.21 compiler (extracted from a local
  Gradle 8.14.3 install, matching this project's exact Kotlin version) and
  the real `kotlinx-serialization`/`kotlinx-coroutines` jars: the full data
  model (`data/model/ProjectModels.kt`, including every field added in this
  update), `UndoRedoManager`, the new `ClipOrdering` helper, and the new
  export-side pure-math files `ColorMatrixFactory`, `TransitionMath`, and
  `SilenceWavWriter`.
- **57 unit tests pass** against the real JUnit 4.13.2 runner and the real
  source files in `app/src/test/`, covering: crop/speed clamping and
  timeline-duration math on `VideoClip`; `ColorAdjustment` clamping;
  background-audio fade/volume math and audible-window boundaries on
  `AudioTrackClip`; visibility windows on `ImageOverlay`; entrance-animation
  progress on `TextOverlay`; duplicate-clip and reorder-clip list math in the
  new `ClipOrdering` (including that it sorts by `order` rather than trusting
  list position, matching `Project.orderedClips`'s own guarantee);
  `ColorMatrixFactory`'s actual matrix output (identity case, true-grayscale
  case with luminance weights summing to 1, temperature's red/blue push
  direction, adjustment clamping); `TransitionMath`'s fade-to-black alpha at
  every phase of the ramp, including the overlapping-fades case; and
  `SilenceWavWriter`'s WAV header byte layout plus the real file length it
  produces. Phase 1's original 21 tests (project save/load, clip split,
  reorder/trim/delete, time formatting) still pass unchanged.
- **What's genuinely unverified, honestly, and why:** everything that touches
  Media3's `androidx.media3.effect`/`androidx.media3.transformer` APIs
  directly — `EffectsFactory`, `ZarvimoRgbMatrix`, `ConstantSpeedProvider`,
  `FadeToBlackOverlay`, `ImageOverlayRenderer`, the updated
  `TextOverlayRenderer`, the rewritten `VideoExporter` and `PlayerManager` —
  plus every new or changed Jetpack Compose UI file (`TransformSheet`,
  `FilterColorSheet`, `AudioTrackSheet`, `ImageOverlaySheet`, the updated
  `TextOverlaySheet`/`ExportSheet`/`PreviewPlayerView`/`EditorScreen`/
  `EditorSidebar`/`EditorControlsBar`), could **not** be compiled here: this
  sandbox has no network path to Google's Maven repository, so none of
  `androidx.media3:media3-effect`, `media3-transformer`, or the Jetpack
  Compose artifacts could be downloaded to compile against. These files were
  written carefully from the documented Media3 1.4.1 API surface and
  cross-checked by hand for the exact bug pattern that caused Phase 1's one
  real CI failure (an extension function/property referenced without an
  `import`, or inside the wrong receiver scope) — every `Icons.*` usage, every
  `remember`/`mutableStateOf` delegate, and every `.weight()`/`.align()` call
  in the new and changed UI files was cross-checked against its import and
  its enclosing `Row`/`Column`/`Box` scope by hand. But "written carefully"
  is not the same as "compiled", and the Media3 effects API in particular
  (`Crop`, `ScaleAndRotateTransformation`, `RgbMatrix`, `SpeedChangeEffect`,
  `SpeedProvider`, `OverlaySettings.setAlpha`) is the least certain part of
  this update — if the next CI run hits a compile error, it is most likely
  somewhere in `export/EffectsFactory.kt`, `export/ZarvimoRgbMatrix.kt`, or
  `export/VideoExporter.kt`'s effect-building code, exactly as flagged in
  those files' own doc comments.
- **The Gradle Kotlin DSL files are unchanged and still syntactically valid**
  (no new dependency was added — see "The workflow, in full" above).
- Every `R.string.*` reference in every new and changed Kotlin file was
  cross-checked against `res/values/strings.xml` and all resolve (including
  every string this update added).

What was **not** verified here, and should be checked on the next CI run:
the full dependency resolution and the actual `assembleDebug` output for the
Media3-effects and Compose-UI code described above. The provided GitHub
Actions workflow is the intended way to get that full, real build — please
check its first run, and if it fails, the error will point at one specific
file rather than the whole update, since everything that *could* be checked
offline already was.

#### What caused Phase 1's one real CI failure (for context)

Phase 1 shipped with four compile errors only a real Compose-aware compiler
could catch, all from the same root cause — an extension function/property
referenced without the `import` it needs, or called from outside the
receiver scope it needs:

- `EditorScreen.kt` / `MediaPickerScreen.kt` — `Icons.AutoMirrored.Filled.ArrowBack`
  / `Icons.Filled.Save` used fully-qualified with no `import`; Compose icons
  are extension properties, so qualifying the path alone doesn't resolve
  them. Fixed with the matching `import`.
- `ExportSheet.kt` — `by remember { mutableStateOf(...) }` missing the
  `import androidx.compose.runtime.getValue`/`setValue` the `by` delegate
  syntax needs.
- `TimelineView.kt` — `import androidx.compose.ui.input.pointerInput` pointed
  at the wrong package (missing `.pointer.`), and a private `TrimHandle`
  composable called `Modifier.align(...)` without being declared as a
  `BoxScope` extension itself.

All four were confirmed against the real failing-run logs and fixed; every
other `Icons.*`/`remember`/`pointerInput`/`.align()` usage in the project was
cross-checked at the time to rule out the same mistake elsewhere. This same
checking method — by hand, against every file this update touches — is what
was applied to this update's new UI files too, in lieu of a real compiler.

## Remaining roadmap

- Frame-accurate overlay timing and baked-in text animation in export (see "Known limitations").
- True cross-dissolve transitions, and true multi-video-track compositing (picture-in-picture video).
- Reverse video playback/export.
- Project thumbnails generated from the first frame.
- Waveform display on the timeline for background audio tracks.
- Cloud backup / project sharing.
