# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.kts.

# Keep kotlinx.serialization models used for local project persistence.
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt

-keep,includedescriptorclasses class com.zarvimo.videoeditor.data.model.**$$serializer { *; }
-keepclassmembers class com.zarvimo.videoeditor.data.model.** {
    *** Companion;
}
-keepclasseswithmembers class com.zarvimo.videoeditor.data.model.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Media3 / ExoPlayer
-dontwarn com.google.android.exoplayer2.**
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
