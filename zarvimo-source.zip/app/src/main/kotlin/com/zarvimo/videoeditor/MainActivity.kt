package com.zarvimo.videoeditor

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.navigation.ZarvimoNavGraph
import com.zarvimo.videoeditor.ui.theme.ZarvimoBackground
import com.zarvimo.videoeditor.ui.theme.ZarvimoTheme
import com.zarvimo.videoeditor.util.CrashLogger

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZarvimoTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = ZarvimoBackground
                ) {
                    ZarvimoNavGraph()
                    CrashReportDialog()
                }
            }
        }
    }
}

/**
 * If [CrashLogger] caught and saved a crash from the previous run, this
 * shows it once on launch with a "Share" button (the normal Android share
 * sheet, `ACTION_SEND` with `text/plain`) so the exact exception — cause
 * chain included — can be forwarded as-is instead of retyped from a
 * screenshot of the generic "has stopped" dialog, which strips every detail
 * that actually says what went wrong.
 */
@Composable
private fun CrashReportDialog() {
    val context = LocalContext.current
    var crashLog by remember { mutableStateOf(CrashLogger.readAndClear(context)) }

    val log = crashLog
    if (log != null) {
        // Plain string literals rather than R.string entries: this dialog
        // only ever appears after a crash, when depending on the resources
        // pipeline having also built correctly is the last thing this
        // should risk.
        AlertDialog(
            onDismissRequest = { crashLog = null },
            title = { Text("Zarvimo crashed last time") },
            text = {
                Text(
                    text = log,
                    modifier = Modifier
                        .heightIn(max = 320.dp)
                        .verticalScroll(rememberScrollState())
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, log)
                    }
                    context.startActivity(Intent.createChooser(sendIntent, null))
                    crashLog = null
                }) {
                    Text("Share")
                }
            },
            dismissButton = {
                TextButton(onClick = { crashLog = null }) {
                    Text("Dismiss")
                }
            }
        )
    }
}
