package com.zarvimo.videoeditor

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.zarvimo.videoeditor.util.CrashLogger

/**
 * Coil's default [ImageLoader] only knows how to decode actual image formats
 * (JPEG, PNG, WebP, ...). The video picker grid and the timeline's clip
 * thumbnails both pass a raw video `content://` Uri as an [coil.compose.AsyncImage]
 * model, expecting Coil to pull a representative frame out of it instead —
 * that's what the `coil-video` artifact's [VideoFrameDecoder] is for, but
 * just having the dependency on the classpath does nothing: it has to be
 * registered with the [ImageLoader] Coil actually uses. Without this,
 * [coil.compose.AsyncImage] silently renders nothing for a video Uri (no
 * crash, no error — just an empty box), which is exactly the "thumbnails
 * don't show" symptom this class fixes.
 *
 * Implementing [ImageLoaderFactory] on the [Application] makes Coil use this
 * loader app-wide, so every `AsyncImage(model = someVideoUri)` call site
 * (the picker grid, the timeline) gets working thumbnails without having to
 * repeat this setup at each call site.
 */
class ZarvimoApplication : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        // See CrashLogger's doc comment: this is the one place a crash can
        // be caught and saved to a file before the process dies, so the
        // next launch (MainActivity) can offer it up for sharing instead of
        // the user having no way to hand over more than "it crashed".
        CrashLogger.install(this)
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components { add(VideoFrameDecoder.Factory()) }
            .build()
}
