package com.zarvimo.videoeditor.data

import com.zarvimo.videoeditor.data.model.VideoClip
import java.util.UUID

/**
 * Pure list-reordering helpers shared by [com.zarvimo.videoeditor.ui.editor.EditorViewModel]'s
 * duplicate/reorder clip operations. Kept dependency-free (no Android/Media3)
 * so the reindexing math itself is directly unit-testable — see
 * [com.zarvimo.videoeditor.ClipOrderingTest] — independent of the ViewModel
 * it's used from, which can't be unit-tested in this sandbox (it extends
 * Android's own `AndroidViewModel`).
 */
object ClipOrdering {

    /**
     * Inserts a copy of the clip with [clipId] immediately after it,
     * renumbering every clip's [VideoClip.order] to match its new position so
     * [com.zarvimo.videoeditor.data.model.Project.orderedClips] stays
     * contiguous. Returns [clips] unchanged if [clipId] isn't found.
     */
    fun withDuplicate(
        clips: List<VideoClip>,
        clipId: String,
        newId: () -> String = { UUID.randomUUID().toString() }
    ): List<VideoClip> {
        val ordered = clips.sortedBy { it.order }
        val index = ordered.indexOfFirst { it.id == clipId }
        if (index < 0) return clips
        val copy = ordered[index].copy(id = newId())
        val result = ordered.toMutableList()
        result.add(index + 1, copy)
        return result.mapIndexed { i, clip -> clip.copy(order = i) }
    }

    /**
     * Moves the clip currently at order-position [fromIndex] to [toIndex],
     * renumbering every clip's order to match. Returns [clips] unchanged if
     * either index is out of range.
     */
    fun withReorder(clips: List<VideoClip>, fromIndex: Int, toIndex: Int): List<VideoClip> {
        val ordered = clips.sortedBy { it.order }.toMutableList()
        if (fromIndex !in ordered.indices || toIndex !in ordered.indices) return clips
        val moved = ordered.removeAt(fromIndex)
        ordered.add(toIndex, moved)
        return ordered.mapIndexed { i, clip -> clip.copy(order = i) }
    }
}
