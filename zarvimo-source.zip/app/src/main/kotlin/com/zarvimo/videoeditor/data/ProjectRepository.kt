package com.zarvimo.videoeditor.data

import android.content.Context
import com.zarvimo.videoeditor.data.model.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Local-only project persistence: every [Project] is serialized to its own
 * pretty-printed JSON file under `filesDir/projects/<id>.json`. No cloud sync
 * in Phase 1 — this is intentionally simple so project files stay human
 * readable and easy to inspect/back up.
 */
class ProjectRepository(context: Context) {

    private val appContext = context.applicationContext

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val projectsDir: File
        get() = File(appContext.filesDir, "projects").apply { if (!exists()) mkdirs() }

    /** Where exported video files should be written; created on first access. */
    val exportsDir: File
        get() = File(appContext.filesDir, "exports").apply { if (!exists()) mkdirs() }

    /** Where generated clip/project thumbnails are cached; safe to clear at any time. */
    val thumbnailsDir: File
        get() = File(appContext.cacheDir, "thumbnails").apply { if (!exists()) mkdirs() }

    private fun fileFor(projectId: String) = File(projectsDir, "$projectId.json")

    suspend fun save(project: Project): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val toSave = project.copy(updatedAtMillis = System.currentTimeMillis())
            val text = json.encodeToString(toSave)
            val target = fileFor(project.id)
            val tmp = File(projectsDir, "${project.id}.json.tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(target)) {
                // Fall back to a direct write if the atomic rename fails (e.g. cross-filesystem).
                target.writeText(text)
                tmp.delete()
            }
        }
    }

    suspend fun load(projectId: String): Result<Project> = withContext(Dispatchers.IO) {
        runCatching {
            val file = fileFor(projectId)
            require(file.exists()) { "Project $projectId was not found on disk" }
            json.decodeFromString<Project>(file.readText())
        }
    }

    suspend fun listAll(): List<Project> = withContext(Dispatchers.IO) {
        projectsDir.listFiles { f -> f.isFile && f.extension == "json" }
            ?.mapNotNull { f -> runCatching { json.decodeFromString<Project>(f.readText()) }.getOrNull() }
            ?.sortedByDescending { it.updatedAtMillis }
            ?: emptyList()
    }

    suspend fun delete(projectId: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val file = fileFor(projectId)
            if (file.exists() && !file.delete()) {
                error("Could not delete project file for $projectId")
            }
        }
    }
}
