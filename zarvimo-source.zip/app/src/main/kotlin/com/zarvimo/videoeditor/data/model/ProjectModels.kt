package com.zarvimo.videoeditor.data.model

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * A single Zarvimo project: an ordered sequence of trimmed, transformed video
 * clips on the primary track, plus independent overlay layers — background
 * audio tracks, image overlays, and text overlays — and export preferences.
 * This is the full state that gets persisted to disk (see ProjectRepository)
 * and that UndoRedoManager snapshots on every edit.
 *
 * Every field added after Phase 1 has a default, so an old project JSON file
 * (saved before these fields existed) still deserializes correctly: missing
 * fields simply take their default value. See ProjectModelsTest for a
 * round-trip test against a Phase-1-shaped JSON string.
 */
@Serializable
data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis(),
    val clips: List<VideoClip> = emptyList(),
    val audioTracks: List<AudioTrackClip> = emptyList(),
    val imageOverlays: List<ImageOverlay> = emptyList(),
    val textOverlays: List<TextOverlay> = emptyList(),
    val aspectRatio: AspectRatio = AspectRatio.RATIO_16_9,
    val exportQuality: ExportQuality = ExportQuality.HD_1080,
    val exportFrameRate: ExportFrameRate = ExportFrameRate.FPS_30,
    val thumbnailUri: String? = null
) {
    /**
     * Total timeline duration in microseconds: the primary track's clip
     * sequence, or a later-ending background audio track if one runs past it
     * (e.g. music added after the last video clip's end).
     */
    val totalDurationUs: Long
        get() {
            val videoEnd = clips.sumOf { it.trimmedDurationUs }
            val audioEnd = audioTracks.maxOfOrNull { it.endOnTimelineUs } ?: 0L
            return maxOf(videoEnd, audioEnd)
        }

    /** Clips in timeline order, regardless of how [clips] happens to be stored. */
    val orderedClips: List<VideoClip>
        get() = clips.sortedBy { it.order }

    companion object {
        fun newEmpty(name: String): Project = Project(name = name)
    }
}

/**
 * One source video trimmed to an in/out range and placed at [order] in the
 * timeline's primary track, with its transform, color and filter settings.
 * Durations and trim points are stored in microseconds to match Media3's
 * [androidx.media3.common.MediaItem.ClippingConfiguration] units directly, so the
 * playback and export layers can use these values with no conversion.
 *
 * [cropLeftFraction]/[cropTopFraction]/[cropRightFraction]/[cropBottomFraction]
 * describe a crop rectangle as fractions of the *source* frame (0f..1f, left
 * < right and top < bottom), so it survives changes to export resolution.
 * The default (0,0,1,1) crops nothing.
 */
@Serializable
data class VideoClip(
    val id: String = UUID.randomUUID().toString(),
    val sourceUri: String,
    val sourceDurationUs: Long,
    val trimStartUs: Long = 0L,
    val trimEndUs: Long = sourceDurationUs,
    val volume: Float = 1f,
    val order: Int,
    val thumbnailUri: String? = null,
    val displayName: String = "Clip",
    val cropLeftFraction: Float = 0f,
    val cropTopFraction: Float = 0f,
    val cropRightFraction: Float = 1f,
    val cropBottomFraction: Float = 1f,
    /** Clockwise rotation in quarter turns: 0, 1 (90°), 2 (180°) or 3 (270°). */
    val rotationQuarterTurns: Int = 0,
    val flipHorizontal: Boolean = false,
    val flipVertical: Boolean = false,
    /** Playback speed multiplier. 1.0 = normal. Clamped to [MIN_SPEED]..[MAX_SPEED] by [withSpeed]. */
    val speed: Float = 1f,
    val colorAdjustment: ColorAdjustment = ColorAdjustment(),
    val filter: VideoFilterType = VideoFilterType.NONE,
    /** Transition played between the END of this clip and the start of the next one. */
    val transitionOut: TransitionType = TransitionType.NONE,
    val transitionDurationUs: Long = DEFAULT_TRANSITION_DURATION_US
) {
    val trimmedDurationUs: Long
        get() = (trimEndUs - trimStartUs).coerceAtLeast(0L)

    /**
     * This clip's contribution to the timeline once [speed] is applied — e.g.
     * a 10s clip at 2x speed occupies 5s of timeline. Playback/export use the
     * *source* trimmed range at the adjusted rate; this is what the timeline
     * UI and [Project.totalDurationUs] should measure against.
     */
    val timelineDurationUs: Long
        get() = (trimmedDurationUs / speed.coerceAtLeast(MIN_SPEED)).toLong()

    /** Returns a copy trimmed to a new [newStartUs]..[newEndUs] range, clamped to the source. */
    fun withTrim(newStartUs: Long, newEndUs: Long): VideoClip {
        val clampedStart = newStartUs.coerceIn(0L, sourceDurationUs)
        val clampedEnd = newEndUs.coerceIn(clampedStart, sourceDurationUs)
        return copy(trimStartUs = clampedStart, trimEndUs = clampedEnd)
    }

    /** Returns a copy with [speed] clamped to a sane, exportable range. */
    fun withSpeed(newSpeed: Float): VideoClip = copy(speed = newSpeed.coerceIn(MIN_SPEED, MAX_SPEED))

    /** Returns a copy with a crop rectangle clamped to a valid, non-empty region. */
    fun withCrop(left: Float, top: Float, right: Float, bottom: Float): VideoClip {
        val clampedLeft = left.coerceIn(0f, 0.95f)
        val clampedTop = top.coerceIn(0f, 0.95f)
        val clampedRight = right.coerceIn(clampedLeft + 0.05f, 1f)
        val clampedBottom = bottom.coerceIn(clampedTop + 0.05f, 1f)
        return copy(
            cropLeftFraction = clampedLeft,
            cropTopFraction = clampedTop,
            cropRightFraction = clampedRight,
            cropBottomFraction = clampedBottom
        )
    }

    /** True if this clip has no crop applied (the full source frame is used). */
    val hasCrop: Boolean
        get() = cropLeftFraction > 0f || cropTopFraction > 0f || cropRightFraction < 1f || cropBottomFraction < 1f

    companion object {
        const val MIN_SPEED = 0.25f
        const val MAX_SPEED = 4.0f
        const val DEFAULT_TRANSITION_DURATION_US = 500_000L
    }
}

/**
 * Brightness/contrast/saturation/temperature, each on a -1f..1f scale where
 * 0f is "no change". Combined into a single 4x4 color matrix by
 * [com.zarvimo.videoeditor.export.ColorMatrixFactory], shared by the live
 * preview (applied per-clip via `ExoPlayer.setVideoEffects`) and export
 * (applied via a Media3 `RgbMatrix` effect), so what you see while editing
 * matches what gets exported.
 */
@Serializable
data class ColorAdjustment(
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    val temperature: Float = 0f
) {
    val isIdentity: Boolean
        get() = brightness == 0f && contrast == 0f && saturation == 0f && temperature == 0f

    fun clamped(): ColorAdjustment = ColorAdjustment(
        brightness = brightness.coerceIn(-1f, 1f),
        contrast = contrast.coerceIn(-1f, 1f),
        saturation = saturation.coerceIn(-1f, 1f),
        temperature = temperature.coerceIn(-1f, 1f)
    )
}

/**
 * A curated set of real, implementable color-matrix filters (see
 * [com.zarvimo.videoeditor.export.ColorMatrixFactory]) — every entry here is
 * backed by an actual matrix, never a label with no effect behind it.
 */
@Serializable
enum class VideoFilterType(val label: String) {
    NONE("None"),
    VIVID("Vivid"),
    MONO("Mono"),
    SEPIA("Sepia"),
    COOL("Cool"),
    WARM("Warm"),
    FADE("Fade"),
    NOIR("Noir")
}

/**
 * Transitions played between adjacent clips. Only [FADE_THROUGH_BLACK] is
 * implemented in this phase (a real alpha-ramped black overlay at the clip
 * boundary, applied identically in preview and export) — a true cross-dissolve
 * between two clips' frames needs multi-source frame blending that Media3
 * Transformer's sequential composition model doesn't give us directly, so
 * it's intentionally not offered here rather than faked.
 */
@Serializable
enum class TransitionType(val label: String) {
    NONE("None"),
    FADE_THROUGH_BLACK("Fade to black")
}

/**
 * An independently-timed background audio track (e.g. music) layered under
 * the primary video track. [startOnTimelineUs] is where it starts on the
 * *timeline* (not necessarily 0), independent of any video clip boundary.
 */
@Serializable
data class AudioTrackClip(
    val id: String = UUID.randomUUID().toString(),
    val sourceUri: String,
    val sourceDurationUs: Long,
    val trimStartUs: Long = 0L,
    val trimEndUs: Long = sourceDurationUs,
    val startOnTimelineUs: Long = 0L,
    val volume: Float = 1f,
    val fadeInUs: Long = 0L,
    val fadeOutUs: Long = 0L,
    val displayName: String = "Audio"
) {
    val trimmedDurationUs: Long
        get() = (trimEndUs - trimStartUs).coerceAtLeast(0L)

    val endOnTimelineUs: Long
        get() = startOnTimelineUs + trimmedDurationUs

    fun isAudibleAt(positionUs: Long): Boolean = positionUs in startOnTimelineUs until endOnTimelineUs

    /**
     * Effective volume at [positionUs] on the timeline, ramping in/out over
     * [fadeInUs]/[fadeOutUs] at the clip's edges. Returns 0f outside the
     * clip's range.
     */
    fun effectiveVolumeAt(positionUs: Long): Float {
        if (!isAudibleAt(positionUs)) return 0f
        val sinceStart = positionUs - startOnTimelineUs
        val untilEnd = endOnTimelineUs - positionUs
        val fadeInFactor = if (fadeInUs > 0L) (sinceStart.toFloat() / fadeInUs).coerceIn(0f, 1f) else 1f
        val fadeOutFactor = if (fadeOutUs > 0L) (untilEnd.toFloat() / fadeOutUs).coerceIn(0f, 1f) else 1f
        return volume * minOf(fadeInFactor, fadeOutFactor)
    }

    fun withTrim(newStartUs: Long, newEndUs: Long): AudioTrackClip {
        val clampedStart = newStartUs.coerceIn(0L, sourceDurationUs)
        val clampedEnd = newEndUs.coerceIn(clampedStart, sourceDurationUs)
        return copy(trimStartUs = clampedStart, trimEndUs = clampedEnd)
    }
}

/**
 * A timed image overlay (sticker/picture-in-picture/watermark), positioned
 * and sized as fractions of the frame so it survives resolution changes.
 */
@Serializable
data class ImageOverlay(
    val id: String = UUID.randomUUID().toString(),
    val sourceUri: String,
    val startTimeUs: Long,
    val endTimeUs: Long,
    val xFraction: Float = 0.5f,
    val yFraction: Float = 0.5f,
    val widthFraction: Float = 0.3f,
    val heightFraction: Float = 0.3f,
    val rotationDegrees: Float = 0f,
    val opacity: Float = 1f
) {
    fun isVisibleAt(positionUs: Long): Boolean = positionUs in startTimeUs until endTimeUs
}

/**
 * A timed text overlay, burned into the export and previewed live over the
 * player. Position is stored as fractions of the frame (0f..1f) so it
 * survives changes to [AspectRatio] or export resolution without re-authoring.
 */
@Serializable
data class TextOverlay(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val colorArgb: Int,
    val startTimeUs: Long,
    val endTimeUs: Long,
    val xFraction: Float = 0.5f,
    val yFraction: Float = 0.85f,
    val fontSizeSp: Float = 28f,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val backgroundColorArgb: Int? = null,
    val animation: TextAnimation = TextAnimation.NONE
) {
    fun isVisibleAt(positionUs: Long): Boolean = positionUs in startTimeUs until endTimeUs

    /**
     * 0f..1f progress through this overlay's entrance animation window
     * ([TextAnimation.ANIMATION_WINDOW_US] long), 1f once fully settled or
     * for [TextAnimation.NONE]. The preview and the export's bitmap renderer
     * both use this so the burned-in text animates the same way it previewed.
     */
    fun animationProgressAt(positionUs: Long): Float {
        if (animation == TextAnimation.NONE) return 1f
        val sinceStart = positionUs - startTimeUs
        return (sinceStart.toFloat() / TextAnimation.ANIMATION_WINDOW_US).coerceIn(0f, 1f)
    }
}

@Serializable
enum class TextAnimation(val label: String) {
    NONE("None"),
    FADE_IN("Fade in"),
    SLIDE_UP("Slide up"),
    POP("Pop");

    companion object {
        const val ANIMATION_WINDOW_US = 350_000L
    }
}

@Serializable
enum class AspectRatio(val widthRatio: Int, val heightRatio: Int, val label: String) {
    RATIO_16_9(16, 9, "16:9"),
    RATIO_9_16(9, 16, "9:16"),
    RATIO_1_1(1, 1, "1:1"),
    RATIO_4_3(4, 3, "4:3");

    val ratio: Float get() = widthRatio.toFloat() / heightRatio.toFloat()
}

@Serializable
enum class ExportQuality(val targetHeight: Int, val videoBitrate: Int, val label: String) {
    SD_720(720, 6_000_000, "720p"),
    HD_1080(1080, 12_000_000, "1080p"),
    UHD_4K(2160, 40_000_000, "4K")
}

@Serializable
enum class ExportFrameRate(val fps: Int, val label: String) {
    FPS_24(24, "24 fps"),
    FPS_30(30, "30 fps"),
    FPS_60(60, "60 fps")
}
