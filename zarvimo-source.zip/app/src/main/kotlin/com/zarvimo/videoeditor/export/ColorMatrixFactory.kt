package com.zarvimo.videoeditor.export

import com.zarvimo.videoeditor.data.model.ColorAdjustment
import com.zarvimo.videoeditor.data.model.VideoFilterType

/**
 * Pure math: combines a [ColorAdjustment] and a [VideoFilterType] into a
 * single 4x4 RGBA color matrix, column-major (OpenGL convention), meant to be
 * multiplied against a frame's `(r, g, b, a)` column vector. Deliberately has
 * **no dependency on Media3** so it can be unit-tested with a plain JUnit
 * runner the same way the rest of this project's business logic is — see
 * [com.zarvimo.videoeditor.ColorMatrixFactoryTest]. The only Media3-specific
 * part (adapting this into an actual GPU effect) lives in [ZarvimoRgbMatrix],
 * which is intentionally tiny so there's as little unverified surface as
 * possible if the real Media3 effects API turns out to differ from what this
 * was written against.
 *
 * The matrix assumes frames are fully opaque (alpha = 1), which is true for
 * ordinary decoded video — the 4th column of the matrix is what lets a
 * strictly-linear 4x4 multiply also express brightness/temperature's
 * *additive* offset (output = M · (r, g, b, 1)).
 */
object ColorMatrixFactory {

    /** Standard luminance (perceived brightness) weights, used to desaturate toward gray. */
    private const val LUMA_R = 0.299f
    private const val LUMA_G = 0.587f
    private const val LUMA_B = 0.114f

    fun buildMatrix(adjustment: ColorAdjustment, filter: VideoFilterType): FloatArray {
        val combined = adjustment.clamped().combineWith(filter)
        return matrixFor(combined)
    }

    /** A filter is just a preset [ColorAdjustment] plus an optional fixed tint, merged additively/multiplicatively with the user's own adjustment. */
    private fun ColorAdjustment.combineWith(filter: VideoFilterType): ResolvedAdjustment {
        val preset = presetFor(filter)
        return ResolvedAdjustment(
            brightness = (brightness + preset.brightness).coerceIn(-1f, 1f),
            contrast = (contrast + preset.contrast).coerceIn(-1f, 1f),
            saturation = (saturation + preset.saturation).coerceIn(-1f, 1f),
            temperature = (temperature + preset.temperature).coerceIn(-1f, 1f),
            grayscale = preset.grayscale
        )
    }

    private fun presetFor(filter: VideoFilterType): ResolvedAdjustment = when (filter) {
        VideoFilterType.NONE -> ResolvedAdjustment()
        VideoFilterType.VIVID -> ResolvedAdjustment(saturation = 0.45f, contrast = 0.15f)
        VideoFilterType.MONO -> ResolvedAdjustment(saturation = -1f, grayscale = true)
        VideoFilterType.SEPIA -> ResolvedAdjustment(saturation = -0.6f, temperature = 0.5f, brightness = 0.05f)
        VideoFilterType.COOL -> ResolvedAdjustment(temperature = -0.35f, saturation = 0.1f)
        VideoFilterType.WARM -> ResolvedAdjustment(temperature = 0.35f, saturation = 0.1f)
        VideoFilterType.FADE -> ResolvedAdjustment(contrast = -0.25f, saturation = -0.3f, brightness = 0.08f)
        VideoFilterType.NOIR -> ResolvedAdjustment(saturation = -1f, contrast = 0.3f, grayscale = true)
    }

    private data class ResolvedAdjustment(
        val brightness: Float = 0f,
        val contrast: Float = 0f,
        val saturation: Float = 0f,
        val temperature: Float = 0f,
        val grayscale: Boolean = false
    )

    /**
     * Builds the combined matrix. Order of operations (saturation, then
     * contrast, then brightness/temperature as a final additive pass) mirrors
     * how most photo-editing pipelines apply these so stacked adjustments
     * look like what a user would expect from a slider-based editor.
     */
    private fun matrixFor(a: ResolvedAdjustment): FloatArray {
        val saturationAmount = if (a.grayscale) -1f else a.saturation
        // Saturation: lerp each channel between the frame's luminance and its
        // original value by (1 + saturationAmount). At -1 every output channel
        // collapses to the luminance weights (true grayscale); at 0, identity.
        val satScale = 1f + saturationAmount
        val satKeep = satScale
        val satAdd = 1f - satScale

        // Each output channel = satKeep*original + satAdd*luminance(r,g,b), expressed
        // per-row as a linear combination of r,g,b.
        var m00 = satKeep + satAdd * LUMA_R
        var m01 = satAdd * LUMA_G
        var m02 = satAdd * LUMA_B
        var m10 = satAdd * LUMA_R
        var m11 = satKeep + satAdd * LUMA_G
        var m12 = satAdd * LUMA_B
        var m20 = satAdd * LUMA_R
        var m21 = satAdd * LUMA_G
        var m22 = satKeep + satAdd * LUMA_B

        // Contrast: scale every channel around the 0.5 midpoint.
        val contrastScale = 1f + a.contrast
        m00 *= contrastScale; m01 *= contrastScale; m02 *= contrastScale
        m10 *= contrastScale; m11 *= contrastScale; m12 *= contrastScale
        m20 *= contrastScale; m21 *= contrastScale; m22 *= contrastScale
        val contrastOffset = (1f - contrastScale) * 0.5f

        // Brightness: a flat additive offset on every channel.
        val brightnessOffset = a.brightness * 0.5f

        // Temperature: push red up / blue down for warm (positive), the reverse for cool.
        val warmOffset = a.temperature * 0.3f

        val m03 = contrastOffset + brightnessOffset + warmOffset
        val m13 = contrastOffset + brightnessOffset
        val m23 = contrastOffset + brightnessOffset - warmOffset

        // Column-major 4x4: columns are [r-row, g-row, b-row, a-row], each a
        // 4-float column; alpha passes through unchanged (identity row 3).
        return floatArrayOf(
            m00, m10, m20, 0f,
            m01, m11, m21, 0f,
            m02, m12, m22, 0f,
            m03, m13, m23, 1f
        )
    }
}
