package com.zarvimo.videoeditor.export

import androidx.media3.common.C
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.common.util.UnstableApi

/**
 * The simplest possible [SpeedProvider]: one constant speed for an entire
 * clip, never changing. Paired with `androidx.media3.effect.SpeedChangeEffect`
 * in [VideoExporter] to bake a clip's speed setting into the exported file's
 * video track.
 *
 * This — along with the rest of speed-change export support — is one of the
 * least-certain pieces of this update (see the README's honesty section):
 * it's written from recollection of the Media3 1.4.1 effects API without
 * being checked against a real compiler here. **In this pass, a sped clip's
 * own audio is muted on export** (see `VideoExporter.buildEditedMediaItem`)
 * rather than also attempting a matching audio-speed change, since getting
 * video and audio speed APIs subtly out of sync would be worse than no audio
 * at all on that clip; background music tracks are unaffected.
 */
@UnstableApi
class ConstantSpeedProvider(private val speed: Float) : SpeedProvider {
    override fun getSpeed(timeUs: Long): Float = speed
    override fun getNextSpeedChangeTimeUs(timeUs: Long): Long = C.TIME_UNSET
}
