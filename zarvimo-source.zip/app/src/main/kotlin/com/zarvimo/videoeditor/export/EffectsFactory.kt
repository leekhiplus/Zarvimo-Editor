package com.zarvimo.videoeditor.export

import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Crop
import androidx.media3.effect.ScaleAndRotateTransformation
import com.zarvimo.videoeditor.data.model.VideoClip
import com.zarvimo.videoeditor.data.model.VideoFilterType

/**
 * Builds the ordered list of Media3 video [Effect]s for one [VideoClip]'s
 * crop/rotation/flip/color-adjustment/filter — shared by the live preview
 * ([com.zarvimo.videoeditor.playback.PlayerManager], via `ExoPlayer.setVideoEffects`)
 * and export ([VideoExporter]), so what's previewed is what gets rendered.
 *
 * Like [ZarvimoRgbMatrix], this file is written from the Media3 1.4.1
 * `androidx.media3.effect` API surface without being checked against a real
 * compiler in this sandbox (see that file's doc comment, and the README's
 * honesty section, for why). [Crop] and [ScaleAndRotateTransformation] are
 * both long-standing, commonly-referenced Media3 Transformer effect classes,
 * so this is comparatively lower-risk than the custom [ZarvimoRgbMatrix] —
 * but it's still unverified here.
 */
@UnstableApi
object EffectsFactory {

    fun buildVideoEffects(clip: VideoClip): List<Effect> {
        val effects = mutableListOf<Effect>()

        if (clip.hasCrop) {
            effects += cropEffect(clip)
        }

        if (clip.rotationQuarterTurns != 0 || clip.flipHorizontal || clip.flipVertical) {
            effects += scaleAndRotateEffect(clip)
        }

        if (!clip.colorAdjustment.isIdentity || clip.filter != VideoFilterType.NONE) {
            effects += ZarvimoRgbMatrix(clip.colorAdjustment, clip.filter)
        }

        return effects
    }

    /**
     * [Crop]'s coordinates are normalized device coordinates (-1..1, origin at
     * frame center, +y up) — Zarvimo's own crop fractions are (0..1, origin at
     * top-left, +y down), matching how the crop UI draws a rectangle over the
     * preview. This converts between the two.
     */
    private fun cropEffect(clip: VideoClip): Crop {
        val ndcLeft = clip.cropLeftFraction * 2f - 1f
        val ndcRight = clip.cropRightFraction * 2f - 1f
        val ndcTop = (1f - clip.cropTopFraction) * 2f - 1f
        val ndcBottom = (1f - clip.cropBottomFraction) * 2f - 1f
        return Crop(ndcLeft, ndcBottom, ndcRight, ndcTop)
    }

    private fun scaleAndRotateEffect(clip: VideoClip): ScaleAndRotateTransformation {
        val scaleX = if (clip.flipHorizontal) -1f else 1f
        val scaleY = if (clip.flipVertical) -1f else 1f
        val degrees = clip.rotationQuarterTurns * 90f
        return ScaleAndRotateTransformation.Builder()
            .setScale(scaleX, scaleY)
            .setRotationDegrees(degrees)
            .build()
    }
}
