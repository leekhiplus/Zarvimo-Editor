package com.zarvimo.videoeditor.export

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Like [VolumeAudioProcessor], but ramps amplitude linearly in over
 * [fadeInUs] at the start of the stream and out over [fadeOutUs] at the end,
 * on top of a constant [volume] factor. Used for background audio tracks,
 * which (unlike a video clip's own embedded audio) commonly want a fade so
 * music doesn't start or stop abruptly under the video.
 *
 * Fade timing is measured in *processed samples* against [totalDurationUs]
 * (the track's own trimmed duration, not the project timeline), since this
 * processor only ever sees one track's PCM stream.
 */
class FadeAudioProcessor(
    private val volume: Float,
    private val fadeInUs: Long,
    private val fadeOutUs: Long,
    private val totalDurationUs: Long
) : BaseAudioProcessor() {

    private var sampleRate: Int = 0
    private var channelCount: Int = 0
    private var framesProcessed: Long = 0L

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        sampleRate = inputAudioFormat.sampleRate
        channelCount = inputAudioFormat.channelCount
        framesProcessed = 0L
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0 || sampleRate == 0 || channelCount == 0) return

        val input = inputBuffer.asReadOnlyBuffer().order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val outputBuffer = replaceOutputBuffer(remaining)
        val output = outputBuffer.asShortBuffer()

        val frameSizeBytes = channelCount * 2
        val totalFrames = remaining / frameSizeBytes

        for (frame in 0 until totalFrames) {
            val frameTimeUs = ((framesProcessed + frame) * 1_000_000L) / sampleRate
            val factor = volume * fadeFactorAt(frameTimeUs)
            for (channel in 0 until channelCount) {
                val scaled = (input.get() * factor)
                    .toInt()
                    .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                output.put(scaled.toShort())
            }
        }
        framesProcessed += totalFrames

        inputBuffer.position(inputBuffer.limit())
    }

    private fun fadeFactorAt(timeUs: Long): Float {
        val fadeInFactor = if (fadeInUs > 0L) (timeUs.toFloat() / fadeInUs).coerceIn(0f, 1f) else 1f
        val remainingUs = totalDurationUs - timeUs
        val fadeOutFactor = if (fadeOutUs > 0L) (remainingUs.toFloat() / fadeOutUs).coerceIn(0f, 1f) else 1f
        return minOf(fadeInFactor, fadeOutFactor)
    }

    override fun isActive(): Boolean = volume != 1f || fadeInUs > 0L || fadeOutUs > 0L
}
