package com.zarvimo.videoeditor.export

import android.graphics.Bitmap
import android.graphics.Color
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlaySettings

/**
 * A solid black full-frame bitmap whose *alpha* is computed per-frame from
 * [TransitionMath.blackOverlayAlpha] — the Media3-facing half of Zarvimo's
 * fade-through-black transition. [clipStartPresentationTimeUs] is this clip's
 * own first frame's presentation time *within its EditedMediaItem* (Media3
 * reports `presentationTimeUs` relative to the item's own clipped start, not
 * the project timeline, so no extra offset bookkeeping is needed here).
 */
class FadeToBlackOverlay(
    widthPx: Int,
    heightPx: Int,
    private val clipDurationUs: Long,
    private val fadeInFromBlack: Boolean,
    private val fadeOutToBlack: Boolean,
    private val transitionDurationUs: Long
) : BitmapOverlay() {

    private val blackBitmap: Bitmap = Bitmap.createBitmap(
        widthPx.coerceAtLeast(1),
        heightPx.coerceAtLeast(1),
        Bitmap.Config.ARGB_8888
    ).apply { eraseColor(Color.BLACK) }

    override fun getBitmap(presentationTimeUs: Long): Bitmap = blackBitmap

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val alpha = TransitionMath.blackOverlayAlpha(
            positionInClipUs = presentationTimeUs,
            clipDurationUs = clipDurationUs,
            fadeInFromBlack = fadeInFromBlack,
            fadeOutToBlack = fadeOutToBlack,
            transitionDurationUs = transitionDurationUs
        )
        return OverlaySettings.Builder().setAlpha(alpha).build()
    }
}
