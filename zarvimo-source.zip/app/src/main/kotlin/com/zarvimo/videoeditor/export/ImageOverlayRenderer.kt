package com.zarvimo.videoeditor.export

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import com.zarvimo.videoeditor.data.model.ImageOverlay

/**
 * Loads an [ImageOverlay]'s source image and composites it onto a
 * transparent, frame-sized bitmap at its authored position/size/rotation/
 * opacity — the same "bake the exact on-screen placement into the bitmap"
 * approach [com.zarvimo.videoeditor.export.TextOverlayRenderer] uses for text,
 * so both overlay types share the same [androidx.media3.effect.OverlayEffect]
 * compositing path in [VideoExporter].
 */
object ImageOverlayRenderer {

    fun render(context: Context, overlay: ImageOverlay, widthPx: Int, heightPx: Int): Bitmap? {
        val source = runCatching {
            context.contentResolver.openInputStream(Uri.parse(overlay.sourceUri))?.use {
                android.graphics.BitmapFactory.decodeStream(it)
            }
        }.getOrNull() ?: return null

        val frame = Bitmap.createBitmap(
            widthPx.coerceAtLeast(1),
            heightPx.coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(frame)

        val targetWidth = (overlay.widthFraction.coerceIn(0.02f, 1f)) * widthPx
        val targetHeight = (overlay.heightFraction.coerceIn(0.02f, 1f)) * heightPx
        val centerX = overlay.xFraction.coerceIn(0f, 1f) * widthPx
        val centerY = overlay.yFraction.coerceIn(0f, 1f) * heightPx

        val matrix = Matrix().apply {
            val scaleX = targetWidth / source.width.coerceAtLeast(1)
            val scaleY = targetHeight / source.height.coerceAtLeast(1)
            postScale(scaleX, scaleY)
            postTranslate(centerX - targetWidth / 2f, centerY - targetHeight / 2f)
            postRotate(overlay.rotationDegrees, centerX, centerY)
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            alpha = (overlay.opacity.coerceIn(0f, 1f) * 255).toInt()
        }
        canvas.drawBitmap(source, matrix, paint)
        return frame
    }
}
