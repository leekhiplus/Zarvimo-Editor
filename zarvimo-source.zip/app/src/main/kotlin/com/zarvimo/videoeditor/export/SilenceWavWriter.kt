package com.zarvimo.videoeditor.export

import java.io.File
import java.io.RandomAccessFile

/**
 * Writes a minimal, valid silent mono 16-bit PCM WAV file of an exact
 * duration. Used to delay a background audio track's start within an export
 * [androidx.media3.transformer.EditedMediaItemSequence]: Transformer plays a
 * sequence's items strictly back-to-back with no separate "start offset"
 * knob, so a silent clip placed before the real audio is how Zarvimo gives a
 * background track a non-zero start time on the timeline — the exact same
 * "sequence of items" mechanism already used for the primary video track's
 * clips, just with a generated silent one.
 *
 * Deliberately plain `java.io` file writing with no Media3/Android
 * dependency, so the WAV header math itself is unit-testable (see
 * [com.zarvimo.videoeditor.SilenceWavWriterTest]) independent of whether the
 * file actually gets consumed correctly by Transformer.
 */
object SilenceWavWriter {
    private const val SAMPLE_RATE = 44_100
    private const val BITS_PER_SAMPLE = 16
    private const val CHANNELS = 1
    private const val BYTE_RATE = SAMPLE_RATE * CHANNELS * BITS_PER_SAMPLE / 8

    /** Builds the 44-byte canonical WAV header for [durationUs] of silence. */
    fun buildWavHeader(durationUs: Long): ByteArray {
        val durationSeconds = durationUs.coerceAtLeast(0L) / 1_000_000.0
        val dataSize = (durationSeconds * BYTE_RATE).toLong().coerceAtLeast(0L)
        val header = ByteArray(44)

        fun writeAscii(offset: Int, text: String) {
            text.forEachIndexed { i, c -> header[offset + i] = c.code.toByte() }
        }
        fun writeLeInt(offset: Int, value: Long) {
            header[offset] = (value and 0xFF).toByte()
            header[offset + 1] = ((value shr 8) and 0xFF).toByte()
            header[offset + 2] = ((value shr 16) and 0xFF).toByte()
            header[offset + 3] = ((value shr 24) and 0xFF).toByte()
        }
        fun writeLeShort(offset: Int, value: Int) {
            header[offset] = (value and 0xFF).toByte()
            header[offset + 1] = ((value shr 8) and 0xFF).toByte()
        }

        writeAscii(0, "RIFF")
        writeLeInt(4, dataSize + 36)
        writeAscii(8, "WAVE")
        writeAscii(12, "fmt ")
        writeLeInt(16, 16) // fmt chunk size
        writeLeShort(20, 1) // PCM
        writeLeShort(22, CHANNELS)
        writeLeInt(24, SAMPLE_RATE.toLong())
        writeLeInt(28, BYTE_RATE.toLong())
        writeLeShort(32, CHANNELS * BITS_PER_SAMPLE / 8) // block align
        writeLeShort(34, BITS_PER_SAMPLE)
        writeAscii(36, "data")
        writeLeInt(40, dataSize)

        return header
    }

    /** Writes a silent WAV file of [durationUs] into [directory] and returns it. */
    fun writeSilence(directory: File, durationUs: Long, fileName: String = "zarvimo_silence_${System.nanoTime()}.wav"): File {
        directory.mkdirs()
        val file = File(directory, fileName)
        val header = buildWavHeader(durationUs)
        val dataSize = header.sliceArray(40..43).let { b ->
            (b[0].toLong() and 0xFF) or
                ((b[1].toLong() and 0xFF) shl 8) or
                ((b[2].toLong() and 0xFF) shl 16) or
                ((b[3].toLong() and 0xFF) shl 24)
        }
        RandomAccessFile(file, "rw").use { raf ->
            raf.write(header)
            // Silence is all-zero bytes; seeking to extend the file is far
            // cheaper than writing dataSize zero bytes by hand for a long track.
            if (dataSize > 0L) {
                raf.seek(44L + dataSize - 1)
                raf.write(0)
            }
        }
        return file
    }
}
