package com.zarvimo.videoeditor.export

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import com.zarvimo.videoeditor.data.model.TextOverlay

/**
 * Rasterizes one [TextOverlay] onto a transparent, frame-sized bitmap so it
 * can be composited back into the video via Media3's overlay effect. Baking
 * the exact on-screen position into the bitmap itself (rather than relying on
 * an overlay-positioning API) keeps the export path's dependency on Media3's
 * newer effects surface as small as possible.
 *
 * Bold/italic and an optional background chip are baked in exactly as
 * authored. [TextOverlay.animation] is a **preview-only** effect: the live
 * preview (see `PreviewPlayerView`) animates the overlay in with
 * [TextOverlay.animationProgressAt], but the exported file bakes one static
 * bitmap per clip (see [com.zarvimo.videoeditor.export.VideoExporter]'s own
 * doc comment on that same limitation), so the entrance animation itself
 * does not appear in the exported video — it always renders at its fully
 * settled position/opacity there. This is a deliberate scope boundary, not
 * an oversight: animating a burned-in overlay would need a time-varying
 * bitmap per frame, which the current "one bitmap per clip" overlay
 * architecture doesn't support yet.
 */
object TextOverlayRenderer {

    fun render(overlay: TextOverlay, widthPx: Int, heightPx: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(
            widthPx.coerceAtLeast(1),
            heightPx.coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)

        val style = when {
            overlay.bold && overlay.italic -> Typeface.BOLD_ITALIC
            overlay.bold -> Typeface.BOLD
            overlay.italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = overlay.colorArgb
            // Scale the authored font size relative to a 720px-tall reference frame,
            // so overlays look the same proportion of the frame at any export quality.
            textSize = overlay.fontSizeSp * (heightPx / 720f)
            typeface = Typeface.create(Typeface.DEFAULT, style)
            textAlign = Paint.Align.CENTER
            setShadowLayer(8f, 0f, 2f, 0x99000000.toInt())
        }
        val x = (overlay.xFraction.coerceIn(0f, 1f)) * widthPx
        val y = (overlay.yFraction.coerceIn(0f, 1f)) * heightPx

        if (overlay.backgroundColorArgb != null) {
            val bounds = Rect()
            paint.getTextBounds(overlay.text, 0, overlay.text.length, bounds)
            val paddingPx = paint.textSize * 0.35f
            val backgroundRect = RectF(
                x - bounds.width() / 2f - paddingPx,
                y + bounds.top - paddingPx,
                x + bounds.width() / 2f + paddingPx,
                y + bounds.bottom + paddingPx
            )
            val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = overlay.backgroundColorArgb
            }
            canvas.drawRoundRect(backgroundRect, paddingPx, paddingPx, backgroundPaint)
        }

        canvas.drawText(overlay.text, x, y, paint)
        return bitmap
    }
}
