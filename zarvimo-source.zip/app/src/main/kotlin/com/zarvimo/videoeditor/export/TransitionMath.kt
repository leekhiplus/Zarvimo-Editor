package com.zarvimo.videoeditor.export

/**
 * Pure math for [com.zarvimo.videoeditor.data.model.TransitionType.FADE_THROUGH_BLACK]:
 * given a position within a clip, how opaque should the black overlay be?
 * Kept dependency-free (no Android/Media3 types) so it's directly
 * unit-testable — see [com.zarvimo.videoeditor.TransitionMathTest]. The thin
 * Media3/Bitmap adapter around this lives in [FadeToBlackOverlay].
 */
object TransitionMath {

    /**
     * @param positionInClipUs how far into this clip's trimmed duration we are
     * @param clipDurationUs this clip's trimmed duration
     * @param fadeInFromBlack true if the *previous* clip ends with a fade-through-black
     *   transition, so this clip should open from black
     * @param fadeOutToBlack true if *this* clip's own [transitionOut][com.zarvimo.videoeditor.data.model.VideoClip.transitionOut]
     *   is a fade-through-black, so it should close to black
     * @return the black overlay's opacity: 1f = fully black, 0f = fully transparent (no overlay)
     */
    fun blackOverlayAlpha(
        positionInClipUs: Long,
        clipDurationUs: Long,
        fadeInFromBlack: Boolean,
        fadeOutToBlack: Boolean,
        transitionDurationUs: Long
    ): Float {
        if (transitionDurationUs <= 0L) return 0f
        var alpha = 0f

        if (fadeInFromBlack) {
            val t = (positionInClipUs.toFloat() / transitionDurationUs).coerceIn(0f, 1f)
            alpha = maxOf(alpha, 1f - t)
        }
        if (fadeOutToBlack) {
            val remaining = clipDurationUs - positionInClipUs
            val t = (remaining.toFloat() / transitionDurationUs).coerceIn(0f, 1f)
            alpha = maxOf(alpha, 1f - t)
        }
        return alpha.coerceIn(0f, 1f)
    }
}
