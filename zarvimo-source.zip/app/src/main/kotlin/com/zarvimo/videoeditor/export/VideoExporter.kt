package com.zarvimo.videoeditor.export

import android.content.Context
import android.net.Uri
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.TransformationRequest
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import com.zarvimo.videoeditor.data.model.AudioTrackClip
import com.zarvimo.videoeditor.data.model.Project
import com.zarvimo.videoeditor.data.model.TransitionType
import com.zarvimo.videoeditor.data.model.VideoClip
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed interface ExportState {
    data object Idle : ExportState
    data class InProgress(val progressPercent: Int) : ExportState
    data class Completed(val outputFile: File) : ExportState
    data class Failed(val message: String) : ExportState
}

/**
 * Renders a [Project] to a single H.264/AAC MP4 using Media3 Transformer.
 *
 * - The primary video track is one [EditedMediaItemSequence] built from
 *   [Project.orderedClips]; trim in/out and concatenation come from
 *   [MediaItem.ClippingConfiguration], crop/rotate/flip/color/filter/speed
 *   from [EffectsFactory] + [ZarvimoRgbMatrix] + [ConstantSpeedProvider], and
 *   a fade-through-black transition from [FadeToBlackOverlay].
 * - Each background [AudioTrackClip] is its own audio-only sequence, composed
 *   alongside the primary one (Media3 Transformer mixes every sequence in a
 *   [Composition] together); [SilenceWavWriter] gives a track a non-zero
 *   start time by prepending generated silence, and [FadeAudioProcessor]
 *   applies its volume/fade.
 * - Text and image overlays are burned in via one [OverlayEffect] per clip,
 *   combining [TextOverlayRenderer] and [ImageOverlayRenderer] bitmaps.
 *   Phase 1 limitation (still present): an overlay is burned in for the full
 *   duration of every clip it timeline-overlaps, not frame-accurately
 *   clipped to its exact start/end time inside that clip — see
 *   [buildOverlayEffects]. This also doesn't yet account for a clip's own
 *   speed change when computing that overlap window (see the README).
 *
 * **Honesty note:** the crop/rotate/flip/color/filter/speed/transition/
 * multi-track-audio pieces added in this pass (everything in [EffectsFactory],
 * [ZarvimoRgbMatrix], [ConstantSpeedProvider], [FadeToBlackOverlay], and the
 * audio-sequence code below) could not be checked against a real compiler in
 * this sandbox — see the README's honesty section for exactly what that
 * means and what to do if the next CI run hits a compile error here.
 */
@UnstableApi
class VideoExporter(private val context: Context) {

    private val _state = MutableStateFlow<ExportState>(ExportState.Idle)
    val state: StateFlow<ExportState> = _state.asStateFlow()

    private var transformer: Transformer? = null
    private var progressJob: Job? = null

    fun export(project: Project, outputFile: File, scope: CoroutineScope, destinationUri: Uri? = null) {
        if (project.clips.isEmpty()) {
            _state.value = ExportState.Failed("Nothing to export: add at least one clip")
            return
        }

        outputFile.parentFile?.mkdirs()
        if (outputFile.exists()) outputFile.delete()

        val sequences = buildSequences(project)
        val composition = Composition.Builder(ImmutableList.copyOf(sequences)).build()

        val transformationRequest = TransformationRequest.Builder()
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .build()

        val builtTransformer = Transformer.Builder(context)
            .setTransformationRequest(transformationRequest)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    stopProgressPolling()
                    transformer = null
                    if (destinationUri != null) copyToDestination(outputFile, destinationUri)
                    _state.value = ExportState.Completed(outputFile)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    stopProgressPolling()
                    transformer = null
                    _state.value = ExportState.Failed(exportException.message ?: "Export failed")
                }
            })
            .build()

        transformer = builtTransformer
        _state.value = ExportState.InProgress(0)
        builtTransformer.start(composition, outputFile.absolutePath)
        startProgressPolling(builtTransformer, scope)
    }

    fun cancel() {
        stopProgressPolling()
        transformer?.cancel()
        transformer = null
        _state.value = ExportState.Idle
    }

    /**
     * Best-effort copy of the finished file to a user-chosen
     * Storage-Access-Framework destination (from the export sheet's
     * "Choose where to save" picker). The local [outputFile] remains the
     * source of truth for the share-sheet flow either way, so a failure here
     * doesn't fail the export itself — it's surfaced by leaving the state as
     * [ExportState.Completed] regardless, since the export *did* succeed.
     */
    private fun copyToDestination(outputFile: File, destinationUri: Uri) {
        runCatching {
            context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                outputFile.inputStream().use { input -> input.copyTo(out) }
            }
        }
    }

    private fun startProgressPolling(activeTransformer: Transformer, scope: CoroutineScope) {
        stopProgressPolling()
        progressJob = scope.launch {
            val holder = ProgressHolder()
            while (true) {
                val status = activeTransformer.getProgress(holder)
                when (status) {
                    Transformer.PROGRESS_STATE_AVAILABLE ->
                        _state.value = ExportState.InProgress(holder.progress)
                    Transformer.PROGRESS_STATE_NOT_STARTED -> return@launch
                    else -> Unit
                }
                delay(PROGRESS_POLL_INTERVAL_MS)
            }
        }
    }

    private fun stopProgressPolling() {
        progressJob?.cancel()
        progressJob = null
    }

    // ---------------------------------------------------------------------
    // Primary video sequence
    // ---------------------------------------------------------------------

    private fun buildSequences(project: Project): List<EditedMediaItemSequence> {
        val sequences = mutableListOf<EditedMediaItemSequence>()
        sequences += buildPrimarySequence(project)
        project.audioTracks.forEach { track -> sequences += buildAudioSequence(track) }
        return sequences
    }

    private fun buildPrimarySequence(project: Project): EditedMediaItemSequence {
        val ordered = project.orderedClips
        val items = ordered.mapIndexed { index, clip ->
            val previous = ordered.getOrNull(index - 1)
            val fadeInFromBlack = previous?.transitionOut == TransitionType.FADE_THROUGH_BLACK
            val fadeOutToBlack = clip.transitionOut == TransitionType.FADE_THROUGH_BLACK
            buildEditedMediaItem(clip, project, fadeInFromBlack, fadeOutToBlack)
        }
        return EditedMediaItemSequence(ImmutableList.copyOf(items))
    }

    private fun buildEditedMediaItem(
        clip: VideoClip,
        project: Project,
        fadeInFromBlack: Boolean,
        fadeOutToBlack: Boolean
    ): EditedMediaItem {
        val mediaItem = MediaItem.Builder()
            .setUri(clip.sourceUri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionUs(clip.trimStartUs)
                    .setEndPositionUs(clip.trimEndUs)
                    .build()
            )
            .build()

        // A sped-up/slowed-down clip's own audio is muted on export rather than
        // also attempting a matching audio-speed change — see ConstantSpeedProvider's
        // doc comment for why. Background music tracks are unaffected.
        val audioProcessors: List<AudioProcessor> = when {
            clip.speed != 1f -> listOf(VolumeAudioProcessor(0f))
            clip.volume != 1f -> listOf(VolumeAudioProcessor(clip.volume))
            else -> emptyList()
        }

        val targetHeight = project.exportQuality.targetHeight
        val targetWidth = (targetHeight * project.aspectRatio.ratio).toInt().coerceAtLeast(2)

        val videoEffects = mutableListOf<Effect>()
        videoEffects += EffectsFactory.buildVideoEffects(clip)
        videoEffects += Presentation.createForHeight(targetHeight)
        if (clip.speed != 1f) {
            videoEffects += SpeedChangeEffect(ConstantSpeedProvider(clip.speed))
        }
        videoEffects += buildOverlayEffects(clip, project, fadeInFromBlack, fadeOutToBlack, targetWidth, targetHeight)

        return EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(audioProcessors, videoEffects))
            .build()
    }

    /**
     * Phase 1 limitation, still present: overlays are burned in for the entire
     * duration of every clip whose timeline window they overlap, not
     * frame-accurately trimmed to their exact start/end time inside that
     * clip (the live preview *does* show overlays at their exact configured
     * time range). This window calculation also doesn't yet account for a
     * clip's own [VideoClip.speed] — it's computed against the clip's
     * trimmed *source* duration, which only matches its on-screen timeline
     * duration when speed is 1x. A text/image overlay timed over a sped-up
     * or slowed-down clip may land at the wrong moment within that clip in
     * the exported file until this is revisited.
     */
    private fun buildOverlayEffects(
        clip: VideoClip,
        project: Project,
        fadeInFromBlack: Boolean,
        fadeOutToBlack: Boolean,
        targetWidth: Int,
        targetHeight: Int
    ): List<Effect> {
        val clipTimelineStart = project.orderedClips
            .takeWhile { it.id != clip.id }
            .sumOf { it.trimmedDurationUs }
        val clipTimelineEnd = clipTimelineStart + clip.trimmedDurationUs

        val overlappingText = project.textOverlays.filter { overlay ->
            overlay.startTimeUs < clipTimelineEnd && overlay.endTimeUs > clipTimelineStart
        }
        val overlappingImages = project.imageOverlays.filter { overlay ->
            overlay.startTimeUs < clipTimelineEnd && overlay.endTimeUs > clipTimelineStart
        }

        val overlays = mutableListOf<androidx.media3.effect.TextureOverlay>()
        overlappingText.forEach { overlay ->
            overlays += StaticTextBitmapOverlay(TextOverlayRenderer.render(overlay, targetWidth, targetHeight))
        }
        overlappingImages.forEach { overlay ->
            ImageOverlayRenderer.render(context, overlay, targetWidth, targetHeight)?.let {
                overlays += StaticTextBitmapOverlay(it)
            }
        }
        if (fadeInFromBlack || fadeOutToBlack) {
            overlays += FadeToBlackOverlay(
                widthPx = targetWidth,
                heightPx = targetHeight,
                clipDurationUs = clip.trimmedDurationUs,
                fadeInFromBlack = fadeInFromBlack,
                fadeOutToBlack = fadeOutToBlack,
                transitionDurationUs = clip.transitionDurationUs
            )
        }

        if (overlays.isEmpty()) return emptyList()
        return listOf(OverlayEffect(ImmutableList.copyOf(overlays)))
    }

    // ---------------------------------------------------------------------
    // Background audio track sequences
    // ---------------------------------------------------------------------

    private fun buildAudioSequence(track: AudioTrackClip): EditedMediaItemSequence {
        val items = mutableListOf<EditedMediaItem>()

        if (track.startOnTimelineUs > 0L) {
            val silenceFile = SilenceWavWriter.writeSilence(context.cacheDir, track.startOnTimelineUs)
            items += EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(silenceFile)))
                .setRemoveVideo(true)
                .build()
        }

        val mediaItem = MediaItem.Builder()
            .setUri(track.sourceUri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionUs(track.trimStartUs)
                    .setEndPositionUs(track.trimEndUs)
                    .build()
            )
            .build()

        val audioProcessors: List<AudioProcessor> =
            if (track.volume != 1f || track.fadeInUs > 0L || track.fadeOutUs > 0L) {
                listOf(FadeAudioProcessor(track.volume, track.fadeInUs, track.fadeOutUs, track.trimmedDurationUs))
            } else emptyList()

        items += EditedMediaItem.Builder(mediaItem)
            .setRemoveVideo(true)
            .setEffects(Effects(audioProcessors, emptyList()))
            .build()

        return EditedMediaItemSequence(ImmutableList.copyOf(items))
    }

    private companion object {
        const val PROGRESS_POLL_INTERVAL_MS = 200L
    }
}

/** Adapts a pre-rendered [android.graphics.Bitmap] (text or image overlay) to Media3's overlay effect. */
private class StaticTextBitmapOverlay(
    private val bitmap: android.graphics.Bitmap
) : androidx.media3.effect.BitmapOverlay() {
    override fun getBitmap(presentationTimeUs: Long): android.graphics.Bitmap = bitmap
    override fun getOverlaySettings(presentationTimeUs: Long): androidx.media3.effect.OverlaySettings =
        androidx.media3.effect.OverlaySettings.Builder().build()
}
