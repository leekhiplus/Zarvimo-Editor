package com.zarvimo.videoeditor.export

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Scales 16-bit PCM sample amplitude by a constant [volume] factor
 * (0f = silent, 1f = unchanged, >1f = amplified, clamped to the 16-bit range
 * to avoid wraparound distortion). This is how a clip's volume slider gets
 * baked into the exported file: Media3 Transformer has no per-clip volume
 * knob of its own, only a composable chain of [AudioProcessor]s attached to
 * each [androidx.media3.transformer.EditedMediaItem]'s [androidx.media3.transformer.Effects].
 */
class VolumeAudioProcessor(private val volume: Float) : BaseAudioProcessor() {

    override fun onConfigure(
        inputAudioFormat: AudioProcessor.AudioFormat
    ): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        // Pass the format straight through; only sample amplitude changes.
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        val input = inputBuffer.asReadOnlyBuffer().order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val outputBuffer = replaceOutputBuffer(remaining)
        val output = outputBuffer.asShortBuffer()

        while (input.hasRemaining()) {
            val scaled = (input.get() * volume)
                .toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            output.put(scaled.toShort())
        }

        inputBuffer.position(inputBuffer.limit())
        // outputBuffer was sized to exactly `remaining` bytes and fully written above,
        // so it is already positioned correctly (0, limit=remaining) for the base class
        // to read back — no flip() needed since we never advanced its own position.
    }

    override fun isActive(): Boolean = volume != 1f
}
