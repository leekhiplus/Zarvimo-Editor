package com.zarvimo.videoeditor.export

import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.RgbMatrix
import com.zarvimo.videoeditor.data.model.ColorAdjustment
import com.zarvimo.videoeditor.data.model.VideoFilterType

/**
 * The one Media3-specific line in Zarvimo's color pipeline: adapts the pure,
 * fully-unit-tested [ColorMatrixFactory] output to Media3's `RgbMatrix`
 * effect interface, which the GPU effects pipeline queries once per frame.
 *
 * This file — along with [EffectsFactory] — is the part of this project's
 * color/transform/filter support that could **not** be checked against a
 * real compiler in this sandbox (no network access to fetch Media3
 * artifacts). It was written from the Media3 1.4.1 `androidx.media3.effect`
 * API surface as documented/sampled at training time; if it doesn't compile
 * as-is, the fix is almost certainly confined to this one small file.
 */
@UnstableApi
class ZarvimoRgbMatrix(
    private val adjustment: ColorAdjustment,
    private val filter: VideoFilterType
) : RgbMatrix {
    private val matrix: FloatArray = ColorMatrixFactory.buildMatrix(adjustment, filter)

    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray = matrix
}
