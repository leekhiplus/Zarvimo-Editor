package com.zarvimo.videoeditor.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.zarvimo.videoeditor.ui.dashboard.DashboardScreen
import com.zarvimo.videoeditor.ui.editor.EditorScreen
import com.zarvimo.videoeditor.ui.picker.MediaPickerScreen
import com.zarvimo.videoeditor.ui.splash.SplashScreen

/** All Zarvimo navigation routes in one place, so a route string is never typed twice. */
object ZarvimoDestinations {
    const val SPLASH = "splash"
    const val DASHBOARD = "dashboard"
    const val EDITOR = "editor/{projectId}"
    const val PICKER = "picker"

    fun editorRoute(projectId: String) = "editor/$projectId"
}

/** The key [MediaPickerScreen] writes picked clip Uris to on the editor's back
 * stack entry, and [EditorScreen] reads them back from — see the Navigation
 * Compose "returning a result" pattern via [androidx.navigation.NavBackStackEntry.savedStateHandle]. */
const val PICKED_URIS_KEY = "picked_uris"

@Composable
fun ZarvimoNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = ZarvimoDestinations.SPLASH) {
        composable(ZarvimoDestinations.SPLASH) {
            SplashScreen(
                onFinished = {
                    navController.navigate(ZarvimoDestinations.DASHBOARD) {
                        popUpTo(ZarvimoDestinations.SPLASH) { inclusive = true }
                    }
                }
            )
        }

        composable(ZarvimoDestinations.DASHBOARD) {
            DashboardScreen(
                onOpenProject = { projectId ->
                    navController.navigate(ZarvimoDestinations.editorRoute(projectId))
                }
            )
        }

        composable(
            route = ZarvimoDestinations.EDITOR,
            arguments = listOf(navArgument("projectId") { type = NavType.StringType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getString("projectId")
            if (projectId != null) {
                EditorScreen(
                    projectId = projectId,
                    navBackStackEntry = backStackEntry,
                    onBack = { navController.popBackStack() },
                    onOpenMediaPicker = { navController.navigate(ZarvimoDestinations.PICKER) }
                )
            }
        }

        composable(ZarvimoDestinations.PICKER) {
            MediaPickerScreen(
                onBack = { navController.popBackStack() },
                onVideosSelected = { uris ->
                    navController.previousBackStackEntry
                        ?.savedStateHandle
                        ?.set(PICKED_URIS_KEY, uris.map { it.toString() })
                    navController.popBackStack()
                }
            )
        }
    }
}
