package com.zarvimo.videoeditor.playback

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.zarvimo.videoeditor.data.model.AudioTrackClip
import com.zarvimo.videoeditor.data.model.Project
import com.zarvimo.videoeditor.data.model.VideoClip
import com.zarvimo.videoeditor.export.EffectsFactory
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Wraps the primary [ExoPlayer] instance (the trimmed, ordered video timeline)
 * and keeps it, plus one secondary [ExoPlayer] per background [AudioTrackClip],
 * in sync with the current project.
 *
 * Each [VideoClip] becomes one [MediaItem] whose
 * [MediaItem.ClippingConfiguration] encodes its trim in/out, so the primary
 * player's own concatenated playlist *is* the trimmed timeline: scrubbing and
 * playback across clip boundaries are handled by ExoPlayer directly rather
 * than by manually swapping sources.
 *
 * **Live preview vs. export, honestly:**
 * - Crop/rotate/flip/color/filter preview uses [ExoPlayer.setVideoEffects]
 *   with the exact same [EffectsFactory] the export path uses, so what's
 *   previewed is what's exported for those.
 * - Speed preview uses [PlaybackParameters] (a stable, well-documented
 *   ExoPlayer API) rather than the export path's `SpeedChangeEffect` — this
 *   is a deliberate, lower-risk choice for live playback, but it means a
 *   sped clip's audio pitch shifts and plays audibly *in preview*, while the
 *   exported file mutes that clip's audio entirely (see
 *   `ConstantSpeedProvider`'s doc comment for why export takes that
 *   stricter approach). The on-screen speed itself matches between preview
 *   and export either way.
 * - Background audio tracks preview on their own [ExoPlayer] per track,
 *   driven by the timeline ticker: each one seeks/plays/pauses/mutes to
 *   track the primary player's position, correcting drift past
 *   [AUDIO_SYNC_DRIFT_THRESHOLD_MS] rather than reseeking every tick (which
 *   would stutter). This is sample-accurate in the exported file (via
 *   [com.zarvimo.videoeditor.export.SilenceWavWriter]) but only
 *   approximately synced in preview, which is standard for a two-player
 *   preview approach and not something this sandbox could improve without
 *   a real device to measure drift on.
 */
@UnstableApi
class PlayerManager(
    context: Context,
    private val scope: CoroutineScope
) {
    private val appContext = context.applicationContext

    val player: ExoPlayer = ExoPlayer.Builder(appContext).build()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    /** Playhead position in the *timeline's* coordinate space, in microseconds:
     * the sum of preceding clips' trimmed durations plus the offset into the
     * current clip. This is the value the timeline UI should scrub against. */
    private val _positionUs = MutableStateFlow(0L)
    val positionUs: StateFlow<Long> = _positionUs.asStateFlow()

    private val _currentClipIndex = MutableStateFlow(0)
    val currentClipIndex: StateFlow<Int> = _currentClipIndex.asStateFlow()

    private val _playbackError = MutableStateFlow<String?>(null)
    val playbackError: StateFlow<String?> = _playbackError.asStateFlow()

    private var clips: List<VideoClip> = emptyList()
    private var audioTracks: List<AudioTrackClip> = emptyList()
    private var audioTrackPlayers: List<ExoPlayer> = emptyList()
    private var tickerJob: Job? = null

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                if (isPlaying) {
                    startTicker()
                } else {
                    stopTicker()
                    audioTrackPlayers.forEach { it.pause() }
                }
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                _currentClipIndex.value = player.currentMediaItemIndex
                applyCurrentClipPreviewState()
                publishPosition()
                syncAudioTracksToPosition(force = true)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                _currentClipIndex.value = player.currentMediaItemIndex
                applyCurrentClipPreviewState()
            }

            override fun onPlayerError(error: PlaybackException) {
                _playbackError.value = error.message ?: "Playback error"
            }
        })
    }

    /**
     * Rebuilds the primary playlist from [project]'s ordered clips and the
     * secondary audio-track players from its background tracks. Call this
     * after any edit that changes clips, audio tracks, a trim range, or the
     * order. When [preservePosition] is true (the default), Zarvimo tries to
     * keep the playhead on the same clip and offset it was on before the edit.
     *
     * Rebuilding means handing Media3 a fresh [MediaItem] per clip —
     * including, for a freshly imported file, one it has never tried to open
     * before. A bad/huge/oddly-encoded file can make any of these calls
     * throw synchronously (as opposed to the *async* playback errors
     * [Player.Listener.onPlayerError] already catches below), and an
     * uncaught exception here — on the main thread, from a ViewModel action
     * as ordinary as "add a clip" — was taking the whole app down rather
     * than just failing that one operation. This wraps the whole rebuild so
     * such a failure becomes a [_playbackError] message (shown as a
     * Snackbar) instead of a crash.
     */
    fun loadProject(project: Project, preservePosition: Boolean = true) {
        _playbackError.value = null
        try {
            val newClips = project.orderedClips
            val previousClipId = clips.getOrNull(player.currentMediaItemIndex)?.id
            val previousOffsetUs = player.currentPosition * 1000L

            clips = newClips
            player.setMediaItems(newClips.map { it.toMediaItem() })
            player.prepare()

            rebuildAudioTrackPlayers(project.audioTracks)

            if (preservePosition && previousClipId != null) {
                val newIndex = newClips.indexOfFirst { it.id == previousClipId }
                if (newIndex >= 0) {
                    val clampedUs = previousOffsetUs.coerceIn(0L, newClips[newIndex].trimmedDurationUs)
                    player.seekTo(newIndex, clampedUs / 1000L)
                }
            }
            _currentClipIndex.value = player.currentMediaItemIndex
            applyCurrentClipPreviewState()
            publishPosition()
            syncAudioTracksToPosition(force = true)
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            _playbackError.value = t.message ?: "Couldn't load this project into the player (${t.javaClass.simpleName})"
        }
    }

    private fun rebuildAudioTrackPlayers(tracks: List<AudioTrackClip>) {
        audioTrackPlayers.forEach { it.release() }
        audioTracks = tracks
        audioTrackPlayers = tracks.map { track ->
            ExoPlayer.Builder(appContext).build().apply {
                setMediaItem(track.toMediaItem())
                prepare()
                playWhenReady = false
            }
        }
    }

    /**
     * Mirrors the current clip's volume slider, crop/rotate/flip/color/filter,
     * and speed during live preview. ExoPlayer's own [Player.setVolume] only
     * accepts 0f..1f (attenuation, no amplification), so a clip volume above
     * 1f previews at full volume and only actually gets amplified in the
     * exported file, where [com.zarvimo.videoeditor.export.VolumeAudioProcessor]
     * applies the exact factor to the PCM samples.
     *
     * Unlike [loadProject], this also runs from [Player.Listener] callbacks
     * (clip transitions, seeks) outside of any caller's try/catch, so it
     * guards itself the same way: a bad call into [EffectsFactory] here must
     * not crash the app mid-playback.
     */
    private fun applyCurrentClipPreviewState() {
        try {
            applyCurrentClipPreviewStateUnsafe()
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            _playbackError.value = t.message ?: "Couldn't apply this clip's preview effects (${t.javaClass.simpleName})"
        }
    }

    private fun applyCurrentClipPreviewStateUnsafe() {
        val clip = clips.getOrNull(player.currentMediaItemIndex) ?: return
        player.volume = clip.volume.coerceIn(0f, 1f)
        player.setVideoEffects(EffectsFactory.buildVideoEffects(clip))
        player.playbackParameters = PlaybackParameters(clip.speed.coerceIn(VideoClip.MIN_SPEED, VideoClip.MAX_SPEED))
    }

    // Media3's ClippingConfiguration requires endPositionUs to be strictly
    // greater than startPositionUs (or the special "end of source" value);
    // a zero-length or inverted window throws when the player prepares that
    // item. That should never happen by construction, but a clip whose
    // duration couldn't be read (see EditorViewModel.addClips) or some other
    // future bug could still produce trimStartUs == trimEndUs — so this
    // builds a plain, unclipped MediaItem instead of letting an invalid
    // clipping window reach ExoPlayer and crash the app.
    private fun VideoClip.toMediaItem(): MediaItem {
        val builder = MediaItem.Builder()
            .setMediaId(id)
            .setUri(sourceUri)
        if (trimEndUs > trimStartUs) {
            builder.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionUs(trimStartUs)
                    .setEndPositionUs(trimEndUs)
                    .build()
            )
        }
        return builder.build()
    }

    private fun AudioTrackClip.toMediaItem(): MediaItem {
        val builder = MediaItem.Builder()
            .setMediaId(id)
            .setUri(sourceUri)
        if (trimEndUs > trimStartUs) {
            builder.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionUs(trimStartUs)
                    .setEndPositionUs(trimEndUs)
                    .build()
            )
        }
        return builder.build()
    }

    fun play() = player.play()
    fun pause() = player.pause()
    fun playPause() {
        if (player.isPlaying) player.pause() else player.play()
    }

    /** Seeks to an absolute position on the trimmed timeline, in microseconds. */
    fun seekToTimelineUs(timelineUs: Long) {
        if (clips.isEmpty()) return
        var remaining = timelineUs.coerceAtLeast(0L)
        for ((index, clip) in clips.withIndex()) {
            val duration = clip.trimmedDurationUs
            if (remaining <= duration || index == clips.lastIndex) {
                player.seekTo(index, remaining.coerceIn(0L, duration) / 1000L)
                publishPosition()
                syncAudioTracksToPosition(force = true)
                return
            }
            remaining -= duration
        }
    }

    fun timelinePositionUs(): Long {
        var base = 0L
        val idx = player.currentMediaItemIndex
        for (i in 0 until idx) base += clips.getOrNull(i)?.trimmedDurationUs ?: 0L
        return base + player.currentPosition * 1000L
    }

    private fun publishPosition() {
        _positionUs.value = timelinePositionUs()
    }

    /**
     * Keeps every background audio track's secondary player in step with the
     * primary player's timeline position: audible tracks play (muting/fading
     * via [AudioTrackClip.effectiveVolumeAt]), inaudible ones pause. Only
     * reseeks a track when it has drifted more than
     * [AUDIO_SYNC_DRIFT_THRESHOLD_MS] (or [force] is set, e.g. right after a
     * scrub) so ordinary playback doesn't stutter from constant reseeking.
     */
    private fun syncAudioTracksToPosition(force: Boolean = false) {
        val timelineUs = timelinePositionUs()
        audioTracks.forEachIndexed { index, track ->
            val exo = audioTrackPlayers.getOrNull(index) ?: return@forEachIndexed
            if (track.isAudibleAt(timelineUs)) {
                val withinTrackUs = (timelineUs - track.startOnTimelineUs).coerceAtLeast(0L)
                val targetMs = withinTrackUs / 1000L
                exo.volume = track.effectiveVolumeAt(timelineUs).coerceIn(0f, 1f)
                if (force || abs(exo.currentPosition - targetMs) > AUDIO_SYNC_DRIFT_THRESHOLD_MS) {
                    exo.seekTo(targetMs)
                }
                if (_isPlaying.value && !exo.isPlaying) exo.play()
            } else if (exo.isPlaying) {
                exo.pause()
            }
        }
    }

    private fun startTicker() {
        stopTicker()
        tickerJob = scope.launch {
            while (true) {
                publishPosition()
                syncAudioTracksToPosition()
                delay(TICK_INTERVAL_MS)
            }
        }
    }

    private fun stopTicker() {
        tickerJob?.cancel()
        tickerJob = null
    }

    fun release() {
        stopTicker()
        audioTrackPlayers.forEach { it.release() }
        audioTrackPlayers = emptyList()
        player.release()
    }

    private companion object {
        /** ~15fps playhead refresh: smooth enough for scrubbing UI without excess recomposition. */
        const val TICK_INTERVAL_MS = 66L

        /** Beyond this many ms of drift, a background track is reseeked rather than left to catch up on its own. */
        const val AUDIO_SYNC_DRIFT_THRESHOLD_MS = 150L
    }
}
