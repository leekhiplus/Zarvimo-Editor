package com.zarvimo.videoeditor.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.ui.theme.ZarvimoGradientColors
import com.zarvimo.videoeditor.ui.theme.ZarvimoSurfaceElevated
import com.zarvimo.videoeditor.ui.theme.ZarvimoSurfaceVariant
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextPrimary

/** The neon diagonal gradient used for primary CTAs and headline accents. */
val ZarvimoGradientBrush: Brush
    @Composable get() = Brush.linearGradient(ZarvimoGradientColors)

/** A filled, gradient-background CTA button — Zarvimo's primary action style. */
@Composable
fun NeonGradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .background(
                    brush = if (enabled) ZarvimoGradientBrush
                    else Brush.linearGradient(listOf(ZarvimoSurfaceElevated, ZarvimoSurfaceElevated)),
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(horizontal = 24.dp, vertical = 14.dp)
        ) {
            androidx.compose.foundation.layout.Row(
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                if (icon != null) {
                    Icon(icon, contentDescription = null, tint = Color.White)
                }
                Text(
                    text = text,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}

/** A dark card with a subtle neon border, used throughout dashboard/picker/editor. */
@Composable
fun NeonCard(
    modifier: Modifier = Modifier,
    borderColor: Color = ZarvimoSurfaceElevated,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = ZarvimoSurfaceVariant,
        border = BorderStroke(1.dp, borderColor)
    ) {
        Box(modifier = Modifier.padding(contentPadding)) {
            content()
        }
    }
}

/** A circular icon button on a translucent dark surface, used in the editor toolbar. */
@Composable
fun NeonIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = ZarvimoTextPrimary,
    enabled: Boolean = true,
    size: androidx.compose.ui.unit.Dp = 44.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(ZarvimoSurfaceVariant)
            .border(1.dp, ZarvimoSurfaceElevated, CircleShape)
    ) {
        IconButton(onClick = onClick, enabled = enabled) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = if (enabled) tint else tint.copy(alpha = 0.35f)
            )
        }
    }
}
