package com.zarvimo.videoeditor.ui.dashboard

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.data.model.Project
import com.zarvimo.videoeditor.ui.components.NeonCard
import com.zarvimo.videoeditor.ui.components.NeonGradientButton
import com.zarvimo.videoeditor.ui.components.NeonIconButton
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary
import com.zarvimo.videoeditor.util.TimeFormat
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onOpenProject: (projectId: String) -> Unit,
    viewModel: DashboardViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var showNewProjectDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            DashboardHeader(
                onNewProject = { showNewProjectDialog = true },
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 20.dp)
            )

            when {
                uiState.isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = ZarvimoElectricBlue)
                }
                uiState.projects.isEmpty() -> EmptyDashboard(
                    onNewProject = { showNewProjectDialog = true }
                )
                else -> ProjectList(
                    projects = uiState.projects,
                    onOpenProject = onOpenProject,
                    onDeleteProject = viewModel::deleteProject
                )
            }
        }
    }

    if (showNewProjectDialog) {
        NewProjectDialog(
            onDismiss = { showNewProjectDialog = false },
            onConfirm = { name ->
                showNewProjectDialog = false
                viewModel.createProject(name) { project -> onOpenProject(project.id) }
            }
        )
    }
}

@Composable
private fun DashboardHeader(onNewProject: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.ic_zarvimo_logo),
                contentDescription = null,
                modifier = Modifier.size(36.dp)
            )
            Spacer(Modifier.size(10.dp))
            Text(
                text = stringResource(id = R.string.app_name),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            text = stringResource(id = R.string.dashboard_title),
            style = MaterialTheme.typography.titleMedium,
            color = ZarvimoTextSecondary
        )
        Spacer(Modifier.height(16.dp))
        NeonGradientButton(
            text = stringResource(id = R.string.dashboard_new_project),
            icon = Icons.Filled.Add,
            onClick = onNewProject,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun EmptyDashboard(onNewProject: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Filled.MovieCreation,
                contentDescription = null,
                tint = ZarvimoTextSecondary,
                modifier = Modifier.size(64.dp)
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = stringResource(id = R.string.dashboard_empty_title),
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(id = R.string.dashboard_empty_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary
            )
            Spacer(Modifier.height(24.dp))
            NeonGradientButton(
                text = stringResource(id = R.string.dashboard_new_project),
                icon = Icons.Filled.Add,
                onClick = onNewProject
            )
        }
    }
}

@Composable
private fun ProjectList(
    projects: List<Project>,
    onOpenProject: (String) -> Unit,
    onDeleteProject: (String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(projects, key = { it.id }) { project ->
            ProjectRow(
                project = project,
                onClick = { onOpenProject(project.id) },
                onDelete = { onDeleteProject(project.id) }
            )
        }
    }
}

@Composable
private fun ProjectRow(project: Project, onClick: () -> Unit, onDelete: () -> Unit) {
    NeonCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.MovieCreation,
                    contentDescription = null,
                    tint = ZarvimoElectricBlue,
                    modifier = Modifier.size(32.dp)
                )
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp)
                    .clickable(onClick = onClick)
            ) {
                Text(
                    text = project.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = stringResource(
                        id = R.string.dashboard_last_edited,
                        DateFormat.getDateInstance().format(Date(project.updatedAtMillis))
                    ) + " · " + TimeFormat.formatUs(project.totalDurationUs),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ZarvimoTextSecondary
                )
            }
            NeonIconButton(
                icon = Icons.Filled.Delete,
                contentDescription = stringResource(id = R.string.dashboard_delete_project),
                onClick = onDelete,
                tint = MaterialTheme.colorScheme.error
            )
        }
    }
}

@Composable
private fun NewProjectDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(id = R.string.dashboard_new_project)) },
        text = {
            androidx.compose.material3.OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                singleLine = true,
                label = { Text("Project name") },
                placeholder = { Text("My Awesome Edit") }
            )
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = { onConfirm(name) }) {
                Text(stringResource(id = R.string.action_confirm))
            }
        },
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) {
                Text(stringResource(id = R.string.action_cancel))
            }
        }
    )
}
