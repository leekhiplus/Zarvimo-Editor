package com.zarvimo.videoeditor.ui.editor

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.data.model.AudioTrackClip
import com.zarvimo.videoeditor.ui.components.NeonGradientButton
import com.zarvimo.videoeditor.ui.theme.ZarvimoDanger
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoSurfaceVariant
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary
import com.zarvimo.videoeditor.util.TimeFormat

/**
 * Bottom sheet that manages the project's background audio tracks: pick a
 * file from the device's own audio picker (a plain [ActivityResultContracts.GetContent]
 * system picker — simpler and just as reliable as a custom MediaStore browser
 * for the "occasionally add one music file" use case), then trim, move,
 * volume and fade each track. Tapping a row expands its controls in place
 * rather than opening a second sheet, so trimming stays visually anchored to
 * the track it belongs to.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioTrackSheet(
    audioTracks: List<AudioTrackClip>,
    selectedTrackId: String?,
    onSelectTrack: (String?) -> Unit,
    onAddAudio: (Uri) -> Unit,
    onTrimChanged: (trackId: String, newStartUs: Long, newEndUs: Long) -> Unit,
    onVolumeChanged: (trackId: String, volume: Float) -> Unit,
    onFadeChanged: (trackId: String, fadeInUs: Long, fadeOutUs: Long) -> Unit,
    onMoveTrack: (trackId: String, newStartOnTimelineUs: Long) -> Unit,
    onDelete: (trackId: String) -> Unit,
    onDismiss: () -> Unit
) {
    val pickAudioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) onAddAudio(uri)
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(id = R.string.audio_tracks_title),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
            }

            NeonGradientButton(
                text = stringResource(id = R.string.audio_tracks_add),
                icon = Icons.Filled.Add,
                onClick = { pickAudioLauncher.launch("audio/*") },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 12.dp)
            )

            if (audioTracks.isEmpty()) {
                Text(
                    text = stringResource(id = R.string.audio_tracks_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ZarvimoTextSecondary
                )
            }

            audioTracks.forEach { track ->
                AudioTrackRow(
                    track = track,
                    expanded = track.id == selectedTrackId,
                    onToggleExpanded = {
                        onSelectTrack(if (track.id == selectedTrackId) null else track.id)
                    },
                    onTrimChanged = onTrimChanged,
                    onVolumeChanged = onVolumeChanged,
                    onFadeChanged = onFadeChanged,
                    onMoveTrack = onMoveTrack,
                    onDelete = onDelete
                )
                Divider(modifier = Modifier.padding(vertical = 8.dp))
            }
        }
    }
}

@Composable
private fun AudioTrackRow(
    track: AudioTrackClip,
    expanded: Boolean,
    onToggleExpanded: () -> Unit,
    onTrimChanged: (String, Long, Long) -> Unit,
    onVolumeChanged: (String, Float) -> Unit,
    onFadeChanged: (String, Long, Long) -> Unit,
    onMoveTrack: (String, Long) -> Unit,
    onDelete: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (expanded) ZarvimoSurfaceVariant else androidx.compose.ui.graphics.Color.Transparent)
            .clickable(onClick = onToggleExpanded)
            .padding(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.MusicNote, contentDescription = null, tint = ZarvimoElectricBlue)
            Column(modifier = Modifier.weight(1f).padding(start = 8.dp)) {
                Text(track.displayName, style = MaterialTheme.typography.bodyMedium)
                Text(
                    text = "${TimeFormat.formatUs(track.startOnTimelineUs)} · ${TimeFormat.formatUs(track.trimmedDurationUs)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ZarvimoTextSecondary
                )
            }
            IconButton(onClick = { onDelete(track.id) }) {
                Icon(Icons.Filled.Delete, contentDescription = stringResource(id = R.string.action_delete), tint = ZarvimoDanger)
            }
        }

        if (expanded) {
            var volume by remember(track.id) { mutableFloatStateOf(track.volume) }
            var fadeInSeconds by remember(track.id) { mutableFloatStateOf(track.fadeInUs / 1_000_000f) }
            var fadeOutSeconds by remember(track.id) { mutableFloatStateOf(track.fadeOutUs / 1_000_000f) }
            var startSeconds by remember(track.id) { mutableFloatStateOf(track.startOnTimelineUs / 1_000_000f) }
            var trimStartSeconds by remember(track.id) { mutableFloatStateOf(track.trimStartUs / 1_000_000f) }
            var trimEndSeconds by remember(track.id) {
                mutableFloatStateOf(track.trimEndUs / 1_000_000f)
            }
            val sourceSeconds = (track.sourceDurationUs / 1_000_000f).coerceAtLeast(0.1f)

            Text(
                text = stringResource(id = R.string.audio_tracks_start_offset),
                style = MaterialTheme.typography.bodySmall,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 12.dp)
            )
            Slider(
                value = startSeconds,
                onValueChange = { startSeconds = it },
                onValueChangeFinished = { onMoveTrack(track.id, (startSeconds * 1_000_000L).toLong()) },
                valueRange = 0f..(sourceSeconds + 600f),
                colors = SliderDefaults.colors(thumbColor = ZarvimoElectricBlue, activeTrackColor = ZarvimoElectricBlue)
            )

            Text(
                text = stringResource(id = R.string.audio_tracks_trim),
                style = MaterialTheme.typography.bodySmall,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 8.dp)
            )
            Slider(
                value = trimStartSeconds,
                onValueChange = { trimStartSeconds = it.coerceAtMost(trimEndSeconds - 0.2f) },
                onValueChangeFinished = {
                    onTrimChanged(track.id, (trimStartSeconds * 1_000_000L).toLong(), (trimEndSeconds * 1_000_000L).toLong())
                },
                valueRange = 0f..sourceSeconds,
                colors = SliderDefaults.colors(thumbColor = ZarvimoElectricBlue, activeTrackColor = ZarvimoElectricBlue)
            )
            Slider(
                value = trimEndSeconds,
                onValueChange = { trimEndSeconds = it.coerceAtLeast(trimStartSeconds + 0.2f) },
                onValueChangeFinished = {
                    onTrimChanged(track.id, (trimStartSeconds * 1_000_000L).toLong(), (trimEndSeconds * 1_000_000L).toLong())
                },
                valueRange = 0f..sourceSeconds,
                colors = SliderDefaults.colors(thumbColor = ZarvimoElectricBlue, activeTrackColor = ZarvimoElectricBlue)
            )

            Text(
                text = stringResource(id = R.string.audio_tracks_volume, (volume * 100).toInt()),
                style = MaterialTheme.typography.bodySmall,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 8.dp)
            )
            Slider(
                value = volume,
                onValueChange = { volume = it },
                onValueChangeFinished = { onVolumeChanged(track.id, volume) },
                valueRange = 0f..2f,
                colors = SliderDefaults.colors(thumbColor = ZarvimoElectricBlue, activeTrackColor = ZarvimoElectricBlue)
            )

            Text(
                text = stringResource(id = R.string.audio_tracks_fade),
                style = MaterialTheme.typography.bodySmall,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 8.dp)
            )
            Row {
                Column(modifier = Modifier.weight(1f)) {
                    Text(stringResource(id = R.string.audio_tracks_fade_in), style = MaterialTheme.typography.bodySmall, color = ZarvimoTextSecondary)
                    Slider(
                        value = fadeInSeconds,
                        onValueChange = { fadeInSeconds = it },
                        onValueChangeFinished = {
                            onFadeChanged(track.id, (fadeInSeconds * 1_000_000L).toLong(), (fadeOutSeconds * 1_000_000L).toLong())
                        },
                        valueRange = 0f..5f,
                        colors = SliderDefaults.colors(thumbColor = ZarvimoElectricBlue, activeTrackColor = ZarvimoElectricBlue)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(stringResource(id = R.string.audio_tracks_fade_out), style = MaterialTheme.typography.bodySmall, color = ZarvimoTextSecondary)
                    Slider(
                        value = fadeOutSeconds,
                        onValueChange = { fadeOutSeconds = it },
                        onValueChangeFinished = {
                            onFadeChanged(track.id, (fadeInSeconds * 1_000_000L).toLong(), (fadeOutSeconds * 1_000_000L).toLong())
                        },
                        valueRange = 0f..5f,
                        colors = SliderDefaults.colors(thumbColor = ZarvimoElectricBlue, activeTrackColor = ZarvimoElectricBlue)
                    )
                }
            }
        }
    }
}
