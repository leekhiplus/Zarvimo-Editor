package com.zarvimo.videoeditor.ui.editor

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Undo
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavBackStackEntry
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.data.model.AspectRatio as ProjectAspectRatio
import com.zarvimo.videoeditor.navigation.PICKED_URIS_KEY
import com.zarvimo.videoeditor.export.ExportState
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    projectId: String,
    navBackStackEntry: NavBackStackEntry,
    onBack: () -> Unit,
    onOpenMediaPicker: () -> Unit,
    viewModel: EditorViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val positionUs by viewModel.playbackPositionUs.collectAsState()
    val currentClipIndex by viewModel.playerManager.currentClipIndex.collectAsState()
    val exportState by viewModel.exporter.state.collectAsState()

    var showVolumeSheet by remember { mutableStateOf(false) }
    var showTextSheet by remember { mutableStateOf(false) }
    var showExportSheet by remember { mutableStateOf(false) }
    var showAudioSheet by remember { mutableStateOf(false) }
    var showFilterSheet by remember { mutableStateOf(false) }
    var showTransformSheet by remember { mutableStateOf(false) }
    var showImageOverlaySheet by remember { mutableStateOf(false) }
    var showAspectMenu by remember { mutableStateOf(false) }
    var editingOverlayId by remember { mutableStateOf<String?>(null) }
    var editingImageOverlayId by remember { mutableStateOf<String?>(null) }

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    val selectClipFirstMessage = stringResource(id = R.string.editor_select_clip_first)

    fun showComingSoon(featureLabel: String) {
        coroutineScope.launch {
            snackbarHostState.showSnackbar(context.getString(R.string.editor_coming_soon, featureLabel))
        }
    }

    fun requireClipThen(action: () -> Unit) {
        if (uiState.selectedClipId != null) {
            action()
        } else {
            coroutineScope.launch { snackbarHostState.showSnackbar(selectClipFirstMessage) }
        }
    }

    LaunchedEffect(projectId) { viewModel.loadProject(projectId) }

    // Receives the Uris picked in MediaPickerScreen via the standard Navigation-Compose
    // "previous back stack entry's SavedStateHandle" result pattern.
    val pickedUris by navBackStackEntry.savedStateHandle
        .getStateFlow(PICKED_URIS_KEY, emptyList<String>())
        .collectAsState()
    LaunchedEffect(pickedUris) {
        if (pickedUris.isNotEmpty()) {
            viewModel.addClips(pickedUris.map { Uri.parse(it) })
            navBackStackEntry.savedStateHandle[PICKED_URIS_KEY] = emptyList<String>()
        }
    }

    // Surfaces EditorUiState.errorMessage (e.g. "Couldn't read: <file>" when a
    // clip's duration couldn't be extracted on import) as a Snackbar, then
    // clears it so it doesn't reappear on the next recomposition.
    LaunchedEffect(uiState.errorMessage) {
        val message = uiState.errorMessage
        if (message != null) {
            snackbarHostState.showSnackbar(message)
            viewModel.consumeError()
        }
    }

    val project = uiState.project

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(snackbarData = data)
            }
        },
        topBar = {
            TopAppBar(
                title = { Text(project?.name ?: stringResource(id = R.string.app_name)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(id = R.string.action_back)
                        )
                    }
                },
                actions = {
                    Box {
                        IconButton(onClick = { showAspectMenu = true }) {
                            Icon(
                                imageVector = Icons.Filled.AspectRatio,
                                contentDescription = stringResource(id = R.string.editor_aspect_ratio)
                            )
                        }
                        DropdownMenu(expanded = showAspectMenu, onDismissRequest = { showAspectMenu = false }) {
                            ProjectAspectRatio.entries.forEach { ratio ->
                                DropdownMenuItem(
                                    text = { Text(ratio.label) },
                                    onClick = {
                                        viewModel.setAspectRatio(ratio)
                                        showAspectMenu = false
                                    }
                                )
                            }
                        }
                    }
                    IconButton(onClick = viewModel::undo, enabled = uiState.canUndo) {
                        Icon(
                            imageVector = Icons.Filled.Undo,
                            contentDescription = stringResource(id = R.string.editor_undo)
                        )
                    }
                    IconButton(onClick = viewModel::redo, enabled = uiState.canRedo) {
                        Icon(
                            imageVector = Icons.Filled.Redo,
                            contentDescription = stringResource(id = R.string.editor_redo)
                        )
                    }
                    IconButton(onClick = { viewModel.save() }) {
                        Icon(
                            imageVector = Icons.Filled.Save,
                            contentDescription = stringResource(id = R.string.editor_save)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            when {
                uiState.isLoading -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) { CircularProgressIndicator(color = ZarvimoElectricBlue) }

                project == null -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) { Text("Project not found", color = ZarvimoTextSecondary) }

                else -> Row(modifier = Modifier.fillMaxSize()) {
                    EditorSidebarRail(
                        onMediaClick = onOpenMediaPicker,
                        onAudioClick = { showAudioSheet = true },
                        onTextClick = {
                            editingOverlayId = null
                            showTextSheet = true
                        },
                        onEffectsClick = { requireClipThen { showFilterSheet = true } },
                        onStickersClick = {
                            editingImageOverlayId = null
                            showImageOverlaySheet = true
                        },
                        onTransformClick = { requireClipThen { showTransformSheet = true } },
                        onAdjustClick = { requireClipThen { showVolumeSheet = true } }
                    )

                    Column(modifier = Modifier.weight(1f).fillMaxSize()) {
                        val orderedClips = project.orderedClips
                        val previousStartUs = {
                            val idx = (currentClipIndex - 1).coerceIn(0, (orderedClips.size - 1).coerceAtLeast(0))
                            orderedClips.take(idx).sumOf { it.trimmedDurationUs }
                        }
                        val nextStartUs = {
                            val idx = (currentClipIndex + 1).coerceIn(0, (orderedClips.size - 1).coerceAtLeast(0))
                            orderedClips.take(idx).sumOf { it.trimmedDurationUs }
                        }

                        PreviewPlayerView(
                            player = viewModel.playerManager.player,
                            overlays = project.textOverlays,
                            imageOverlays = project.imageOverlays,
                            positionUs = positionUs,
                            totalDurationUs = project.totalDurationUs,
                            isPlaying = isPlaying,
                            onPlayPause = if (orderedClips.isEmpty()) null else viewModel.playerManager::playPause,
                            onPreviousClip = if (orderedClips.size > 1) {
                                { viewModel.playerManager.seekToTimelineUs(previousStartUs()) }
                            } else null,
                            onNextClip = if (orderedClips.size > 1) {
                                { viewModel.playerManager.seekToTimelineUs(nextStartUs()) }
                            } else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(project.aspectRatio.ratio),
                            onOverlayClick = { overlay ->
                                editingOverlayId = overlay.id
                                showTextSheet = true
                            },
                            onImageOverlayClick = { overlay ->
                                editingImageOverlayId = overlay.id
                                showImageOverlaySheet = true
                            }
                        )

                        if (project.clips.isEmpty()) {
                            Box(
                                modifier = Modifier.fillMaxWidth().height(80.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = stringResource(id = R.string.editor_empty_timeline),
                                    color = ZarvimoTextSecondary
                                )
                            }
                        } else {
                            TimelineView(
                                clips = project.clips,
                                selectedClipId = uiState.selectedClipId,
                                playheadUs = positionUs,
                                onSelectClip = viewModel::selectClip,
                                onSeekToClipStart = { clipId ->
                                    val clip = project.orderedClips.firstOrNull { it.id == clipId }
                                    val index = project.orderedClips.indexOfFirst { it.id == clipId }
                                    if (clip != null && index >= 0) {
                                        val startUs = project.orderedClips.take(index).sumOf { it.trimmedDurationUs }
                                        viewModel.playerManager.seekToTimelineUs(startUs)
                                    }
                                },
                                onReorder = viewModel::reorderClip,
                                onTrimChanged = viewModel::trimClip,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(84.dp)
                            )
                        }

                        EditorControlsBar(
                            hasSelectedClip = uiState.selectedClipId != null,
                            onSplit = viewModel::splitAtPlayhead,
                            onDeleteClip = {
                                uiState.selectedClipId?.let(viewModel::deleteClip)
                            },
                            onAddMusic = { showAudioSheet = true },
                            onApplyFilters = { requireClipThen { showFilterSheet = true } },
                            onSlowMotion = { requireClipThen { showTransformSheet = true } },
                            onExport = { showExportSheet = true },
                            onComingSoon = ::showComingSoon
                        )
                    }
                }
            }
        }
    }

    if (showVolumeSheet && project != null) {
        val selectedClip = project.clips.firstOrNull { it.id == uiState.selectedClipId }
        if (selectedClip != null) {
            VolumeControlSheet(
                initialVolume = selectedClip.volume,
                onVolumeChanged = { volume -> viewModel.setClipVolume(selectedClip.id, volume) },
                onDismiss = { showVolumeSheet = false }
            )
        } else {
            showVolumeSheet = false
        }
    }

    if (showTransformSheet && project != null) {
        val selectedClip = project.clips.firstOrNull { it.id == uiState.selectedClipId }
        if (selectedClip != null) {
            TransformSheet(
                clip = selectedClip,
                onCropChanged = { left, top, right, bottom -> viewModel.setClipCrop(selectedClip.id, left, top, right, bottom) },
                onClearCrop = { viewModel.clearClipCrop(selectedClip.id) },
                onRotate = { viewModel.rotateClipQuarterTurn(selectedClip.id) },
                onToggleFlipHorizontal = { viewModel.toggleClipFlipHorizontal(selectedClip.id) },
                onToggleFlipVertical = { viewModel.toggleClipFlipVertical(selectedClip.id) },
                onSpeedChanged = { speed -> viewModel.setClipSpeed(selectedClip.id, speed) },
                onDismiss = { showTransformSheet = false }
            )
        } else {
            showTransformSheet = false
        }
    }

    if (showFilterSheet && project != null) {
        val selectedClip = project.clips.firstOrNull { it.id == uiState.selectedClipId }
        if (selectedClip != null) {
            FilterColorSheet(
                clip = selectedClip,
                onFilterChanged = { filter -> viewModel.setClipFilter(selectedClip.id, filter) },
                onColorAdjustmentChanged = { adjustment -> viewModel.setClipColorAdjustment(selectedClip.id, adjustment) },
                onTransitionChanged = { transition -> viewModel.setClipTransition(selectedClip.id, transition) },
                onDismiss = { showFilterSheet = false }
            )
        } else {
            showFilterSheet = false
        }
    }

    if (showAudioSheet && project != null) {
        AudioTrackSheet(
            audioTracks = project.audioTracks,
            selectedTrackId = uiState.selectedAudioTrackId,
            onSelectTrack = viewModel::selectAudioTrack,
            onAddAudio = { uri -> viewModel.addAudioTrack(uri, positionUs) },
            onTrimChanged = viewModel::trimAudioTrack,
            onVolumeChanged = viewModel::setAudioTrackVolume,
            onFadeChanged = viewModel::setAudioTrackFade,
            onMoveTrack = viewModel::moveAudioTrack,
            onDelete = viewModel::deleteAudioTrack,
            onDismiss = { showAudioSheet = false }
        )
    }

    if (showImageOverlaySheet && project != null) {
        val existing = project.imageOverlays.firstOrNull { it.id == editingImageOverlayId }
        ImageOverlaySheet(
            existingOverlay = existing,
            currentPlayheadUs = positionUs,
            onPickAndAdd = { uri, startUs, endUs -> viewModel.addImageOverlay(uri, startUs, endUs) },
            onUpdate = { overlay -> viewModel.updateImageOverlay(overlay) },
            onRemove = existing?.let { { viewModel.removeImageOverlay(it.id) } },
            onDismiss = { showImageOverlaySheet = false }
        )
    }

    if (showTextSheet && project != null) {
        val existing = project.textOverlays.firstOrNull { it.id == editingOverlayId }
        TextOverlaySheet(
            existingOverlay = existing,
            currentPlayheadUs = positionUs,
            onSave = { overlay ->
                if (existing == null) viewModel.addTextOverlay(overlay) else viewModel.updateTextOverlay(overlay)
            },
            onRemove = existing?.let { { viewModel.removeTextOverlay(it.id) } },
            onDismiss = { showTextSheet = false }
        )
    }

    if (showExportSheet && project != null) {
        val safeName = project.name.filter { it.isLetterOrDigit() }.ifBlank { "project" }
        ExportSheet(
            state = exportState,
            suggestedFileName = "zarvimo_$safeName.mp4",
            onStart = { quality, frameRate, destinationUri ->
                viewModel.exportProject(quality, frameRate, destinationUri)
            },
            onCancel = { viewModel.cancelExport() },
            onShare = { file ->
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Share exported video"))
            },
            onDismiss = { showExportSheet = false }
        )
    }
}
