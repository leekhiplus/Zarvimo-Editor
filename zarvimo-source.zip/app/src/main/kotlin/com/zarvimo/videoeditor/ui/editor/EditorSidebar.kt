package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoSurface
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextPrimary

/**
 * The editor's left-hand vertical tool rail (Media/Audio/Text/Effects/Stickers/
 * Transform/Adjust), in the spirit of Zarvimo's branding reference. Every
 * item here opens a real, working sheet — [onEffectsClick] (filters/color/
 * transition) and [onTransformClick] (crop/rotate/flip/speed) operate on the
 * selected clip, so [EditorScreen] prompts to select one first if none is
 * selected rather than this rail dimming them out.
 */
@Composable
fun EditorSidebarRail(
    onMediaClick: () -> Unit,
    onAudioClick: () -> Unit,
    onTextClick: () -> Unit,
    onEffectsClick: () -> Unit,
    onStickersClick: () -> Unit,
    onTransformClick: () -> Unit,
    onAdjustClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .width(76.dp)
            .background(ZarvimoSurface)
            .verticalScroll(rememberScrollState())
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        SidebarRailItem(
            icon = Icons.Filled.VideoLibrary,
            label = stringResource(id = R.string.sidebar_media),
            onClick = onMediaClick
        )
        SidebarRailItem(
            icon = Icons.Filled.MusicNote,
            label = stringResource(id = R.string.sidebar_audio),
            onClick = onAudioClick
        )
        SidebarRailItem(
            icon = Icons.Filled.TextFields,
            label = stringResource(id = R.string.sidebar_text),
            onClick = onTextClick
        )
        SidebarRailItem(
            icon = Icons.Filled.AutoAwesome,
            label = stringResource(id = R.string.sidebar_effects),
            onClick = onEffectsClick
        )
        SidebarRailItem(
            icon = Icons.Filled.EmojiEmotions,
            label = stringResource(id = R.string.sidebar_stickers),
            onClick = onStickersClick
        )
        SidebarRailItem(
            icon = Icons.Filled.Crop,
            label = stringResource(id = R.string.sidebar_overlay),
            onClick = onTransformClick
        )
        SidebarRailItem(
            icon = Icons.Filled.Tune,
            label = stringResource(id = R.string.sidebar_adjust),
            onClick = onAdjustClick
        )
    }
}

@Composable
private fun SidebarRailItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(68.dp)
            .padding(vertical = 2.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = ZarvimoElectricBlue
        )
        Text(
            text = label,
            color = ZarvimoTextPrimary,
            style = MaterialTheme.typography.labelSmall,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}
