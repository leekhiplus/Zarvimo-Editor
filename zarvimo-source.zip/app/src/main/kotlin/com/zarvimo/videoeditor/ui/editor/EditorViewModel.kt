package com.zarvimo.videoeditor.ui.editor

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zarvimo.videoeditor.data.ClipOrdering
import com.zarvimo.videoeditor.data.ProjectRepository
import com.zarvimo.videoeditor.data.UndoRedoManager
import com.zarvimo.videoeditor.data.model.AspectRatio
import com.zarvimo.videoeditor.data.model.AudioTrackClip
import com.zarvimo.videoeditor.data.model.ColorAdjustment
import com.zarvimo.videoeditor.data.model.ExportFrameRate
import com.zarvimo.videoeditor.data.model.ExportQuality
import com.zarvimo.videoeditor.data.model.ImageOverlay
import com.zarvimo.videoeditor.data.model.Project
import com.zarvimo.videoeditor.data.model.TextOverlay
import com.zarvimo.videoeditor.data.model.TransitionType
import com.zarvimo.videoeditor.data.model.VideoClip
import com.zarvimo.videoeditor.data.model.VideoFilterType
import com.zarvimo.videoeditor.export.VideoExporter
import com.zarvimo.videoeditor.playback.PlayerManager
import com.zarvimo.videoeditor.util.MediaUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

data class EditorUiState(
    val project: Project? = null,
    val selectedClipId: String? = null,
    val selectedAudioTrackId: String? = null,
    val selectedImageOverlayId: String? = null,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val isLoading: Boolean = true,
    val isSaving: Boolean = false,
    val lastSavedAtMillis: Long? = null,
    val errorMessage: String? = null
)

/**
 * Owns a single project's editing session: the undo/redo history, the live
 * preview player, and the export pipeline. Every mutating action (add/trim/
 * split/duplicate/delete/reorder a clip, its crop/rotation/flip/speed/color/
 * filter/transition, audio tracks, image overlays, text overlays) funnels
 * through [mutate], which is the one place that pushes undo history and
 * reloads the preview player, so those two things can never drift apart.
 */
class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ProjectRepository(application)
    val playerManager = PlayerManager(application, viewModelScope)
    val exporter = VideoExporter(application)

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    val playbackPositionUs: StateFlow<Long> get() = playerManager.positionUs
    val isPlaying: StateFlow<Boolean> get() = playerManager.isPlaying

    private var undoRedo: UndoRedoManager<Project>? = null

    fun loadProject(projectId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            repository.load(projectId)
                .onSuccess { project ->
                    undoRedo = UndoRedoManager(project)
                    playerManager.loadProject(project, preservePosition = false)
                    _uiState.value = EditorUiState(project = project, isLoading = false)
                }
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = e.message ?: "Could not load project"
                    )
                }
        }
    }

    private fun mutate(mutator: (Project) -> Project) {
        val manager = undoRedo ?: return
        val updated = mutator(manager.current())
        manager.push(updated)
        playerManager.loadProject(updated)
        publishFromManager(manager)
    }

    private fun publishFromManager(manager: UndoRedoManager<Project>) {
        _uiState.value = _uiState.value.copy(
            project = manager.current(),
            canUndo = manager.canUndo,
            canRedo = manager.canRedo
        )
    }

    fun undo() {
        val manager = undoRedo ?: return
        if (!manager.canUndo) return
        manager.undo()
        playerManager.loadProject(manager.current())
        publishFromManager(manager)
    }

    fun redo() {
        val manager = undoRedo ?: return
        if (!manager.canRedo) return
        manager.redo()
        playerManager.loadProject(manager.current())
        publishFromManager(manager)
    }

    // ---------------------------------------------------------------------
    // Primary track: add / select / delete / reorder / trim / split / duplicate
    // ---------------------------------------------------------------------

    fun addClips(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val context = getApplication<Application>()
            val startOrder = undoRedo?.current()?.clips.orEmpty().size
            val newClips = uris.mapIndexed { offset, uri ->
                val duration = MediaUtils.durationUs(context, uri)
                VideoClip(
                    sourceUri = uri.toString(),
                    sourceDurationUs = duration,
                    trimStartUs = 0L,
                    trimEndUs = duration,
                    order = startOrder + offset,
                    displayName = MediaUtils.displayName(context, uri)
                )
            }
            mutate { project -> project.copy(clips = project.clips + newClips) }
        }
    }

    fun selectClip(clipId: String?) {
        _uiState.value = _uiState.value.copy(selectedClipId = clipId, selectedAudioTrackId = null, selectedImageOverlayId = null)
    }

    fun deleteClip(clipId: String) {
        mutate { project ->
            val remaining = project.clips
                .filterNot { it.id == clipId }
                .sortedBy { it.order }
                .mapIndexed { index, clip -> clip.copy(order = index) }
            project.copy(clips = remaining)
        }
        if (_uiState.value.selectedClipId == clipId) selectClip(null)
    }

    /** Inserts a copy of [clipId] immediately after it, shifting every later clip's order by one. */
    fun duplicateClip(clipId: String) {
        mutate { project -> project.copy(clips = ClipOrdering.withDuplicate(project.clips, clipId)) }
    }

    fun reorderClip(fromIndex: Int, toIndex: Int) {
        mutate { project -> project.copy(clips = ClipOrdering.withReorder(project.clips, fromIndex, toIndex)) }
    }

    fun trimClip(clipId: String, newStartUs: Long, newEndUs: Long) {
        mutate { project ->
            project.copy(
                clips = project.clips.map { clip ->
                    if (clip.id == clipId) clip.withTrim(newStartUs, newEndUs) else clip
                }
            )
        }
    }

    fun setClipVolume(clipId: String, volume: Float) {
        mutate { project ->
            project.copy(
                clips = project.clips.map { clip ->
                    if (clip.id == clipId) clip.copy(volume = volume.coerceIn(0f, 2f)) else clip
                }
            )
        }
    }

    /**
     * Splits whichever clip the playhead currently sits inside into two adjacent
     * clips at that exact position. A no-op if the playhead is within
     * [MIN_SPLIT_MARGIN_US] of either end of its clip, so a split never produces
     * a near-zero-length fragment.
     */
    fun splitAtPlayhead() {
        val project = undoRedo?.current() ?: return
        val timelineUs = playerManager.timelinePositionUs()
        var cursor = 0L
        for (clip in project.orderedClips) {
            val clipEnd = cursor + clip.trimmedDurationUs
            val localOffsetUs = timelineUs - cursor
            val splittable = timelineUs in (cursor + MIN_SPLIT_MARGIN_US) until (clipEnd - MIN_SPLIT_MARGIN_US)
            if (splittable) {
                val splitPointInSource = clip.trimStartUs + localOffsetUs
                mutate { current ->
                    val others = current.clips
                        .filterNot { it.id == clip.id }
                        .map { c -> if (c.order > clip.order) c.copy(order = c.order + 1) else c }
                    val firstHalf = clip.copy(trimEndUs = splitPointInSource, order = clip.order)
                    val secondHalf = clip.copy(
                        id = UUID.randomUUID().toString(),
                        trimStartUs = splitPointInSource,
                        order = clip.order + 1
                    )
                    current.copy(clips = others + firstHalf + secondHalf)
                }
                return
            }
            cursor = clipEnd
        }
    }

    // ---------------------------------------------------------------------
    // Per-clip transform, color, filter and transition
    // ---------------------------------------------------------------------

    private fun updateClip(clipId: String, transform: (VideoClip) -> VideoClip) {
        mutate { project ->
            project.copy(clips = project.clips.map { if (it.id == clipId) transform(it) else it })
        }
    }

    fun setClipCrop(clipId: String, left: Float, top: Float, right: Float, bottom: Float) {
        updateClip(clipId) { it.withCrop(left, top, right, bottom) }
    }

    fun clearClipCrop(clipId: String) {
        updateClip(clipId) { it.withCrop(0f, 0f, 1f, 1f) }
    }

    /** Rotates the clip 90° clockwise from its current orientation. */
    fun rotateClipQuarterTurn(clipId: String) {
        updateClip(clipId) { it.copy(rotationQuarterTurns = (it.rotationQuarterTurns + 1) % 4) }
    }

    fun toggleClipFlipHorizontal(clipId: String) {
        updateClip(clipId) { it.copy(flipHorizontal = !it.flipHorizontal) }
    }

    fun toggleClipFlipVertical(clipId: String) {
        updateClip(clipId) { it.copy(flipVertical = !it.flipVertical) }
    }

    fun setClipSpeed(clipId: String, speed: Float) {
        updateClip(clipId) { it.withSpeed(speed) }
    }

    fun setClipColorAdjustment(clipId: String, adjustment: ColorAdjustment) {
        updateClip(clipId) { it.copy(colorAdjustment = adjustment.clamped()) }
    }

    fun setClipFilter(clipId: String, filter: VideoFilterType) {
        updateClip(clipId) { it.copy(filter = filter) }
    }

    fun setClipTransition(clipId: String, transition: TransitionType, durationUs: Long = VideoClip.DEFAULT_TRANSITION_DURATION_US) {
        updateClip(clipId) { it.copy(transitionOut = transition, transitionDurationUs = durationUs.coerceAtLeast(100_000L)) }
    }

    // ---------------------------------------------------------------------
    // Background audio tracks (independent of the primary video track)
    // ---------------------------------------------------------------------

    fun addAudioTrack(uri: Uri, startOnTimelineUs: Long = 0L) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            val duration = MediaUtils.durationUs(context, uri)
            if (duration <= 0L) return@launch
            val track = AudioTrackClip(
                sourceUri = uri.toString(),
                sourceDurationUs = duration,
                trimEndUs = duration,
                startOnTimelineUs = startOnTimelineUs.coerceAtLeast(0L),
                displayName = MediaUtils.displayName(context, uri)
            )
            mutate { project -> project.copy(audioTracks = project.audioTracks + track) }
        }
    }

    fun selectAudioTrack(trackId: String?) {
        _uiState.value = _uiState.value.copy(selectedAudioTrackId = trackId, selectedClipId = null, selectedImageOverlayId = null)
    }

    fun trimAudioTrack(trackId: String, newStartUs: Long, newEndUs: Long) {
        mutate { project ->
            project.copy(
                audioTracks = project.audioTracks.map { track ->
                    if (track.id == trackId) track.withTrim(newStartUs, newEndUs) else track
                }
            )
        }
    }

    fun moveAudioTrack(trackId: String, newStartOnTimelineUs: Long) {
        mutate { project ->
            project.copy(
                audioTracks = project.audioTracks.map { track ->
                    if (track.id == trackId) track.copy(startOnTimelineUs = newStartOnTimelineUs.coerceAtLeast(0L)) else track
                }
            )
        }
    }

    fun setAudioTrackVolume(trackId: String, volume: Float) {
        mutate { project ->
            project.copy(
                audioTracks = project.audioTracks.map { track ->
                    if (track.id == trackId) track.copy(volume = volume.coerceIn(0f, 2f)) else track
                }
            )
        }
    }

    fun setAudioTrackFade(trackId: String, fadeInUs: Long, fadeOutUs: Long) {
        mutate { project ->
            project.copy(
                audioTracks = project.audioTracks.map { track ->
                    if (track.id == trackId) {
                        track.copy(fadeInUs = fadeInUs.coerceAtLeast(0L), fadeOutUs = fadeOutUs.coerceAtLeast(0L))
                    } else track
                }
            )
        }
    }

    fun deleteAudioTrack(trackId: String) {
        mutate { project -> project.copy(audioTracks = project.audioTracks.filterNot { it.id == trackId }) }
        if (_uiState.value.selectedAudioTrackId == trackId) selectAudioTrack(null)
    }

    // ---------------------------------------------------------------------
    // Image overlays
    // ---------------------------------------------------------------------

    fun addImageOverlay(uri: Uri, startTimeUs: Long, endTimeUs: Long) {
        mutate { project ->
            project.copy(
                imageOverlays = project.imageOverlays + ImageOverlay(
                    sourceUri = uri.toString(),
                    startTimeUs = startTimeUs,
                    endTimeUs = endTimeUs.coerceAtLeast(startTimeUs + 100_000L)
                )
            )
        }
    }

    fun selectImageOverlay(overlayId: String?) {
        _uiState.value = _uiState.value.copy(selectedImageOverlayId = overlayId, selectedClipId = null, selectedAudioTrackId = null)
    }

    fun updateImageOverlay(overlay: ImageOverlay) {
        mutate { project ->
            project.copy(imageOverlays = project.imageOverlays.map { if (it.id == overlay.id) overlay else it })
        }
    }

    fun removeImageOverlay(overlayId: String) {
        mutate { project -> project.copy(imageOverlays = project.imageOverlays.filterNot { it.id == overlayId }) }
        if (_uiState.value.selectedImageOverlayId == overlayId) selectImageOverlay(null)
    }

    // ---------------------------------------------------------------------
    // Text overlays
    // ---------------------------------------------------------------------

    fun addTextOverlay(overlay: TextOverlay) {
        mutate { project -> project.copy(textOverlays = project.textOverlays + overlay) }
    }

    fun updateTextOverlay(overlay: TextOverlay) {
        mutate { project ->
            project.copy(
                textOverlays = project.textOverlays.map { if (it.id == overlay.id) overlay else it }
            )
        }
    }

    fun removeTextOverlay(overlayId: String) {
        mutate { project ->
            project.copy(textOverlays = project.textOverlays.filterNot { it.id == overlayId })
        }
    }

    fun renameProject(name: String) {
        mutate { project -> project.copy(name = name.ifBlank { project.name }) }
    }

    fun setAspectRatio(aspectRatio: AspectRatio) {
        mutate { project -> project.copy(aspectRatio = aspectRatio) }
    }

    fun save() {
        val project = undoRedo?.current() ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSaving = true)
            repository.save(project)
            _uiState.value = _uiState.value.copy(
                isSaving = false,
                lastSavedAtMillis = System.currentTimeMillis()
            )
        }
    }

    fun exportProject(quality: ExportQuality, frameRate: ExportFrameRate, destinationUri: Uri?) {
        if (undoRedo?.current() == null) return
        mutate { project -> project.copy(exportQuality = quality, exportFrameRate = frameRate) }
        val project = undoRedo?.current() ?: return
        val safeName = project.name.filter { it.isLetterOrDigit() }.ifBlank { "project" }
        val fileName = "zarvimo_${safeName}_${System.currentTimeMillis()}.mp4"
        val outputFile = File(repository.exportsDir, fileName)
        exporter.export(project, outputFile, viewModelScope, destinationUri)
    }

    fun cancelExport() = exporter.cancel()

    fun consumeError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.release()
    }

    private companion object {
        /** Minimum remaining length either side of a split, in microseconds. */
        const val MIN_SPLIT_MARGIN_US = 100_000L
    }
}
