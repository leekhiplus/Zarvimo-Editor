package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.data.model.ColorAdjustment
import com.zarvimo.videoeditor.data.model.TransitionType
import com.zarvimo.videoeditor.data.model.VideoClip
import com.zarvimo.videoeditor.data.model.VideoFilterType
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary

/**
 * Bottom sheet for one clip's filter preset, brightness/contrast/saturation/
 * temperature, and its outgoing transition into the next clip. Every entry
 * here is backed by a real, implemented effect (see [VideoFilterType] and
 * [TransitionType]'s own doc comments for exactly what's real vs. not
 * offered) — nothing in this sheet is a label with no effect behind it.
 * Color sliders commit on release, same pattern as [VolumeControlSheet].
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilterColorSheet(
    clip: VideoClip,
    onFilterChanged: (VideoFilterType) -> Unit,
    onColorAdjustmentChanged: (ColorAdjustment) -> Unit,
    onTransitionChanged: (TransitionType) -> Unit,
    onDismiss: () -> Unit
) {
    var brightness by remember(clip.id) { mutableFloatStateOf(clip.colorAdjustment.brightness) }
    var contrast by remember(clip.id) { mutableFloatStateOf(clip.colorAdjustment.contrast) }
    var saturation by remember(clip.id) { mutableFloatStateOf(clip.colorAdjustment.saturation) }
    var temperature by remember(clip.id) { mutableFloatStateOf(clip.colorAdjustment.temperature) }

    fun commitColor() {
        onColorAdjustmentChanged(ColorAdjustment(brightness, contrast, saturation, temperature))
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
            Text(
                text = stringResource(id = R.string.filters_title),
                style = MaterialTheme.typography.titleMedium
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(top = 12.dp)
            ) {
                VideoFilterType.entries.forEach { filterType ->
                    FilterChip(
                        selected = clip.filter == filterType,
                        onClick = { onFilterChanged(filterType) },
                        label = { Text(filterType.label) },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                    )
                }
            }

            Divider(modifier = Modifier.padding(vertical = 16.dp))

            Text(
                text = stringResource(id = R.string.filters_adjust),
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            AdjustSlider(
                label = stringResource(id = R.string.filters_brightness),
                value = brightness,
                onValueChange = { brightness = it },
                onValueChangeFinished = ::commitColor
            )
            AdjustSlider(
                label = stringResource(id = R.string.filters_contrast),
                value = contrast,
                onValueChange = { contrast = it },
                onValueChangeFinished = ::commitColor
            )
            AdjustSlider(
                label = stringResource(id = R.string.filters_saturation),
                value = saturation,
                onValueChange = { saturation = it },
                onValueChangeFinished = ::commitColor
            )
            AdjustSlider(
                label = stringResource(id = R.string.filters_temperature),
                value = temperature,
                onValueChange = { temperature = it },
                onValueChangeFinished = ::commitColor
            )

            Divider(modifier = Modifier.padding(vertical = 16.dp))

            Text(
                text = stringResource(id = R.string.filters_transition),
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row {
                TransitionType.entries.forEach { transition ->
                    FilterChip(
                        selected = clip.transitionOut == transition,
                        onClick = { onTransitionChanged(transition) },
                        label = { Text(transition.label) },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                    )
                }
            }
        }
    }
}

@Composable
private fun AdjustSlider(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = ZarvimoTextSecondary)
        Slider(
            value = value,
            onValueChange = onValueChange,
            onValueChangeFinished = onValueChangeFinished,
            valueRange = -1f..1f,
            colors = SliderDefaults.colors(
                thumbColor = ZarvimoElectricBlue,
                activeTrackColor = ZarvimoElectricBlue
            )
        )
    }
}
