package com.zarvimo.videoeditor.ui.editor

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.data.model.ImageOverlay
import com.zarvimo.videoeditor.ui.components.NeonGradientButton
import com.zarvimo.videoeditor.ui.theme.ZarvimoDanger
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary

/**
 * Bottom sheet to add a new image overlay (sticker/watermark/picture-in-picture),
 * anchored at [currentPlayheadUs] with a default 3s duration, or edit/remove an
 * existing one. Picking the image reuses the same plain system picker pattern
 * as [AudioTrackSheet]. Position/size are dragged live in [PreviewPlayerView]
 * once added (tap the overlay there to reopen this sheet with [existingOverlay]
 * set); this sheet itself exposes the same values as sliders for precise control.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageOverlaySheet(
    existingOverlay: ImageOverlay?,
    currentPlayheadUs: Long,
    onPickAndAdd: (Uri, startTimeUs: Long, endTimeUs: Long) -> Unit,
    onUpdate: (ImageOverlay) -> Unit,
    onRemove: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    val pickImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            onPickAndAdd(uri, currentPlayheadUs, currentPlayheadUs + 3_000_000L)
            onDismiss()
        }
    }

    var xFraction by remember(existingOverlay) { mutableFloatStateOf(existingOverlay?.xFraction ?: 0.5f) }
    var yFraction by remember(existingOverlay) { mutableFloatStateOf(existingOverlay?.yFraction ?: 0.5f) }
    var widthFraction by remember(existingOverlay) { mutableFloatStateOf(existingOverlay?.widthFraction ?: 0.3f) }
    var heightFraction by remember(existingOverlay) { mutableFloatStateOf(existingOverlay?.heightFraction ?: 0.3f) }
    var rotationDegrees by remember(existingOverlay) { mutableFloatStateOf(existingOverlay?.rotationDegrees ?: 0f) }
    var opacity by remember(existingOverlay) { mutableFloatStateOf(existingOverlay?.opacity ?: 1f) }

    fun commit() {
        val overlay = existingOverlay ?: return
        onUpdate(
            overlay.copy(
                xFraction = xFraction,
                yFraction = yFraction,
                widthFraction = widthFraction,
                heightFraction = heightFraction,
                rotationDegrees = rotationDegrees,
                opacity = opacity
            )
        )
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
            Text(
                text = stringResource(id = R.string.image_overlay_title),
                style = MaterialTheme.typography.titleMedium
            )

            if (existingOverlay == null) {
                Text(
                    text = stringResource(id = R.string.image_overlay_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ZarvimoTextSecondary,
                    modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                )
                NeonGradientButton(
                    text = stringResource(id = R.string.image_overlay_pick),
                    icon = Icons.Filled.Image,
                    onClick = { pickImageLauncher.launch("image/*") },
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                OverlaySlider(
                    label = stringResource(id = R.string.image_overlay_position_x),
                    value = xFraction,
                    onValueChange = { xFraction = it },
                    onValueChangeFinished = ::commit
                )
                OverlaySlider(
                    label = stringResource(id = R.string.image_overlay_position_y),
                    value = yFraction,
                    onValueChange = { yFraction = it },
                    onValueChangeFinished = ::commit
                )
                OverlaySlider(
                    label = stringResource(id = R.string.image_overlay_width),
                    value = widthFraction,
                    onValueChange = { widthFraction = it },
                    onValueChangeFinished = ::commit,
                    valueRange = 0.05f..1f
                )
                OverlaySlider(
                    label = stringResource(id = R.string.image_overlay_height),
                    value = heightFraction,
                    onValueChange = { heightFraction = it },
                    onValueChangeFinished = ::commit,
                    valueRange = 0.05f..1f
                )
                OverlaySlider(
                    label = stringResource(id = R.string.image_overlay_rotation),
                    value = rotationDegrees,
                    onValueChange = { rotationDegrees = it },
                    onValueChangeFinished = ::commit,
                    valueRange = 0f..360f
                )
                OverlaySlider(
                    label = stringResource(id = R.string.image_overlay_opacity),
                    value = opacity,
                    onValueChange = { opacity = it },
                    onValueChangeFinished = ::commit
                )

                Divider(modifier = Modifier.padding(vertical = 12.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    if (onRemove != null) {
                        TextButton(onClick = { onRemove(); onDismiss() }) {
                            Text(stringResource(id = R.string.image_overlay_remove), color = ZarvimoDanger)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OverlaySlider(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f
) {
    Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = ZarvimoTextSecondary)
        Slider(
            value = value,
            onValueChange = onValueChange,
            onValueChangeFinished = onValueChangeFinished,
            valueRange = valueRange,
            colors = SliderDefaults.colors(thumbColor = ZarvimoElectricBlue, activeTrackColor = ZarvimoElectricBlue)
        )
    }
}
