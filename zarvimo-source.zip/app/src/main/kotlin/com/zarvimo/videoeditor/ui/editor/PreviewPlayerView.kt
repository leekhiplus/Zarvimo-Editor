package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.data.model.ImageOverlay
import com.zarvimo.videoeditor.data.model.TextAnimation
import com.zarvimo.videoeditor.data.model.TextOverlay
import com.zarvimo.videoeditor.ui.components.NeonIconButton
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.util.TimeFormat

/**
 * The video surface: a Media3 [PlayerView] (no built-in transport controls — Zarvimo
 * draws its own prev/play/next row over the bottom of the frame, plus a
 * current/total timestamp) with a Compose layer on top that renders whichever
 * [TextOverlay]s and [ImageOverlay]s are active at [positionUs], at their
 * authored normalized position. This Compose layer is preview-only; the
 * exported file gets its overlays burned in separately by
 * [com.zarvimo.videoeditor.export.VideoExporter] — including the honest
 * exception that a text overlay's entrance [TextAnimation] previews here but
 * is not baked into the exported video (see [TextOverlayRenderer]'s doc
 * comment for why).
 */
@OptIn(UnstableApi::class)
@Composable
fun PreviewPlayerView(
    player: ExoPlayer,
    overlays: List<TextOverlay>,
    positionUs: Long,
    modifier: Modifier = Modifier,
    imageOverlays: List<ImageOverlay> = emptyList(),
    totalDurationUs: Long? = null,
    isPlaying: Boolean = false,
    onPlayPause: (() -> Unit)? = null,
    onPreviousClip: (() -> Unit)? = null,
    onNextClip: (() -> Unit)? = null,
    onOverlayClick: (TextOverlay) -> Unit = {},
    onImageOverlayClick: (ImageOverlay) -> Unit = {}
) {
    var frameSize by remember { mutableStateOf(IntSize.Zero) }

    Box(
        modifier = modifier
            .background(Color.Black)
            .onSizeChanged { frameSize = it }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                PlayerView(context).apply {
                    this.player = player
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
            update = { view -> view.player = player }
        )

        if (frameSize.width > 0 && frameSize.height > 0) {
            val density = LocalDensity.current

            imageOverlays.filter { it.isVisibleAt(positionUs) }.forEach { overlay ->
                val widthDp = with(density) { (overlay.widthFraction * frameSize.width).toDp() }
                val heightDp = with(density) { (overlay.heightFraction * frameSize.height).toDp() }
                val centerXDp = with(density) { (overlay.xFraction * frameSize.width).toDp() }
                val centerYDp = with(density) { (overlay.yFraction * frameSize.height).toDp() }
                AsyncImage(
                    model = overlay.sourceUri,
                    contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(x = centerXDp - widthDp / 2, y = centerYDp - heightDp / 2)
                        .width(widthDp)
                        .height(heightDp)
                        .graphicsLayer {
                            rotationZ = overlay.rotationDegrees
                            alpha = overlay.opacity.coerceIn(0f, 1f)
                        }
                        .clickable { onImageOverlayClick(overlay) }
                )
            }

            overlays.filter { it.isVisibleAt(positionUs) }.forEach { overlay ->
                val xDp = with(density) { (overlay.xFraction * frameSize.width).toDp() }
                val yDp = with(density) { (overlay.yFraction * frameSize.height).toDp() }
                val progress = overlay.animationProgressAt(positionUs)
                val slideOffsetDp = if (overlay.animation == TextAnimation.SLIDE_UP) (1f - progress) * 32 else 0f

                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(x = xDp, y = yDp + slideOffsetDp.dp)
                        .graphicsLayer {
                            alpha = if (overlay.animation == TextAnimation.NONE) 1f else progress
                            val scale = if (overlay.animation == TextAnimation.POP) 0.6f + 0.4f * progress else 1f
                            scaleX = scale
                            scaleY = scale
                        }
                        .let { base ->
                            if (overlay.backgroundColorArgb != null) {
                                base
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(overlay.backgroundColorArgb))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            } else base
                        }
                        .clickable { onOverlayClick(overlay) }
                ) {
                    Text(
                        text = overlay.text,
                        color = Color(overlay.colorArgb),
                        fontSize = overlay.fontSizeSp.sp,
                        fontWeight = if (overlay.bold) FontWeight.Bold else FontWeight.Normal,
                        fontStyle = if (overlay.italic) FontStyle.Italic else FontStyle.Normal
                    )
                }
            }
        }

        // Transport row: current/total timestamp + prev | play/pause | next, drawn
        // over the bottom of the frame — only when the caller wired up transport
        // callbacks, so this view still works standalone (e.g. a future thumbnail
        // preview) without forcing every caller to supply them.
        if (onPlayPause != null) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.45f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = TimeFormat.formatUs(positionUs),
                    color = Color.White,
                    fontSize = 12.sp
                )

                Spacer(Modifier.weight(1f))

                if (onPreviousClip != null) {
                    NeonIconButton(
                        icon = Icons.Filled.SkipPrevious,
                        contentDescription = stringResource(id = R.string.editor_previous_clip),
                        onClick = onPreviousClip,
                        size = 34.dp
                    )
                    Spacer(Modifier.width(10.dp))
                }

                NeonIconButton(
                    icon = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = stringResource(
                        id = if (isPlaying) R.string.editor_pause else R.string.editor_play
                    ),
                    onClick = onPlayPause,
                    tint = ZarvimoElectricBlue,
                    size = 42.dp
                )

                if (onNextClip != null) {
                    Spacer(Modifier.width(10.dp))
                    NeonIconButton(
                        icon = Icons.Filled.SkipNext,
                        contentDescription = stringResource(id = R.string.editor_next_clip),
                        onClick = onNextClip,
                        size = 34.dp
                    )
                }

                Spacer(Modifier.weight(1f))

                Text(
                    text = TimeFormat.formatUs(totalDurationUs ?: 0L),
                    color = Color.White,
                    fontSize = 12.sp
                )
            }
        }
    }
}
