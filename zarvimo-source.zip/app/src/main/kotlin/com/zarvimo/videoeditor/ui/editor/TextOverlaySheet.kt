package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.data.model.TextAnimation
import com.zarvimo.videoeditor.data.model.TextOverlay
import com.zarvimo.videoeditor.ui.components.NeonGradientButton
import com.zarvimo.videoeditor.ui.theme.ZarvimoDanger
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoGold
import com.zarvimo.videoeditor.ui.theme.ZarvimoMagenta
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary
import com.zarvimo.videoeditor.ui.theme.ZarvimoViolet
import java.util.UUID

private val OVERLAY_COLOR_CHOICES = listOf(
    Color.White, ZarvimoElectricBlue, ZarvimoViolet, ZarvimoMagenta, ZarvimoGold
)
private val BACKGROUND_COLOR_CHOICES = listOf(
    Color.Black, Color.White, ZarvimoViolet, ZarvimoMagenta
)

/**
 * Bottom sheet to add a new text overlay (anchored at [currentPlayheadUs]) or
 * edit/remove an existing one. Duration is authored as a simple 1–10s slider
 * from the start time rather than two separate time pickers, which is enough
 * precision for captions/titles. Bold/italic and an optional background chip
 * bake exactly as previewed; [TextAnimation] previews live but is not baked
 * into the exported file — see [TextOverlayRenderer]'s doc comment for why.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TextOverlaySheet(
    existingOverlay: TextOverlay?,
    currentPlayheadUs: Long,
    onSave: (TextOverlay) -> Unit,
    onRemove: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var text by remember(existingOverlay) { mutableStateOf(existingOverlay?.text ?: "") }
    var color by remember(existingOverlay) {
        mutableStateOf(existingOverlay?.colorArgb?.let { Color(it) } ?: Color.White)
    }
    var bold by remember(existingOverlay) { mutableStateOf(existingOverlay?.bold ?: false) }
    var italic by remember(existingOverlay) { mutableStateOf(existingOverlay?.italic ?: false) }
    var backgroundEnabled by remember(existingOverlay) { mutableStateOf(existingOverlay?.backgroundColorArgb != null) }
    var backgroundColor by remember(existingOverlay) {
        mutableStateOf(existingOverlay?.backgroundColorArgb?.let { Color(it) } ?: Color.Black)
    }
    var animation by remember(existingOverlay) { mutableStateOf(existingOverlay?.animation ?: TextAnimation.NONE) }
    val startUs = existingOverlay?.startTimeUs ?: currentPlayheadUs
    var durationSeconds by remember(existingOverlay) {
        mutableFloatStateOf(
            existingOverlay
                ?.let { (it.endTimeUs - it.startTimeUs) / 1_000_000f }
                ?.coerceIn(1f, 10f)
                ?: 3f
        )
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
            Text(
                text = stringResource(id = R.string.text_overlay_title),
                style = MaterialTheme.typography.titleMedium
            )

            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(stringResource(id = R.string.text_overlay_hint)) },
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
            )

            Row(modifier = Modifier.padding(top = 12.dp)) {
                FilterChip(
                    selected = bold,
                    onClick = { bold = !bold },
                    label = { Text(stringResource(id = R.string.text_overlay_bold)) },
                    modifier = Modifier.padding(end = 8.dp),
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                )
                FilterChip(
                    selected = italic,
                    onClick = { italic = !italic },
                    label = { Text(stringResource(id = R.string.text_overlay_italic)) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                )
            }

            Text(
                text = stringResource(id = R.string.text_overlay_color),
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OVERLAY_COLOR_CHOICES.forEach { swatch ->
                    Row(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(swatch)
                            .border(
                                width = if (swatch == color) 3.dp else 1.dp,
                                color = if (swatch == color) ZarvimoElectricBlue else ZarvimoTextSecondary,
                                shape = CircleShape
                            )
                            .clickable { color = swatch }
                    ) {}
                }
            }

            Text(
                text = stringResource(id = R.string.text_overlay_animation),
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
            )
            Row {
                TextAnimation.entries.forEach { option ->
                    FilterChip(
                        selected = animation == option,
                        onClick = { animation = option },
                        label = { Text(option.label) },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(id = R.string.text_overlay_background),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ZarvimoTextSecondary,
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = backgroundEnabled,
                    onClick = { backgroundEnabled = !backgroundEnabled },
                    label = { Text(stringResource(id = if (backgroundEnabled) R.string.text_overlay_on else R.string.text_overlay_off)) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                )
            }
            if (backgroundEnabled) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 8.dp)) {
                    BACKGROUND_COLOR_CHOICES.forEach { swatch ->
                        Row(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(swatch)
                                .border(
                                    width = if (swatch == backgroundColor) 3.dp else 1.dp,
                                    color = if (swatch == backgroundColor) ZarvimoElectricBlue else ZarvimoTextSecondary,
                                    shape = CircleShape
                                )
                                .clickable { backgroundColor = swatch }
                        ) {}
                    }
                }
            }

            Text(
                text = "Duration: ${durationSeconds.toInt()}s",
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 16.dp)
            )
            Slider(
                value = durationSeconds,
                onValueChange = { durationSeconds = it },
                valueRange = 1f..10f,
                steps = 8
            )

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                horizontalArrangement = Arrangement.End
            ) {
                if (onRemove != null) {
                    TextButton(onClick = { onRemove(); onDismiss() }) {
                        Text(
                            text = stringResource(id = R.string.text_overlay_remove),
                            color = ZarvimoDanger
                        )
                    }
                }
            }

            NeonGradientButton(
                text = stringResource(
                    id = if (existingOverlay == null) R.string.text_overlay_add else R.string.text_overlay_update
                ),
                enabled = text.isNotBlank(),
                onClick = {
                    val endUs = startUs + (durationSeconds * 1_000_000L).toLong()
                    onSave(
                        TextOverlay(
                            id = existingOverlay?.id ?: UUID.randomUUID().toString(),
                            text = text,
                            colorArgb = color.toArgb(),
                            startTimeUs = startUs,
                            endTimeUs = endUs,
                            xFraction = existingOverlay?.xFraction ?: 0.5f,
                            yFraction = existingOverlay?.yFraction ?: 0.85f,
                            fontSizeSp = existingOverlay?.fontSizeSp ?: 28f,
                            bold = bold,
                            italic = italic,
                            backgroundColorArgb = if (backgroundEnabled) backgroundColor.toArgb() else null,
                            animation = animation
                        )
                    )
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            )
        }
    }
}
