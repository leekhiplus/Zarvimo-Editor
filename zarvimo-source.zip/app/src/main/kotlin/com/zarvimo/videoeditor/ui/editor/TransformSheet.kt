package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Rotate90DegreesCw
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.data.model.VideoClip
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary

private val SPEED_PRESETS = listOf(0.25f, 0.5f, 1f, 1.5f, 2f, 4f)

/**
 * Bottom sheet for one clip's crop/rotate/flip/speed. Crop is authored as a
 * margin from each edge (0%–45%), which maps directly onto
 * [VideoClip.withCrop]'s 0f..1f frame fractions; rotate/flip are discrete
 * actions rather than sliders since 90°-turn and mirror are the only
 * supported transforms (matching what [com.zarvimo.videoeditor.export.EffectsFactory]
 * can actually render). Every change commits immediately except the crop
 * sliders, which commit on release like [VolumeControlSheet]'s pattern, so a
 * drag doesn't flood undo history.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransformSheet(
    clip: VideoClip,
    onCropChanged: (left: Float, top: Float, right: Float, bottom: Float) -> Unit,
    onClearCrop: () -> Unit,
    onRotate: () -> Unit,
    onToggleFlipHorizontal: () -> Unit,
    onToggleFlipVertical: () -> Unit,
    onSpeedChanged: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    var leftMargin by remember(clip.id) { mutableFloatStateOf(clip.cropLeftFraction) }
    var topMargin by remember(clip.id) { mutableFloatStateOf(clip.cropTopFraction) }
    var rightMargin by remember(clip.id) { mutableFloatStateOf(1f - clip.cropRightFraction) }
    var bottomMargin by remember(clip.id) { mutableFloatStateOf(1f - clip.cropBottomFraction) }

    fun commitCrop() {
        onCropChanged(leftMargin, topMargin, 1f - rightMargin, 1f - bottomMargin)
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
            Text(
                text = stringResource(id = R.string.transform_title),
                style = MaterialTheme.typography.titleMedium
            )

            Text(
                text = stringResource(id = R.string.transform_rotate_flip),
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
            )
            Row {
                FilterChip(
                    selected = false,
                    onClick = onRotate,
                    label = { Text(stringResource(id = R.string.transform_rotate, clip.rotationQuarterTurns * 90)) },
                    leadingIcon = { Icon(Icons.Filled.Rotate90DegreesCw, contentDescription = null) },
                    modifier = Modifier.padding(end = 8.dp)
                )
                FilterChip(
                    selected = clip.flipHorizontal,
                    onClick = onToggleFlipHorizontal,
                    label = { Text(stringResource(id = R.string.transform_flip_horizontal)) },
                    leadingIcon = { Icon(Icons.Filled.Flip, contentDescription = null) },
                    modifier = Modifier.padding(end = 8.dp),
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                )
                FilterChip(
                    selected = clip.flipVertical,
                    onClick = onToggleFlipVertical,
                    label = { Text(stringResource(id = R.string.transform_flip_vertical)) },
                    leadingIcon = { Icon(Icons.Filled.Flip, contentDescription = null) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                )
            }

            Divider(modifier = Modifier.padding(vertical = 16.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = stringResource(id = R.string.transform_crop),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ZarvimoTextSecondary,
                    modifier = Modifier.weight(1f)
                )
                if (clip.hasCrop) {
                    TextButton(onClick = {
                        leftMargin = 0f; topMargin = 0f; rightMargin = 0f; bottomMargin = 0f
                        onClearCrop()
                    }) {
                        Text(stringResource(id = R.string.transform_crop_reset))
                    }
                }
            }
            CropMarginSlider(
                label = stringResource(id = R.string.transform_crop_left),
                value = leftMargin,
                onValueChange = { leftMargin = it },
                onValueChangeFinished = ::commitCrop
            )
            CropMarginSlider(
                label = stringResource(id = R.string.transform_crop_top),
                value = topMargin,
                onValueChange = { topMargin = it },
                onValueChangeFinished = ::commitCrop
            )
            CropMarginSlider(
                label = stringResource(id = R.string.transform_crop_right),
                value = rightMargin,
                onValueChange = { rightMargin = it },
                onValueChangeFinished = ::commitCrop
            )
            CropMarginSlider(
                label = stringResource(id = R.string.transform_crop_bottom),
                value = bottomMargin,
                onValueChange = { bottomMargin = it },
                onValueChangeFinished = ::commitCrop
            )

            Divider(modifier = Modifier.padding(vertical = 16.dp))

            Text(
                text = stringResource(id = R.string.transform_speed),
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row {
                SPEED_PRESETS.forEach { speed ->
                    FilterChip(
                        selected = clip.speed == speed,
                        onClick = { onSpeedChanged(speed) },
                        label = { Text("${speed}x") },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ZarvimoElectricBlue)
                    )
                }
            }
            if (clip.speed != 1f) {
                Text(
                    text = stringResource(id = R.string.transform_speed_audio_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = ZarvimoTextSecondary,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun CropMarginSlider(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit
) {
    Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = ZarvimoTextSecondary,
            modifier = Modifier.padding(top = 14.dp, end = 8.dp)
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            onValueChangeFinished = onValueChangeFinished,
            valueRange = 0f..0.45f,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = ZarvimoElectricBlue,
                activeTrackColor = ZarvimoElectricBlue
            )
        )
    }
}
