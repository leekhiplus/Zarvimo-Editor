package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue

/**
 * Bottom sheet with a single slider for the selected clip's volume, 0%–200%
 * (100% = unchanged). Commits via [onVolumeChanged] on release, not on every
 * slider tick, so a drag doesn't flood undo history — see [TimelineView]'s
 * trim handles for the same pattern.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolumeControlSheet(
    initialVolume: Float,
    onVolumeChanged: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    var liveVolume by remember(initialVolume) { mutableFloatStateOf(initialVolume) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
            Text(
                text = stringResource(id = R.string.editor_volume),
                style = MaterialTheme.typography.titleMedium
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (liveVolume == 0f) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp,
                    contentDescription = null,
                    tint = ZarvimoElectricBlue
                )
                Slider(
                    value = liveVolume,
                    onValueChange = { liveVolume = it },
                    onValueChangeFinished = { onVolumeChanged(liveVolume) },
                    valueRange = 0f..2f,
                    modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = ZarvimoElectricBlue,
                        activeTrackColor = ZarvimoElectricBlue
                    )
                )
                Text(
                    text = "${(liveVolume * 100).toInt()}%",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
