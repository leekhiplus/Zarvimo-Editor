package com.zarvimo.videoeditor.ui.picker

import android.app.Application
import android.content.ContentUris
import android.net.Uri
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** One video found on the device via [MediaStore]. */
data class DeviceVideo(
    val uri: Uri,
    val displayName: String,
    val durationUs: Long,
    val sizeBytes: Long
)

data class MediaPickerUiState(
    val videos: List<DeviceVideo> = emptyList(),
    val selectedUris: Set<Uri> = emptySet(),
    val isLoading: Boolean = true
)

class MediaPickerViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(MediaPickerUiState())
    val uiState: StateFlow<MediaPickerUiState> = _uiState.asStateFlow()

    init {
        loadVideos()
    }

    fun loadVideos() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val videos = queryDeviceVideos()
            _uiState.value = _uiState.value.copy(videos = videos, isLoading = false)
        }
    }

    fun toggleSelection(uri: Uri) {
        val current = _uiState.value.selectedUris
        _uiState.value = _uiState.value.copy(
            selectedUris = if (uri in current) current - uri else current + uri
        )
    }

    fun selectedVideos(): List<DeviceVideo> =
        _uiState.value.videos.filter { it.uri in _uiState.value.selectedUris }

    private suspend fun queryDeviceVideos(): List<DeviceVideo> = withContext(Dispatchers.IO) {
        val results = mutableListOf<DeviceVideo>()
        val resolver = getApplication<android.app.Application>().contentResolver
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE
        )
        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        runCatching {
            resolver.query(collection, projection, null, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val uri = ContentUris.withAppendedId(collection, id)
                    results += DeviceVideo(
                        uri = uri,
                        displayName = cursor.getString(nameCol) ?: "Video",
                        durationUs = cursor.getLong(durationCol) * 1000L,
                        sizeBytes = cursor.getLong(sizeCol)
                    )
                }
            }
        }
        results
    }
}
