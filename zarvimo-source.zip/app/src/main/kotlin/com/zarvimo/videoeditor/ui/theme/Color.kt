package com.zarvimo.videoeditor.ui.theme

import androidx.compose.ui.graphics.Color

// Core neon black/navy palette — mirrors res/values/colors.xml so the native
// splash window and Compose UI agree before Compose even attaches.
val ZarvimoBackground = Color(0xFF0A0B1E)
val ZarvimoSurface = Color(0xFF12152E)
val ZarvimoSurfaceVariant = Color(0xFF1C2044)
val ZarvimoSurfaceElevated = Color(0xFF242A52)

val ZarvimoElectricBlue = Color(0xFF00D9FF)
val ZarvimoViolet = Color(0xFF8B5CF6)
val ZarvimoMagenta = Color(0xFFFF2D9E)
val ZarvimoGold = Color(0xFFFFC947)

val ZarvimoTextPrimary = Color(0xFFF5F6FF)
val ZarvimoTextSecondary = Color(0xFF9CA3C7)
val ZarvimoDanger = Color(0xFFFF4D6D)
val ZarvimoSuccess = Color(0xFF2EE6A6)

/** The gradient brush colors used for primary CTAs and the Zarvimo wordmark. */
val ZarvimoGradientColors = listOf(ZarvimoElectricBlue, ZarvimoViolet, ZarvimoMagenta)
