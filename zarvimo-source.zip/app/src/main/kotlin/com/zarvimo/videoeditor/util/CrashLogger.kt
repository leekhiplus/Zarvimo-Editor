package com.zarvimo.videoeditor.util

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * A minimal crash-log-to-file fallback for a user who has no way to pull a
 * real `logcat`/`adb` trace off their phone. [install] wraps the process's
 * default uncaught-exception handler: it writes the full exception (with
 * its cause chain, which is where the actually useful detail usually is —
 * see [com.zarvimo.videoeditor.playback.PlayerManager]'s own
 * `describeThrowable`) to a plain text file in app-private storage, then
 * hands the exception on to whatever handler was previously installed, so
 * the crash still behaves exactly as it would have otherwise (the "has
 * stopped" dialog, the process dying) — this never tries to suppress or
 * recover from the crash, only to leave a readable trace of it behind.
 *
 * [readAndClear] is called once on the next app launch (see
 * `MainActivity`): if a log is there, it's shown with a "Share" button so
 * the person can forward the exact text — which is far more diagnostic
 * value than "it crashed" — without installing a separate logcat app.
 *
 * This can only catch a genuine JVM/Kotlin exception. A native-code crash
 * (a `SIGSEGV` inside a codec, for instance — a real possibility for some
 * malformed or very large video files) kills the process before any Java
 * handler, including this one, ever runs, and leaves no file here; that
 * case is undiagnosable without a real `adb logcat` capture.
 */
object CrashLogger {

    private const val FILE_NAME = "zarvimo_last_crash.txt"

    fun install(context: Context) {
        val appContext = context.applicationContext
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching { writeCrashLog(appContext, throwable) }
            previousHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun writeCrashLog(context: Context, throwable: Throwable) {
        val stringWriter = StringWriter()
        throwable.printStackTrace(PrintWriter(stringWriter))
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val content = "Zarvimo crash at $timestamp\n\n$stringWriter"
        File(context.filesDir, FILE_NAME).writeText(content)
    }

    /** Returns the last saved crash log, if any, and deletes it so it's only shown once. */
    fun readAndClear(context: Context): String? {
        val file = File(context.applicationContext.filesDir, FILE_NAME)
        if (!file.exists()) return null
        return runCatching { file.readText() }
            .onSuccess { file.delete() }
            .getOrNull()
    }
}
