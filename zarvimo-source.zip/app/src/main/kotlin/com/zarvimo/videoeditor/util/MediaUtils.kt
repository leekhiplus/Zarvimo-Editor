package com.zarvimo.videoeditor.util

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Small helpers for reading metadata off a content:// video Uri. */
object MediaUtils {

    /**
     * Returns the video's duration in microseconds, or 0L if it can't be
     * read. Deliberately catches [Throwable], not just [Exception]:
     * [MediaMetadataRetriever] is a thin wrapper over native/platform code,
     * and some devices/codecs throw an [OutOfMemoryError] or another
     * [Error] — not an [Exception] — on certain large or malformed files,
     * which a plain `catch (Exception)` would let through to crash the app.
     * The caller ([com.zarvimo.videoeditor.ui.editor.EditorViewModel.addClips])
     * is responsible for treating a 0L result as "this file couldn't be
     * imported" rather than silently building a zero-duration clip.
     */
    suspend fun durationUs(context: Context, uri: Uri): Long = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durationMs = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            durationMs * 1000L
        } catch (e: CancellationException) {
            throw e // let coroutine cancellation keep propagating, never swallow it
        } catch (_: Throwable) {
            0L
        } finally {
            runCatching { retriever.release() }
        }
    }

    /** Best-effort display name for a content:// Uri, falling back to its last path segment. */
    fun displayName(context: Context, uri: Uri): String {
        runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0 && cursor.moveToFirst()) {
                    return cursor.getString(nameIndex) ?: "Clip"
                }
            }
        }
        return uri.lastPathSegment ?: "Clip"
    }
}
