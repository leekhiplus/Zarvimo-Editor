package com.zarvimo.videoeditor

import com.zarvimo.videoeditor.data.ClipOrdering
import com.zarvimo.videoeditor.data.model.VideoClip
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertSame
import org.junit.Test

class ClipOrderingTest {

    private fun clip(id: String, order: Int) =
        VideoClip(id = id, sourceUri = "uri-$id", sourceDurationUs = 1_000_000, order = order)

    @Test
    fun `withDuplicate inserts a copy immediately after the original and renumbers every clip`() {
        val clips = listOf(clip("A", 0), clip("B", 1), clip("C", 2))
        val result = ClipOrdering.withDuplicate(clips, "A", newId = { "A-copy" })

        assertEquals(listOf("A", "A-copy", "B", "C"), result.map { it.id })
        assertEquals(listOf(0, 1, 2, 3), result.map { it.order })
    }

    @Test
    fun `withDuplicate copies the original clip's fields`() {
        val original = VideoClip(id = "A", sourceUri = "uri-A", sourceDurationUs = 5_000_000, order = 0, volume = 1.5f)
        val result = ClipOrdering.withDuplicate(listOf(original), "A", newId = { "A-copy" })
        val copy = result.first { it.id == "A-copy" }

        assertEquals(original.sourceUri, copy.sourceUri)
        assertEquals(original.sourceDurationUs, copy.sourceDurationUs)
        assertEquals(original.volume, copy.volume)
        assertNotEquals(original.id, copy.id)
    }

    @Test
    fun `withDuplicate on an unordered input list still inserts at the correct timeline position`() {
        // Deliberately out of order in the backing list, to prove withDuplicate
        // sorts by `order` first rather than trusting list insertion order —
        // the same guarantee Project.orderedClips makes.
        val clips = listOf(clip("C", 2), clip("A", 0), clip("B", 1))
        val result = ClipOrdering.withDuplicate(clips, "B", newId = { "B-copy" })

        assertEquals(listOf("A", "B", "B-copy", "C"), result.map { it.id })
    }

    @Test
    fun `withDuplicate returns the input unchanged when the clip id isn't found`() {
        val clips = listOf(clip("A", 0), clip("B", 1))
        val result = ClipOrdering.withDuplicate(clips, "missing", newId = { "x" })
        assertSame(clips, result)
    }

    @Test
    fun `withReorder moves a clip to a later position and renumbers every clip`() {
        val clips = listOf(clip("A", 0), clip("B", 1), clip("C", 2))
        val result = ClipOrdering.withReorder(clips, fromIndex = 0, toIndex = 2)

        assertEquals(listOf("B", "C", "A"), result.map { it.id })
        assertEquals(listOf(0, 1, 2), result.map { it.order })
    }

    @Test
    fun `withReorder moves a clip to an earlier position`() {
        val clips = listOf(clip("A", 0), clip("B", 1), clip("C", 2))
        val result = ClipOrdering.withReorder(clips, fromIndex = 2, toIndex = 0)

        assertEquals(listOf("C", "A", "B"), result.map { it.id })
    }

    @Test
    fun `withReorder returns the input unchanged for an out-of-range index`() {
        val clips = listOf(clip("A", 0), clip("B", 1))
        assertSame(clips, ClipOrdering.withReorder(clips, fromIndex = -1, toIndex = 0))
        assertSame(clips, ClipOrdering.withReorder(clips, fromIndex = 0, toIndex = 5))
    }
}
