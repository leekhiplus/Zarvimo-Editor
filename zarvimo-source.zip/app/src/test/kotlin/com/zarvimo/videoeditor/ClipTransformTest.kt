package com.zarvimo.videoeditor

import com.zarvimo.videoeditor.data.model.AudioTrackClip
import com.zarvimo.videoeditor.data.model.ColorAdjustment
import com.zarvimo.videoeditor.data.model.ImageOverlay
import com.zarvimo.videoeditor.data.model.TextAnimation
import com.zarvimo.videoeditor.data.model.TextOverlay
import com.zarvimo.videoeditor.data.model.VideoClip
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

private const val EPSILON = 1e-4f

/**
 * Covers the new crop/speed/rotation math on [VideoClip], the fade math on
 * [AudioTrackClip], and the visibility/animation math on [ImageOverlay] and
 * [TextOverlay] — everything added to the data model in this pass that
 * doesn't need Media3 or Android to exercise.
 */
class ClipTransformTest {

    private fun baseClip(speed: Float = 1f) = VideoClip(
        sourceUri = "x",
        sourceDurationUs = 10_000_000,
        order = 0,
        speed = speed
    )

    // -- VideoClip.withSpeed / timelineDurationUs ---------------------------

    @Test
    fun `withSpeed clamps to the supported 0_25x to 4x range`() {
        assertEquals(VideoClip.MAX_SPEED, baseClip().withSpeed(10f).speed, EPSILON)
        assertEquals(VideoClip.MIN_SPEED, baseClip().withSpeed(0f).speed, EPSILON)
        assertEquals(2f, baseClip().withSpeed(2f).speed, EPSILON)
    }

    @Test
    fun `timelineDurationUs halves at 2x speed and doubles at 0_5x`() {
        val clip = VideoClip(sourceUri = "x", sourceDurationUs = 10_000_000, trimEndUs = 10_000_000, order = 0)
        assertEquals(5_000_000L, clip.withSpeed(2f).timelineDurationUs)
        assertEquals(20_000_000L, clip.withSpeed(0.5f).timelineDurationUs)
        assertEquals(10_000_000L, clip.timelineDurationUs)
    }

    // -- VideoClip.withCrop / hasCrop ----------------------------------------

    @Test
    fun `withCrop clamps each edge into a valid, non-empty rectangle`() {
        val clip = baseClip().withCrop(left = -1f, top = -1f, right = 2f, bottom = 2f)
        assertEquals(0f, clip.cropLeftFraction, EPSILON)
        assertEquals(0f, clip.cropTopFraction, EPSILON)
        assertEquals(1f, clip.cropRightFraction, EPSILON)
        assertEquals(1f, clip.cropBottomFraction, EPSILON)
    }

    @Test
    fun `withCrop never lets right cross left or bottom cross top`() {
        // An inverted request (right less than left) still produces a valid,
        // minimum-width rectangle rather than a crop with negative size.
        val clip = baseClip().withCrop(left = 0.9f, top = 0.9f, right = 0.1f, bottom = 0.1f)
        assertTrue(clip.cropRightFraction > clip.cropLeftFraction)
        assertTrue(clip.cropBottomFraction > clip.cropTopFraction)
    }

    @Test
    fun `hasCrop is false only for the untouched full-frame rectangle`() {
        assertFalse(baseClip().hasCrop)
        assertTrue(baseClip().withCrop(0.1f, 0f, 1f, 1f).hasCrop)
        assertTrue(baseClip().withCrop(0f, 0f, 0.9f, 1f).hasCrop)
    }

    // -- ColorAdjustment.clamped ---------------------------------------------

    @Test
    fun `ColorAdjustment clamped keeps every field within -1f to 1f`() {
        val clamped = ColorAdjustment(brightness = 5f, contrast = -5f, saturation = 2f, temperature = -2f).clamped()
        assertEquals(1f, clamped.brightness, EPSILON)
        assertEquals(-1f, clamped.contrast, EPSILON)
        assertEquals(1f, clamped.saturation, EPSILON)
        assertEquals(-1f, clamped.temperature, EPSILON)
    }

    @Test
    fun `ColorAdjustment isIdentity is true only when every field is exactly zero`() {
        assertTrue(ColorAdjustment().isIdentity)
        assertFalse(ColorAdjustment(brightness = 0.01f).isIdentity)
    }

    // -- AudioTrackClip.isAudibleAt / effectiveVolumeAt ----------------------

    private fun audioTrack(
        startOnTimelineUs: Long = 1_000_000,
        durationUs: Long = 4_000_000,
        volume: Float = 1f,
        fadeInUs: Long = 0L,
        fadeOutUs: Long = 0L
    ) = AudioTrackClip(
        sourceUri = "music",
        sourceDurationUs = durationUs,
        trimEndUs = durationUs,
        startOnTimelineUs = startOnTimelineUs,
        volume = volume,
        fadeInUs = fadeInUs,
        fadeOutUs = fadeOutUs
    )

    @Test
    fun `isAudibleAt is true only within the track's timeline window`() {
        val track = audioTrack(startOnTimelineUs = 1_000_000, durationUs = 4_000_000)
        assertFalse(track.isAudibleAt(999_999))
        assertTrue(track.isAudibleAt(1_000_000))
        assertTrue(track.isAudibleAt(4_999_999))
        assertFalse(track.isAudibleAt(5_000_000))
    }

    @Test
    fun `effectiveVolumeAt is zero outside the track's window`() {
        val track = audioTrack()
        assertEquals(0f, track.effectiveVolumeAt(0L), EPSILON)
    }

    @Test
    fun `effectiveVolumeAt ramps up over the fade-in window and back down over the fade-out window`() {
        val track = audioTrack(
            startOnTimelineUs = 0L,
            durationUs = 10_000_000,
            volume = 1f,
            fadeInUs = 1_000_000,
            fadeOutUs = 1_000_000
        )
        assertEquals(0f, track.effectiveVolumeAt(0L), EPSILON)
        assertEquals(0.5f, track.effectiveVolumeAt(500_000L), EPSILON)
        assertEquals(1f, track.effectiveVolumeAt(1_000_000L), EPSILON)
        assertEquals(1f, track.effectiveVolumeAt(5_000_000L), EPSILON)
        assertEquals(0.5f, track.effectiveVolumeAt(9_500_000L), EPSILON)
        assertEquals(0f, track.effectiveVolumeAt(9_999_999L), EPSILON)
    }

    @Test
    fun `effectiveVolumeAt scales the fade by the track's own volume`() {
        val track = audioTrack(startOnTimelineUs = 0L, durationUs = 10_000_000, volume = 0.5f)
        assertEquals(0.5f, track.effectiveVolumeAt(5_000_000L), EPSILON)
    }

    // -- ImageOverlay.isVisibleAt ---------------------------------------------

    @Test
    fun `ImageOverlay isVisibleAt matches its start-inclusive end-exclusive window`() {
        val overlay = ImageOverlay(sourceUri = "img", startTimeUs = 1_000_000, endTimeUs = 3_000_000)
        assertFalse(overlay.isVisibleAt(999_999))
        assertTrue(overlay.isVisibleAt(1_000_000))
        assertTrue(overlay.isVisibleAt(2_999_999))
        assertFalse(overlay.isVisibleAt(3_000_000))
    }

    // -- TextOverlay.animationProgressAt --------------------------------------

    @Test
    fun `animationProgressAt is always 1f for TextAnimation NONE`() {
        val overlay = TextOverlay(
            text = "hi",
            colorArgb = 0xFFFFFFFF.toInt(),
            startTimeUs = 1_000_000,
            endTimeUs = 5_000_000,
            animation = TextAnimation.NONE
        )
        assertEquals(1f, overlay.animationProgressAt(1_000_000), EPSILON)
        assertEquals(1f, overlay.animationProgressAt(1_000_001), EPSILON)
    }

    @Test
    fun `animationProgressAt ramps 0f to 1f over the animation window then holds`() {
        val overlay = TextOverlay(
            text = "hi",
            colorArgb = 0xFFFFFFFF.toInt(),
            startTimeUs = 1_000_000,
            endTimeUs = 5_000_000,
            animation = TextAnimation.FADE_IN
        )
        val windowUs = TextAnimation.ANIMATION_WINDOW_US
        assertEquals(0f, overlay.animationProgressAt(1_000_000), EPSILON)
        assertEquals(0.5f, overlay.animationProgressAt(1_000_000 + windowUs / 2), EPSILON)
        assertEquals(1f, overlay.animationProgressAt(1_000_000 + windowUs), EPSILON)
        assertEquals(1f, overlay.animationProgressAt(1_000_000 + windowUs * 3), EPSILON)
    }
}
