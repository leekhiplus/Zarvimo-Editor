package com.zarvimo.videoeditor

import com.zarvimo.videoeditor.data.model.ColorAdjustment
import com.zarvimo.videoeditor.data.model.VideoFilterType
import com.zarvimo.videoeditor.export.ColorMatrixFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private const val EPSILON = 1e-4f

class ColorMatrixFactoryTest {

    @Test
    fun `no adjustment and no filter produces the identity matrix`() {
        val matrix = ColorMatrixFactory.buildMatrix(ColorAdjustment(), VideoFilterType.NONE)
        val expected = floatArrayOf(
            1f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f,
            0f, 0f, 1f, 0f,
            0f, 0f, 0f, 1f
        )
        assertMatrixEquals(expected, matrix)
    }

    @Test
    fun `MONO filter collapses every channel to the same luminance weights`() {
        val matrix = ColorMatrixFactory.buildMatrix(ColorAdjustment(), VideoFilterType.MONO)

        // Column-major layout: indices 0,1,2 are the r-output coefficient for
        // each of the r/g/b output rows — a true grayscale matrix makes all
        // three identical (every output channel reads the same mix of input).
        assertEquals(matrix[0], matrix[1], EPSILON)
        assertEquals(matrix[1], matrix[2], EPSILON)
        assertEquals(matrix[4], matrix[5], EPSILON)
        assertEquals(matrix[5], matrix[6], EPSILON)
        assertEquals(matrix[8], matrix[9], EPSILON)
        assertEquals(matrix[9], matrix[10], EPSILON)

        // The three luminance weights (one per input channel) must sum to 1,
        // so a pure white input still maps to pure white output.
        val lumaSum = matrix[0] + matrix[4] + matrix[8]
        assertEquals(1f, lumaSum, EPSILON)

        // No brightness/contrast/temperature offset baked in for a bare MONO filter.
        assertEquals(0f, matrix[12], EPSILON)
        assertEquals(0f, matrix[13], EPSILON)
        assertEquals(0f, matrix[14], EPSILON)
        assertEquals(1f, matrix[15], EPSILON)
    }

    @Test
    fun `positive temperature pushes red up and blue down, negative does the reverse`() {
        val warm = ColorMatrixFactory.buildMatrix(ColorAdjustment(temperature = 1f), VideoFilterType.NONE)
        val cool = ColorMatrixFactory.buildMatrix(ColorAdjustment(temperature = -1f), VideoFilterType.NONE)

        // m03/m23 are the red/blue rows' constant offset (4th column).
        assertTrue("warm should raise the red offset", warm[12] > 0f)
        assertTrue("warm should lower the blue offset", warm[14] < 0f)
        assertTrue("cool should lower the red offset", cool[12] < 0f)
        assertTrue("cool should raise the blue offset", cool[14] > 0f)
    }

    @Test
    fun `brightness and contrast clamp to the valid range before building the matrix`() {
        val overdriven = ColorMatrixFactory.buildMatrix(
            ColorAdjustment(brightness = 5f, contrast = -9f, saturation = 2f, temperature = -8f),
            VideoFilterType.NONE
        )
        val clamped = ColorMatrixFactory.buildMatrix(
            ColorAdjustment(brightness = 1f, contrast = -1f, saturation = 1f, temperature = -1f),
            VideoFilterType.NONE
        )
        assertMatrixEquals(clamped, overdriven)
    }

    private fun assertMatrixEquals(expected: FloatArray, actual: FloatArray) {
        assertEquals(expected.size, actual.size)
        for (i in expected.indices) {
            assertEquals("mismatch at index $i", expected[i], actual[i], EPSILON)
        }
    }
}
