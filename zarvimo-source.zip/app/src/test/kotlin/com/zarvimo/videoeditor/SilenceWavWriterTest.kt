package com.zarvimo.videoeditor

import com.zarvimo.videoeditor.export.SilenceWavWriter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class SilenceWavWriterTest {

    private fun ascii(bytes: ByteArray, offset: Int, length: Int): String =
        String(bytes, offset, length, Charsets.US_ASCII)

    private fun leInt(bytes: ByteArray, offset: Int): Long {
        val buffer = ByteBuffer.wrap(bytes, offset, 4).order(ByteOrder.LITTLE_ENDIAN)
        return buffer.int.toLong() and 0xFFFFFFFFL
    }

    private fun leShort(bytes: ByteArray, offset: Int): Int {
        val buffer = ByteBuffer.wrap(bytes, offset, 2).order(ByteOrder.LITTLE_ENDIAN)
        return buffer.short.toInt() and 0xFFFF
    }

    @Test
    fun `header has the canonical 44-byte RIFF-WAVE-fmt-data layout`() {
        val header = SilenceWavWriter.buildWavHeader(1_000_000L)

        assertEquals(44, header.size)
        assertEquals("RIFF", ascii(header, 0, 4))
        assertEquals("WAVE", ascii(header, 8, 4))
        assertEquals("fmt ", ascii(header, 12, 4))
        assertEquals("data", ascii(header, 36, 4))
    }

    @Test
    fun `fmt chunk describes mono 16-bit 44_1kHz PCM`() {
        val header = SilenceWavWriter.buildWavHeader(1_000_000L)

        assertEquals(16L, leInt(header, 16)) // fmt chunk size
        assertEquals(1, leShort(header, 20)) // PCM format tag
        assertEquals(1, leShort(header, 22)) // mono
        assertEquals(44_100L, leInt(header, 24)) // sample rate
        assertEquals(88_200L, leInt(header, 28)) // byte rate = sampleRate * channels * bitsPerSample/8
        assertEquals(2, leShort(header, 32)) // block align
        assertEquals(16, leShort(header, 34)) // bits per sample
    }

    @Test
    fun `one second of silence sizes the data chunk to exactly one second of PCM`() {
        val header = SilenceWavWriter.buildWavHeader(1_000_000L)
        val dataSize = leInt(header, 40)
        assertEquals(44_100L * 2, dataSize) // 44100 samples/sec * 2 bytes/sample

        val riffChunkSize = leInt(header, 4)
        assertEquals(dataSize + 36, riffChunkSize)
    }

    @Test
    fun `zero duration produces a zero-length data chunk, not an error`() {
        val header = SilenceWavWriter.buildWavHeader(0L)
        assertEquals(0L, leInt(header, 40))
    }

    @Test
    fun `writeSilence produces a file whose length matches the header's declared data size`() {
        val tempDir = createTempDir(prefix = "zarvimo-silence-test")
        try {
            val durationUs = 250_000L // quarter second
            val file = SilenceWavWriter.writeSilence(tempDir, durationUs, fileName = "test.wav")
            val header = SilenceWavWriter.buildWavHeader(durationUs)
            val dataSize = leInt(header, 40)

            assertTrue(file.exists())
            assertEquals(44L + dataSize, file.length())
        } finally {
            tempDir.deleteRecursively()
        }
    }

    private fun createTempDir(prefix: String): File =
        File.createTempFile(prefix, "").let { f ->
            f.delete()
            f.mkdirs()
            f
        }
}
