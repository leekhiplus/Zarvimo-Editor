package com.zarvimo.videoeditor

import com.zarvimo.videoeditor.util.TimeFormat
import org.junit.Assert.assertEquals
import org.junit.Test

class TimeFormatTest {

    @Test
    fun `formatUs renders zero as 0 colon 00`() {
        assertEquals("0:00", TimeFormat.formatUs(0))
    }

    @Test
    fun `formatUs renders sub-minute durations as M colon SS`() {
        assertEquals("1:05", TimeFormat.formatUs(65_000_000))
    }

    @Test
    fun `formatUs renders hour-plus durations as H colon MM colon SS`() {
        assertEquals("1:01:01", TimeFormat.formatUs(3_661_000_000))
    }

    @Test
    fun `formatUs clamps negative durations to zero`() {
        assertEquals("0:00", TimeFormat.formatUs(-5_000_000))
    }

    @Test
    fun `formatUsPrecise includes one decimal place`() {
        assertEquals("0:01.2", TimeFormat.formatUsPrecise(1_250_000))
    }

    @Test
    fun `usToMs and msToUs are inverse conversions`() {
        val originalUs = 5_432_000L
        assertEquals(originalUs, TimeFormat.msToUs(TimeFormat.usToMs(originalUs)))
    }
}
