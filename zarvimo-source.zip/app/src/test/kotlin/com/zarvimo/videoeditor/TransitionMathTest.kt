package com.zarvimo.videoeditor

import com.zarvimo.videoeditor.export.TransitionMath
import org.junit.Assert.assertEquals
import org.junit.Test

private const val EPSILON = 1e-4f

class TransitionMathTest {

    @Test
    fun `no transition in either direction is always fully transparent`() {
        val alpha = TransitionMath.blackOverlayAlpha(
            positionInClipUs = 0L,
            clipDurationUs = 5_000_000L,
            fadeInFromBlack = false,
            fadeOutToBlack = false,
            transitionDurationUs = 500_000L
        )
        assertEquals(0f, alpha, EPSILON)
    }

    @Test
    fun `a zero or negative transition duration is always fully transparent`() {
        val alpha = TransitionMath.blackOverlayAlpha(
            positionInClipUs = 0L,
            clipDurationUs = 5_000_000L,
            fadeInFromBlack = true,
            fadeOutToBlack = true,
            transitionDurationUs = 0L
        )
        assertEquals(0f, alpha, EPSILON)
    }

    @Test
    fun `fade-in from black starts fully black and ramps to transparent`() {
        val transitionUs = 500_000L
        val atStart = TransitionMath.blackOverlayAlpha(0L, 5_000_000L, fadeInFromBlack = true, fadeOutToBlack = false, transitionDurationUs = transitionUs)
        val atHalfway = TransitionMath.blackOverlayAlpha(transitionUs / 2, 5_000_000L, fadeInFromBlack = true, fadeOutToBlack = false, transitionDurationUs = transitionUs)
        val atEnd = TransitionMath.blackOverlayAlpha(transitionUs, 5_000_000L, fadeInFromBlack = true, fadeOutToBlack = false, transitionDurationUs = transitionUs)
        val wellAfter = TransitionMath.blackOverlayAlpha(transitionUs * 4, 5_000_000L, fadeInFromBlack = true, fadeOutToBlack = false, transitionDurationUs = transitionUs)

        assertEquals(1f, atStart, EPSILON)
        assertEquals(0.5f, atHalfway, EPSILON)
        assertEquals(0f, atEnd, EPSILON)
        assertEquals(0f, wellAfter, EPSILON)
    }

    @Test
    fun `fade-out to black ramps from transparent to fully black at the clip's end`() {
        val transitionUs = 500_000L
        val clipDuration = 5_000_000L
        val wellBeforeEnd = TransitionMath.blackOverlayAlpha(0L, clipDuration, fadeInFromBlack = false, fadeOutToBlack = true, transitionDurationUs = transitionUs)
        val atTransitionStart = TransitionMath.blackOverlayAlpha(clipDuration - transitionUs, clipDuration, fadeInFromBlack = false, fadeOutToBlack = true, transitionDurationUs = transitionUs)
        val atHalfway = TransitionMath.blackOverlayAlpha(clipDuration - transitionUs / 2, clipDuration, fadeInFromBlack = false, fadeOutToBlack = true, transitionDurationUs = transitionUs)
        val atVeryEnd = TransitionMath.blackOverlayAlpha(clipDuration, clipDuration, fadeInFromBlack = false, fadeOutToBlack = true, transitionDurationUs = transitionUs)

        assertEquals(0f, wellBeforeEnd, EPSILON)
        assertEquals(0f, atTransitionStart, EPSILON)
        assertEquals(0.5f, atHalfway, EPSILON)
        assertEquals(1f, atVeryEnd, EPSILON)
    }

    @Test
    fun `a clip that both fades in and out takes the louder (more opaque) of the two at any point`() {
        // A very short clip where the fade windows overlap: right at the start,
        // the fade-in wants fully black (1f) while the fade-out wants fully
        // transparent (0f) — the overlay must show the fade-in's black, not
        // average the two away to gray.
        val alpha = TransitionMath.blackOverlayAlpha(
            positionInClipUs = 0L,
            clipDurationUs = 1_000_000L,
            fadeInFromBlack = true,
            fadeOutToBlack = true,
            transitionDurationUs = 500_000L
        )
        assertEquals(1f, alpha, EPSILON)
    }

    @Test
    fun `alpha never leaves the 0f to 1f range`() {
        val alpha = TransitionMath.blackOverlayAlpha(
            positionInClipUs = -1_000_000L,
            clipDurationUs = 5_000_000L,
            fadeInFromBlack = true,
            fadeOutToBlack = false,
            transitionDurationUs = 500_000L
        )
        assertEquals(1f, alpha, EPSILON)
    }
}
