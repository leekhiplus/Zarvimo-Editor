package com.zarvimo.videoeditor

import com.zarvimo.videoeditor.data.UndoRedoManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UndoRedoManagerTest {

    @Test
    fun `push updates current state`() {
        val manager = UndoRedoManager(initial = 0)
        manager.push(1)
        assertEquals(1, manager.current())
    }

    @Test
    fun `undo reverts to the previous state`() {
        val manager = UndoRedoManager(initial = 0)
        manager.push(1)
        manager.push(2)
        assertEquals(1, manager.undo())
        assertEquals(0, manager.undo())
    }

    @Test
    fun `redo re-applies an undone state`() {
        val manager = UndoRedoManager(initial = 0)
        manager.push(1)
        manager.push(2)
        manager.undo()
        assertEquals(2, manager.redo())
    }

    @Test
    fun `a new push after undo clears the redo stack`() {
        val manager = UndoRedoManager(initial = 0)
        manager.push(1)
        manager.push(2)
        manager.undo()
        manager.push(99)
        assertFalse(manager.canRedo)
        assertEquals(99, manager.current())
    }

    @Test
    fun `canUndo and canRedo reflect available history`() {
        val manager = UndoRedoManager(initial = 0)
        assertFalse(manager.canUndo)
        assertFalse(manager.canRedo)
        manager.push(1)
        assertTrue(manager.canUndo)
        manager.undo()
        assertTrue(manager.canRedo)
    }

    @Test
    fun `pushing an equal state is a no-op`() {
        val manager = UndoRedoManager(initial = "a")
        manager.push("a")
        assertFalse(manager.canUndo)
    }

    @Test
    fun `undo stack is bounded by maxHistory`() {
        val manager = UndoRedoManager(initial = 0, maxHistory = 3)
        for (i in 1..10) manager.push(i)
        var undoCount = 0
        while (manager.canUndo) {
            manager.undo()
            undoCount++
        }
        assertEquals(3, undoCount)
    }

    @Test
    fun `reset clears history and sets a new current state`() {
        val manager = UndoRedoManager(initial = 0)
        manager.push(1)
        manager.push(2)
        manager.reset(100)
        assertEquals(100, manager.current())
        assertFalse(manager.canUndo)
        assertFalse(manager.canRedo)
    }
}
