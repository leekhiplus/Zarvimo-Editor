# Zarvimo Video Editor — Phase 1

A real, working Android video editor built with Kotlin, Jetpack Compose, Gradle
Kotlin DSL, and AndroidX Media3. Premium black/navy UI with electric-blue,
violet and magenta neon accents.

> **Brand note:** this project was originally scaffolded as "Zafronix" and was
> renamed to **Zarvimo** at the user's request before this build — the
> application ID, package name (`com.zarvimo.videoeditor`), app name, launcher
> icon, splash screen and all in-app text use **Zarvimo** throughout.

## What's implemented in Phase 1

- **Splash screen** — animated Zarvimo "Z" logo + wordmark, then routes to the dashboard.
- **Dashboard** — list of saved projects (name, duration, last-edited date), create/delete, empty state.
- **Media picker** — browses on-device videos via `MediaStore` + the standard permission flow (`READ_MEDIA_VIDEO` on API 33+, `READ_EXTERNAL_STORAGE` below), multi-select grid with thumbnails and durations.
- **Editor workspace**
  - Live video preview (Media3 `ExoPlayer` + `PlayerView`) with play/pause and a playhead synced to the timeline.
  - Horizontally scrollable **timeline**: add clips, **reorder** (long-press + drag), **trim** (drag edge handles on the selected clip), **split** at the playhead, **delete** a clip.
  - Per-clip **volume** control (0–200%), previewed live and baked into the export.
  - **Text overlays**: add/edit/remove, positioned and timed, rendered live over the preview and burned into the exported file.
  - **Undo/redo** across every edit (add/trim/split/delete/reorder clips, volume, overlays).
  - **Local project save** — JSON on disk, no cloud dependency.
  - **Export** — renders a real H.264/AAC `.mp4` via Media3 `Transformer`, with a quality picker (720p/1080p/4K), live progress, cancel, and share-sheet on completion.
- **Architecture** — UI (Compose screens/components), timeline (`TimelineView` + gesture handling), project data (`data/model`, `ProjectRepository`, `UndoRedoManager`), playback (`PlayerManager`), and export (`VideoExporter`, `VolumeAudioProcessor`, `TextOverlayRenderer`) are separate, single-purpose modules under `app/src/main/kotlin/com/zarvimo/videoeditor/`, intended to be extended rather than rewritten in Phase 2.

### Known Phase 1 limitation

Text overlays are burned into the **exported** file for the full duration of
every clip they time-overlap, not frame-accurately clipped to their exact
start/end time within that clip (the live preview *does* show them at their
exact configured times, since that's just a Compose layer synced to the
player). This is called out in code at
`export/VideoExporter.kt::buildOverlayEffects`. Phase 2 replaces the
bitmap-overlay effect with a time-windowed shader to close this gap.

## Project structure

```
zarvimo-video-editor/
├── .github/workflows/android-build.yml   # CI: build debug APK + publish GitHub Release
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── kotlin/com/zarvimo/videoeditor/
│       │   │   ├── MainActivity.kt, ZarvimoApplication.kt
│       │   │   ├── data/            # models, ProjectRepository, UndoRedoManager
│       │   │   ├── playback/        # PlayerManager (ExoPlayer wrapper)
│       │   │   ├── export/          # VideoExporter (Media3 Transformer), volume & overlay effects
│       │   │   ├── navigation/      # ZarvimoNavGraph
│       │   │   ├── util/            # TimeFormat, MediaUtils
│       │   │   └── ui/              # theme, splash, dashboard, picker, editor, shared components
│       │   └── res/                 # colors, strings, themes, launcher icon, splash drawable
│       └── test/kotlin/com/zarvimo/videoeditor/   # unit tests
├── gradle/
│   ├── libs.versions.toml           # version catalog
│   └── wrapper/                     # gradle-wrapper.jar + .properties
├── gradlew / gradlew.bat
├── settings.gradle.kts
├── build.gradle.kts
└── gradle.properties
```

## Building it (GitHub Actions -> APK in Releases)

Two ways to use the included workflow (`.github/workflows/android-build.yml`):

**A) Upload the zip as-is (easiest, works from a phone browser)**

1. Create a new GitHub repository.
2. **Add file -> Upload files**, choose `zarvimo-video-editor.zip`, commit to `main`.
3. **Add file -> Create new file**, name it `.github/workflows/android-build.yml`, paste the workflow code, commit. (GitHub does not unzip files by itself - the workflow does it for you.)

**B) Extracted files**

Unzip the archive so the files land at the repo root (`settings.gradle.kts` at `your-repo/settings.gradle.kts`) and push to `main`.

Either way, every push to `main` (or a manual run from the **Actions** tab) will:

1. unzip the project if it was uploaded as a zip,
2. install JDK 17 + the Android SDK,
3. build `app-debug.apk`,
4. publish it as a **GitHub Release** (repo home page -> **Releases** on the right) named `build-<run number>`, and also attach it as a workflow artifact.

The workflow builds the **debug** APK because it is signed with the debug key and installs directly on a phone. The release build type is unsigned, so it would not install.

Locally: `./gradlew assembleDebug` (requires a JDK 17 and the Android SDK/licenses, which `android-actions/setup-android` provides automatically in CI).

### Honesty about what was verified in this environment

This project was built in a sandboxed environment with **no access to Maven
Central, Google's Maven repository, or the Gradle plugin portal** — only a
small package-manager allowlist and GitHub. That means a full
`./gradlew assembleDebug` (which needs to download the Android Gradle Plugin,
Compose, and Media3 artifacts) could not be run or verified end-to-end here.
What *was* verified directly, with the real project files, before packaging:

- **Every Kotlin source file compiles cleanly** against the real Kotlin 2.0.21
  compiler (extracted from a local Gradle install) and the real
  `kotlinx-serialization`/`kotlinx-coroutines` jars used by this project —
  checked file-by-file and in combination for the data, undo/redo,
  repository, and clip-editing logic.
- **The full unit test suite (21 tests) passes** against the real JUnit
  4.13.2 runner and the real source files in `app/src/test/`.
- **Core editing logic was exercised with real assertions**, not just
  compiled: `ProjectRepository` save/load/list/delete round-tripping real
  JSON through a real filesystem; the clip-split algorithm (mid-clip split,
  cross-clip split, edge-margin no-op, total duration preserved); clip
  delete/reorder/trim including re-indexing and bounds-clamping.
- **The Gradle Kotlin DSL files are syntactically valid**: `gradle --offline
  help` against the real project parses `settings.gradle.kts` and
  `build.gradle.kts` successfully and gets as far as plugin *resolution*,
  which is exactly where it's expected to fail without network access (it
  correctly reports it cannot reach Google's Maven repo for the Android
  Gradle Plugin — there is no other error).
- **The GitHub Actions workflow YAML is valid** (parsed with PyYAML) and its
  `on:` triggers are exactly `workflow_dispatch` and `push` to `main`, as
  required.
- **`gradlew`/`gradlew.bat` and `gradle-wrapper.jar` are the genuine Gradle
  8.14.3 wrapper artifacts**, extracted directly from a local Gradle 8.14.3
  installation (not hand-written), so there is no risk of an invalid or
  corrupted wrapper jar.
- Every `R.string.*`, `R.drawable.*`, and intra-project import used in the
  Kotlin source was cross-checked against the actual resource/source files
  and all resolve.

What was **not** verified here, and should be checked on first CI run or
local build with full network access: full dependency resolution and the
actual `assembleDebug`/instrumented build output, since the Android Gradle
Plugin, Jetpack Compose compiler, and Media3 artifacts could not be
downloaded in this sandbox. The provided GitHub Actions workflow is the
intended way to get that full, real build — please check its first run.

## Phase 2 roadmap (architecture already allows for)

- Frame-accurate overlay timing in export (see limitation above).
- Multiple overlapping text/sticker layers, image overlays, transitions.
- Project thumbnails generated from the first frame.
- Waveform display on the timeline.
- Cloud backup / project sharing.
