package com.zarvimo.videoeditor.export

import android.content.Context
import android.graphics.Bitmap
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.TransformationRequest
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import com.zarvimo.videoeditor.data.model.Project
import com.zarvimo.videoeditor.data.model.VideoClip
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed interface ExportState {
    data object Idle : ExportState
    data class InProgress(val progressPercent: Int) : ExportState
    data class Completed(val outputFile: File) : ExportState
    data class Failed(val message: String) : ExportState
}

/**
 * Renders a [Project] to a single H.264/AAC MP4 using Media3 Transformer.
 *
 * - Trim in/out, clip order, and concatenation come from [MediaItem.ClippingConfiguration]
 *   on a single [EditedMediaItemSequence] — Transformer plays the sequence's items back to
 *   back, so an ordered, trimmed clip list *is* the composition.
 * - Per-clip volume is baked in via [VolumeAudioProcessor], a custom [AudioProcessor].
 * - Text overlays are burned in via [OverlayEffect] + a bitmap rendered by [TextOverlayRenderer].
 *   Phase 1 limitation: an overlay is burned in for the full duration of every clip it
 *   overlaps, not frame-accurately clipped to its exact start/end time inside that clip —
 *   see the comment on [buildOverlayEffects].
 */
class VideoExporter(private val context: Context) {

    private val _state = MutableStateFlow<ExportState>(ExportState.Idle)
    val state: StateFlow<ExportState> = _state.asStateFlow()

    private var transformer: Transformer? = null
    private var progressJob: Job? = null

    fun export(project: Project, outputFile: File, scope: CoroutineScope) {
        if (project.clips.isEmpty()) {
            _state.value = ExportState.Failed("Nothing to export: add at least one clip")
            return
        }

        outputFile.parentFile?.mkdirs()
        if (outputFile.exists()) outputFile.delete()

        val sequence = buildSequence(project)
        val composition = Composition.Builder(ImmutableList.of(sequence)).build()

        val transformationRequest = TransformationRequest.Builder()
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .build()

        val builtTransformer = Transformer.Builder(context)
            .setTransformationRequest(transformationRequest)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    stopProgressPolling()
                    transformer = null
                    _state.value = ExportState.Completed(outputFile)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    stopProgressPolling()
                    transformer = null
                    _state.value = ExportState.Failed(exportException.message ?: "Export failed")
                }
            })
            .build()

        transformer = builtTransformer
        _state.value = ExportState.InProgress(0)
        builtTransformer.start(composition, outputFile.absolutePath)
        startProgressPolling(builtTransformer, scope)
    }

    fun cancel() {
        stopProgressPolling()
        transformer?.cancel()
        transformer = null
        _state.value = ExportState.Idle
    }

    private fun startProgressPolling(activeTransformer: Transformer, scope: CoroutineScope) {
        stopProgressPolling()
        progressJob = scope.launch {
            val holder = ProgressHolder()
            while (true) {
                val status = activeTransformer.getProgress(holder)
                when (status) {
                    Transformer.PROGRESS_STATE_AVAILABLE ->
                        _state.value = ExportState.InProgress(holder.progress)
                    Transformer.PROGRESS_STATE_NOT_STARTED -> return@launch
                    else -> Unit
                }
                delay(PROGRESS_POLL_INTERVAL_MS)
            }
        }
    }

    private fun stopProgressPolling() {
        progressJob?.cancel()
        progressJob = null
    }

    private fun buildSequence(project: Project): EditedMediaItemSequence {
        val items = project.orderedClips.map { clip -> buildEditedMediaItem(clip, project) }
        return EditedMediaItemSequence(ImmutableList.copyOf(items))
    }

    private fun buildEditedMediaItem(clip: VideoClip, project: Project): EditedMediaItem {
        val mediaItem = MediaItem.Builder()
            .setUri(clip.sourceUri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionUs(clip.trimStartUs)
                    .setEndPositionUs(clip.trimEndUs)
                    .build()
            )
            .build()

        val audioProcessors: List<AudioProcessor> =
            if (clip.volume != 1f) listOf(VolumeAudioProcessor(clip.volume)) else emptyList()

        val videoEffects: List<Effect> = buildOverlayEffects(clip, project)

        return EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(audioProcessors, videoEffects))
            .build()
    }

    /**
     * Phase 1 limitation, called out here and in the README: overlays are burned
     * in for the entire duration of every clip whose timeline window they
     * overlap, not frame-accurately trimmed to their exact start/end time
     * inside that clip. The live preview (EditorScreen) *does* show overlays
     * at their exact configured time range, since it is just a Compose layer
     * synced to the player's position — only the exported file has this
     * coarser, clip-granularity timing. Phase 2 removes this gap with a
     * time-windowed custom GlShaderProgram instead of a plain bitmap overlay.
     */
    private fun buildOverlayEffects(clip: VideoClip, project: Project): List<Effect> {
        val clipTimelineStart = project.orderedClips
            .takeWhile { it.id != clip.id }
            .sumOf { it.trimmedDurationUs }
        val clipTimelineEnd = clipTimelineStart + clip.trimmedDurationUs

        val overlapping = project.textOverlays.filter { overlay ->
            overlay.startTimeUs < clipTimelineEnd && overlay.endTimeUs > clipTimelineStart
        }
        if (overlapping.isEmpty()) return emptyList()

        val targetHeight = project.exportQuality.targetHeight
        val targetWidth = (targetHeight * project.aspectRatio.ratio).toInt().coerceAtLeast(2)

        val overlays = overlapping.map { overlay ->
            val bitmap = TextOverlayRenderer.render(overlay, targetWidth, targetHeight)
            StaticTextBitmapOverlay(bitmap)
        }
        return listOf(OverlayEffect(ImmutableList.copyOf(overlays)))
    }

    private companion object {
        const val PROGRESS_POLL_INTERVAL_MS = 200L
    }
}

/** Adapts a pre-rendered [Bitmap] (see [TextOverlayRenderer]) to Media3's overlay effect. */
private class StaticTextBitmapOverlay(private val bitmap: Bitmap) : BitmapOverlay() {
    override fun getBitmap(presentationTimeUs: Long): Bitmap = bitmap
    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        OverlaySettings.Builder().build()
}
