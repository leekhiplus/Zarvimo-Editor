package com.zarvimo.videoeditor.playback

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.zarvimo.videoeditor.data.model.Project
import com.zarvimo.videoeditor.data.model.VideoClip
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Wraps a single [ExoPlayer] instance and keeps it in sync with the current
 * project's ordered, trimmed clip list.
 *
 * Each [VideoClip] becomes one [MediaItem] whose
 * [MediaItem.ClippingConfiguration] encodes its trim in/out, so the player's
 * own concatenated playlist *is* the trimmed timeline: scrubbing and playback
 * across clip boundaries are handled by ExoPlayer directly rather than by
 * manually swapping sources.
 */
class PlayerManager(
    context: Context,
    private val scope: CoroutineScope
) {
    val player: ExoPlayer = ExoPlayer.Builder(context.applicationContext).build()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    /** Playhead position in the *timeline's* coordinate space, in microseconds:
     * the sum of preceding clips' trimmed durations plus the offset into the
     * current clip. This is the value the timeline UI should scrub against. */
    private val _positionUs = MutableStateFlow(0L)
    val positionUs: StateFlow<Long> = _positionUs.asStateFlow()

    private val _currentClipIndex = MutableStateFlow(0)
    val currentClipIndex: StateFlow<Int> = _currentClipIndex.asStateFlow()

    private val _playbackError = MutableStateFlow<String?>(null)
    val playbackError: StateFlow<String?> = _playbackError.asStateFlow()

    private var clips: List<VideoClip> = emptyList()
    private var tickerJob: Job? = null

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                if (isPlaying) startTicker() else stopTicker()
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                _currentClipIndex.value = player.currentMediaItemIndex
                applyCurrentClipVolume()
                publishPosition()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                _currentClipIndex.value = player.currentMediaItemIndex
                applyCurrentClipVolume()
            }

            override fun onPlayerError(error: PlaybackException) {
                _playbackError.value = error.message ?: "Playback error"
            }
        })
    }

    /**
     * Rebuilds the ExoPlayer playlist from [project]'s ordered clips. Call this
     * after any edit that changes the clip list, a trim range, or the order.
     * When [preservePosition] is true (the default), Zarvimo tries to keep the
     * playhead on the same clip and offset it was on before the edit.
     */
    fun loadProject(project: Project, preservePosition: Boolean = true) {
        val newClips = project.orderedClips
        val previousClipId = clips.getOrNull(player.currentMediaItemIndex)?.id
        val previousOffsetUs = player.currentPosition * 1000L

        clips = newClips
        player.setMediaItems(newClips.map { it.toMediaItem() })
        player.prepare()

        if (preservePosition && previousClipId != null) {
            val newIndex = newClips.indexOfFirst { it.id == previousClipId }
            if (newIndex >= 0) {
                val clampedUs = previousOffsetUs.coerceIn(0L, newClips[newIndex].trimmedDurationUs)
                player.seekTo(newIndex, clampedUs / 1000L)
            }
        }
        _currentClipIndex.value = player.currentMediaItemIndex
        applyCurrentClipVolume()
        publishPosition()
    }

    /**
     * Mirrors the current clip's volume slider during live preview. ExoPlayer's
     * own [Player.setVolume] only accepts 0f..1f (attenuation, no amplification),
     * so a clip volume above 1f previews at full volume and only actually gets
     * amplified in the exported file, where [com.zarvimo.videoeditor.export.VolumeAudioProcessor]
     * applies the exact factor to the PCM samples.
     */
    private fun applyCurrentClipVolume() {
        val clip = clips.getOrNull(player.currentMediaItemIndex) ?: return
        player.volume = clip.volume.coerceIn(0f, 1f)
    }

    private fun VideoClip.toMediaItem(): MediaItem =
        MediaItem.Builder()
            .setMediaId(id)
            .setUri(sourceUri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionUs(trimStartUs)
                    .setEndPositionUs(trimEndUs)
                    .build()
            )
            .build()

    fun play() = player.play()
    fun pause() = player.pause()
    fun playPause() {
        if (player.isPlaying) player.pause() else player.play()
    }

    /** Seeks to an absolute position on the trimmed timeline, in microseconds. */
    fun seekToTimelineUs(timelineUs: Long) {
        if (clips.isEmpty()) return
        var remaining = timelineUs.coerceAtLeast(0L)
        for ((index, clip) in clips.withIndex()) {
            val duration = clip.trimmedDurationUs
            if (remaining <= duration || index == clips.lastIndex) {
                player.seekTo(index, remaining.coerceIn(0L, duration) / 1000L)
                publishPosition()
                return
            }
            remaining -= duration
        }
    }

    fun timelinePositionUs(): Long {
        var base = 0L
        val idx = player.currentMediaItemIndex
        for (i in 0 until idx) base += clips.getOrNull(i)?.trimmedDurationUs ?: 0L
        return base + player.currentPosition * 1000L
    }

    private fun publishPosition() {
        _positionUs.value = timelinePositionUs()
    }

    private fun startTicker() {
        stopTicker()
        tickerJob = scope.launch {
            while (true) {
                publishPosition()
                delay(TICK_INTERVAL_MS)
            }
        }
    }

    private fun stopTicker() {
        tickerJob?.cancel()
        tickerJob = null
    }

    fun release() {
        stopTicker()
        player.release()
    }

    private companion object {
        /** ~15fps playhead refresh: smooth enough for scrubbing UI without excess recomposition. */
        const val TICK_INTERVAL_MS = 66L
    }
}
