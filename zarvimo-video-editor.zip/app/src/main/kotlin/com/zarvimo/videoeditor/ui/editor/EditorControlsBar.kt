package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.ui.components.NeonIconButton
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoMagenta

/**
 * The editor's main action row: transport + editing tools. A clip-specific
 * group (split/volume/delete) is only enabled when [hasSelectedClip] is true.
 */
@Composable
fun EditorControlsBar(
    isPlaying: Boolean,
    canUndo: Boolean,
    canRedo: Boolean,
    hasSelectedClip: Boolean,
    onPlayPause: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onAddClip: () -> Unit,
    onSplit: () -> Unit,
    onDeleteClip: () -> Unit,
    onVolume: () -> Unit,
    onAddText: () -> Unit,
    onExport: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NeonIconButton(
            icon = Icons.Filled.Undo,
            contentDescription = stringResource(id = R.string.editor_undo),
            onClick = onUndo,
            enabled = canUndo
        )
        Spacer(Modifier.width(6.dp))
        NeonIconButton(
            icon = Icons.Filled.Redo,
            contentDescription = stringResource(id = R.string.editor_redo),
            onClick = onRedo,
            enabled = canRedo
        )

        Spacer(Modifier.weight(1f))

        NeonIconButton(
            icon = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
            contentDescription = stringResource(
                id = if (isPlaying) R.string.editor_pause else R.string.editor_play
            ),
            onClick = onPlayPause,
            tint = ZarvimoElectricBlue,
            size = 52.dp
        )

        Spacer(Modifier.weight(1f))

        NeonIconButton(
            icon = Icons.Filled.ContentCut,
            contentDescription = stringResource(id = R.string.editor_split),
            onClick = onSplit,
            enabled = hasSelectedClip
        )
        Spacer(Modifier.width(6.dp))
        NeonIconButton(
            icon = Icons.Filled.VolumeUp,
            contentDescription = stringResource(id = R.string.editor_volume),
            onClick = onVolume,
            enabled = hasSelectedClip
        )
        Spacer(Modifier.width(6.dp))
        NeonIconButton(
            icon = Icons.Filled.Delete,
            contentDescription = stringResource(id = R.string.editor_delete_clip),
            onClick = onDeleteClip,
            enabled = hasSelectedClip,
            tint = ZarvimoMagenta
        )
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NeonIconButton(
            icon = Icons.Filled.Add,
            contentDescription = stringResource(id = R.string.editor_add_clip),
            onClick = onAddClip
        )
        Spacer(Modifier.width(6.dp))
        NeonIconButton(
            icon = Icons.Filled.TextFields,
            contentDescription = stringResource(id = R.string.editor_add_text),
            onClick = onAddText
        )
        Spacer(Modifier.weight(1f))
        NeonIconButton(
            icon = Icons.Filled.FileDownload,
            contentDescription = stringResource(id = R.string.editor_export),
            onClick = onExport,
            tint = ZarvimoMagenta,
            size = 48.dp
        )
    }
}
