package com.zarvimo.videoeditor.ui.editor

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zarvimo.videoeditor.data.ProjectRepository
import com.zarvimo.videoeditor.data.UndoRedoManager
import com.zarvimo.videoeditor.data.model.ExportQuality
import com.zarvimo.videoeditor.data.model.Project
import com.zarvimo.videoeditor.data.model.TextOverlay
import com.zarvimo.videoeditor.data.model.VideoClip
import com.zarvimo.videoeditor.export.VideoExporter
import com.zarvimo.videoeditor.playback.PlayerManager
import com.zarvimo.videoeditor.util.MediaUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

data class EditorUiState(
    val project: Project? = null,
    val selectedClipId: String? = null,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val isLoading: Boolean = true,
    val isSaving: Boolean = false,
    val lastSavedAtMillis: Long? = null,
    val errorMessage: String? = null
)

/**
 * Owns a single project's editing session: the undo/redo history, the live
 * preview player, and the export pipeline. Every mutating action (add/trim/
 * split/delete/reorder a clip, add/edit an overlay, change volume) funnels
 * through [mutate], which is the one place that pushes undo history and
 * reloads the preview player, so those two things can never drift apart.
 */
class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ProjectRepository(application)
    val playerManager = PlayerManager(application, viewModelScope)
    val exporter = VideoExporter(application)

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    val playbackPositionUs: StateFlow<Long> get() = playerManager.positionUs
    val isPlaying: StateFlow<Boolean> get() = playerManager.isPlaying

    private var undoRedo: UndoRedoManager<Project>? = null

    fun loadProject(projectId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            repository.load(projectId)
                .onSuccess { project ->
                    undoRedo = UndoRedoManager(project)
                    playerManager.loadProject(project, preservePosition = false)
                    _uiState.value = EditorUiState(project = project, isLoading = false)
                }
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = e.message ?: "Could not load project"
                    )
                }
        }
    }

    private fun mutate(mutator: (Project) -> Project) {
        val manager = undoRedo ?: return
        val updated = mutator(manager.current())
        manager.push(updated)
        playerManager.loadProject(updated)
        publishFromManager(manager)
    }

    private fun publishFromManager(manager: UndoRedoManager<Project>) {
        _uiState.value = _uiState.value.copy(
            project = manager.current(),
            canUndo = manager.canUndo,
            canRedo = manager.canRedo
        )
    }

    fun undo() {
        val manager = undoRedo ?: return
        if (!manager.canUndo) return
        manager.undo()
        playerManager.loadProject(manager.current())
        publishFromManager(manager)
    }

    fun redo() {
        val manager = undoRedo ?: return
        if (!manager.canRedo) return
        manager.redo()
        playerManager.loadProject(manager.current())
        publishFromManager(manager)
    }

    fun addClips(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val context = getApplication<Application>()
            val startOrder = undoRedo?.current()?.clips.orEmpty().size
            val newClips = uris.mapIndexed { offset, uri ->
                val duration = MediaUtils.durationUs(context, uri)
                VideoClip(
                    sourceUri = uri.toString(),
                    sourceDurationUs = duration,
                    trimStartUs = 0L,
                    trimEndUs = duration,
                    order = startOrder + offset,
                    displayName = MediaUtils.displayName(context, uri)
                )
            }
            mutate { project -> project.copy(clips = project.clips + newClips) }
        }
    }

    fun selectClip(clipId: String?) {
        _uiState.value = _uiState.value.copy(selectedClipId = clipId)
    }

    fun deleteClip(clipId: String) {
        mutate { project ->
            val remaining = project.clips
                .filterNot { it.id == clipId }
                .sortedBy { it.order }
                .mapIndexed { index, clip -> clip.copy(order = index) }
            project.copy(clips = remaining)
        }
        if (_uiState.value.selectedClipId == clipId) selectClip(null)
    }

    fun reorderClip(fromIndex: Int, toIndex: Int) {
        mutate { project ->
            val ordered = project.orderedClips.toMutableList()
            if (fromIndex !in ordered.indices || toIndex !in ordered.indices) return@mutate project
            val moved = ordered.removeAt(fromIndex)
            ordered.add(toIndex, moved)
            project.copy(clips = ordered.mapIndexed { index, clip -> clip.copy(order = index) })
        }
    }

    fun trimClip(clipId: String, newStartUs: Long, newEndUs: Long) {
        mutate { project ->
            project.copy(
                clips = project.clips.map { clip ->
                    if (clip.id == clipId) clip.withTrim(newStartUs, newEndUs) else clip
                }
            )
        }
    }

    fun setClipVolume(clipId: String, volume: Float) {
        mutate { project ->
            project.copy(
                clips = project.clips.map { clip ->
                    if (clip.id == clipId) clip.copy(volume = volume.coerceIn(0f, 2f)) else clip
                }
            )
        }
    }

    /**
     * Splits whichever clip the playhead currently sits inside into two adjacent
     * clips at that exact position. A no-op if the playhead is within
     * [MIN_SPLIT_MARGIN_US] of either end of its clip, so a split never produces
     * a near-zero-length fragment.
     */
    fun splitAtPlayhead() {
        val project = undoRedo?.current() ?: return
        val timelineUs = playerManager.timelinePositionUs()
        var cursor = 0L
        for (clip in project.orderedClips) {
            val clipEnd = cursor + clip.trimmedDurationUs
            val localOffsetUs = timelineUs - cursor
            val splittable = timelineUs in (cursor + MIN_SPLIT_MARGIN_US) until (clipEnd - MIN_SPLIT_MARGIN_US)
            if (splittable) {
                val splitPointInSource = clip.trimStartUs + localOffsetUs
                mutate { current ->
                    val others = current.clips
                        .filterNot { it.id == clip.id }
                        .map { c -> if (c.order > clip.order) c.copy(order = c.order + 1) else c }
                    val firstHalf = clip.copy(trimEndUs = splitPointInSource, order = clip.order)
                    val secondHalf = clip.copy(
                        id = UUID.randomUUID().toString(),
                        trimStartUs = splitPointInSource,
                        order = clip.order + 1
                    )
                    current.copy(clips = others + firstHalf + secondHalf)
                }
                return
            }
            cursor = clipEnd
        }
    }

    fun addTextOverlay(overlay: TextOverlay) {
        mutate { project -> project.copy(textOverlays = project.textOverlays + overlay) }
    }

    fun updateTextOverlay(overlay: TextOverlay) {
        mutate { project ->
            project.copy(
                textOverlays = project.textOverlays.map { if (it.id == overlay.id) overlay else it }
            )
        }
    }

    fun removeTextOverlay(overlayId: String) {
        mutate { project ->
            project.copy(textOverlays = project.textOverlays.filterNot { it.id == overlayId })
        }
    }

    fun renameProject(name: String) {
        mutate { project -> project.copy(name = name.ifBlank { project.name }) }
    }

    fun save() {
        val project = undoRedo?.current() ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSaving = true)
            repository.save(project)
            _uiState.value = _uiState.value.copy(
                isSaving = false,
                lastSavedAtMillis = System.currentTimeMillis()
            )
        }
    }

    fun exportProject(quality: ExportQuality) {
        if (undoRedo?.current() == null) return
        mutate { project -> project.copy(exportQuality = quality) }
        val project = undoRedo?.current() ?: return
        val safeName = project.name.filter { it.isLetterOrDigit() }.ifBlank { "project" }
        val fileName = "zarvimo_${safeName}_${System.currentTimeMillis()}.mp4"
        val outputFile = File(repository.exportsDir, fileName)
        exporter.export(project, outputFile, viewModelScope)
    }

    fun cancelExport() = exporter.cancel()

    fun consumeError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.release()
    }

    private companion object {
        /** Minimum remaining length either side of a split, in microseconds. */
        const val MIN_SPLIT_MARGIN_US = 100_000L
    }
}
