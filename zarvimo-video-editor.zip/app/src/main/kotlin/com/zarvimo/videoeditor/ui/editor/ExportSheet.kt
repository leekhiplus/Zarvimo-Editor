package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.data.model.ExportQuality
import com.zarvimo.videoeditor.export.ExportState
import com.zarvimo.videoeditor.ui.components.NeonGradientButton
import com.zarvimo.videoeditor.ui.theme.ZarvimoDanger
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoSuccess
import java.io.File

/**
 * Bottom sheet that drives export: pick a quality, start, watch progress, and
 * either share the finished file or dismiss on failure. Mirrors [ExportState]
 * from [com.zarvimo.videoeditor.export.VideoExporter] directly — no separate
 * UI-only state machine to keep in sync with it.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportSheet(
    state: ExportState,
    onStart: (ExportQuality) -> Unit,
    onCancel: () -> Unit,
    onShare: (File) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedQuality by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf(ExportQuality.HD_1080)
    }

    ModalBottomSheet(onDismissRequest = { if (state !is ExportState.InProgress) onDismiss() }) {
        Column(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
            Text(
                text = stringResource(id = R.string.export_title),
                style = MaterialTheme.typography.titleMedium
            )

            when (state) {
                is ExportState.Idle, is ExportState.Failed -> {
                    Text(
                        text = stringResource(id = R.string.export_quality),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
                    )
                    Row {
                        ExportQuality.entries.forEach { quality ->
                            FilterChip(
                                selected = quality == selectedQuality,
                                onClick = { selectedQuality = quality },
                                label = { Text(quality.label) },
                                modifier = Modifier.padding(end = 8.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ZarvimoElectricBlue
                                )
                            )
                        }
                    }
                    if (state is ExportState.Failed) {
                        Text(
                            text = stringResource(id = R.string.export_failed, state.message),
                            color = ZarvimoDanger,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(top = 12.dp)
                        )
                    }
                    NeonGradientButton(
                        text = stringResource(id = R.string.export_start),
                        onClick = { onStart(selectedQuality) },
                        modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
                    )
                }

                is ExportState.InProgress -> {
                    Column(modifier = Modifier.padding(top = 20.dp)) {
                        Text(
                            text = stringResource(id = R.string.export_in_progress, state.progressPercent),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        LinearProgressIndicator(
                            progress = { state.progressPercent / 100f },
                            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                            color = ZarvimoElectricBlue
                        )
                        TextButton(
                            onClick = onCancel,
                            modifier = Modifier.padding(top = 12.dp)
                        ) {
                            Text(stringResource(id = R.string.export_cancel), color = ZarvimoDanger)
                        }
                    }
                }

                is ExportState.Completed -> {
                    Row(
                        modifier = Modifier.padding(top = 20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(id = R.string.export_success),
                            color = ZarvimoSuccess,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    NeonGradientButton(
                        text = stringResource(id = R.string.export_share),
                        onClick = { onShare(state.outputFile) },
                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
                    )
                }
            }
        }
    }
}
