package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.zarvimo.videoeditor.data.model.TextOverlay

/**
 * The video surface: a Media3 [PlayerView] (no built-in transport controls — Zarvimo
 * draws its own in [EditorControlsBar]) with a Compose layer on top that renders
 * whichever [TextOverlay]s are active at [positionUs], at their authored normalized
 * position. This Compose layer is preview-only; the exported file gets its overlays
 * burned in separately by [com.zarvimo.videoeditor.export.VideoExporter].
 */
@OptIn(UnstableApi::class)
@Composable
fun PreviewPlayerView(
    player: ExoPlayer,
    overlays: List<TextOverlay>,
    positionUs: Long,
    modifier: Modifier = Modifier,
    onOverlayClick: (TextOverlay) -> Unit = {}
) {
    var frameSize by remember { mutableStateOf(IntSize.Zero) }

    Box(
        modifier = modifier
            .background(Color.Black)
            .onSizeChanged { frameSize = it }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                PlayerView(context).apply {
                    this.player = player
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
            update = { view -> view.player = player }
        )

        if (frameSize.width > 0 && frameSize.height > 0) {
            val density = LocalDensity.current
            overlays.filter { it.isVisibleAt(positionUs) }.forEach { overlay ->
                val xDp = with(density) { (overlay.xFraction * frameSize.width).toDp() }
                val yDp = with(density) { (overlay.yFraction * frameSize.height).toDp() }
                Text(
                    text = overlay.text,
                    color = Color(overlay.colorArgb),
                    fontSize = overlay.fontSizeSp.sp,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(x = xDp, y = yDp)
                        .clickable { onOverlayClick(overlay) }
                )
            }
        }
    }
}
