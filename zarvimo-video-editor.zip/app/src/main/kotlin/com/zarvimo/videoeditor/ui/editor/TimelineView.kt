package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.zarvimo.videoeditor.data.model.VideoClip
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoMagenta
import com.zarvimo.videoeditor.ui.theme.ZarvimoSurfaceVariant
import com.zarvimo.videoeditor.util.TimeFormat
import kotlin.math.roundToInt

/** Visual time scale: how many density-independent pixels represent one second of clip. */
private val PIXELS_PER_SECOND = 56.dp
private val CLIP_HEIGHT = 64.dp
private val TRIM_HANDLE_WIDTH = 16.dp
private val MIN_CLIP_WIDTH = 28.dp

/**
 * The horizontally scrollable clip strip. Tap a clip to select and seek to its
 * start; long-press and drag a clip to reorder it; when a clip is selected,
 * drag its edge handles to trim; a thin playhead line tracks [playheadUs].
 */
@Composable
fun TimelineView(
    clips: List<VideoClip>,
    selectedClipId: String?,
    playheadUs: Long,
    onSelectClip: (String) -> Unit,
    onSeekToClipStart: (String) -> Unit,
    onReorder: (fromIndex: Int, toIndex: Int) -> Unit,
    onTrimChanged: (clipId: String, newStartUs: Long, newEndUs: Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val pxPerUs = with(density) { PIXELS_PER_SECOND.toPx() } / 1_000_000f
    val scrollState = rememberScrollState()

    val ordered = clips.sortedBy { it.order }
    val clipWidthsPx = ordered.map { (it.trimmedDurationUs * pxPerUs).coerceAtLeast(with(density) { MIN_CLIP_WIDTH.toPx() }) }
    val clipStartsPx = clipWidthsPx.runningFold(0f) { acc, w -> acc + w }

    var draggingClipId by remember { mutableStateOf<String?>(null) }
    var dragOffsetX by remember { mutableFloatStateOf(0f) }

    Box(modifier = modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
        ) {
            Box(
                modifier = Modifier
                    .height(CLIP_HEIGHT)
                    .padding(vertical = 4.dp)
            ) {
                ordered.forEachIndexed { index, clip ->
                    val widthDp = with(density) { clipWidthsPx[index].toDp() }
                    val xDp = with(density) { clipStartsPx[index].toDp() }
                    val isDragging = draggingClipId == clip.id
                    val visualOffsetDp = if (isDragging) with(density) { dragOffsetX.toDp() } else 0.dp

                    Box(
                        modifier = Modifier
                            .padding(start = xDp)
                            .width(widthDp)
                            .fillMaxHeight()
                    ) {
                        ClipBlock(
                            clip = clip,
                            widthDp = widthDp,
                            isSelected = clip.id == selectedClipId,
                            visualOffsetX = visualOffsetDp,
                            onTap = {
                                onSelectClip(clip.id)
                                onSeekToClipStart(clip.id)
                            },
                            onDragStart = { draggingClipId = clip.id; dragOffsetX = 0f },
                            onDrag = { delta -> dragOffsetX += delta },
                            onDragEnd = {
                                val finalCenterPx = clipStartsPx[index] + clipWidthsPx[index] / 2f + dragOffsetX
                                val targetIndex = clipStartsPx.indices.minByOrNull { i ->
                                    kotlin.math.abs((clipStartsPx[i] + clipWidthsPx.getOrElse(i) { 0f } / 2f) - finalCenterPx)
                                } ?: index
                                draggingClipId = null
                                dragOffsetX = 0f
                                if (targetIndex != index) onReorder(index, targetIndex)
                            },
                            onTrimStartDrag = { deltaUs ->
                                val newStart = (clip.trimStartUs + deltaUs).coerceIn(0L, clip.trimEndUs - MIN_TRIM_US)
                                onTrimChanged(clip.id, newStart, clip.trimEndUs)
                            },
                            onTrimEndDrag = { deltaUs ->
                                val newEnd = (clip.trimEndUs + deltaUs).coerceIn(clip.trimStartUs + MIN_TRIM_US, clip.sourceDurationUs)
                                onTrimChanged(clip.id, clip.trimStartUs, newEnd)
                            },
                            pxPerUs = pxPerUs
                        )
                    }
                }
            }
        }

        val playheadXDp = with(density) { (playheadUs * pxPerUs - scrollState.value).toDp() }
        if (playheadXDp >= 0.dp) {
            Box(
                modifier = Modifier
                    .padding(start = playheadXDp)
                    .width(2.dp)
                    .fillMaxHeight()
                    .background(ZarvimoMagenta)
            )
        }
    }
}

@Composable
private fun ClipBlock(
    clip: VideoClip,
    widthDp: Dp,
    isSelected: Boolean,
    visualOffsetX: Dp,
    onTap: () -> Unit,
    onDragStart: () -> Unit,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit,
    onTrimStartDrag: (Long) -> Unit,
    onTrimEndDrag: (Long) -> Unit,
    pxPerUs: Float
) {
    Box(
        modifier = Modifier
            .fillMaxHeight()
            .width(widthDp)
            .offset(x = visualOffsetX)
            .padding(horizontal = 1.dp)
            .shadow(if (isSelected) 6.dp else 0.dp, RoundedCornerShape(8.dp))
            .clip(RoundedCornerShape(8.dp))
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) ZarvimoElectricBlue else ZarvimoSurfaceVariant,
                shape = RoundedCornerShape(8.dp)
            )
            .background(Color.Black)
            .pointerInput(clip.id) {
                detectTapGestures(onTap = { onTap() })
            }
            .pointerInput(clip.id) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { onDragStart() },
                    onDrag = { change, dragAmount -> change.consume(); onDrag(dragAmount.x) },
                    onDragEnd = { onDragEnd() },
                    onDragCancel = { onDragEnd() }
                )
            }
    ) {
        AsyncImage(
            model = clip.sourceUri,
            contentDescription = clip.displayName,
            modifier = Modifier.fillMaxHeight().fillMaxWidth(),
            contentScale = androidx.compose.ui.layout.ContentScale.Crop
        )
        Text(
            text = TimeFormat.formatUs(clip.trimmedDurationUs),
            color = Color.White,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier
                .align(androidx.compose.ui.Alignment.BottomStart)
                .padding(2.dp)
        )

        if (isSelected) {
            TrimHandle(
                alignment = androidx.compose.ui.Alignment.CenterStart,
                pxPerUs = pxPerUs,
                onCommitDeltaUs = onTrimStartDrag
            )
            TrimHandle(
                alignment = androidx.compose.ui.Alignment.CenterEnd,
                pxPerUs = pxPerUs,
                onCommitDeltaUs = onTrimEndDrag
            )
        }
    }
}

/**
 * A trim handle commits its change once, on release, rather than on every drag
 * frame: committing per-pixel would flood undo history and rebuild the preview
 * playlist dozens of times a second. The handle itself still tracks the finger
 * in real time ([offsetPx]) so the drag feels responsive even though the clip
 * block's width only updates once the parent's state is reloaded after release.
 */
@Composable
private fun TrimHandle(
    alignment: androidx.compose.ui.Alignment,
    pxPerUs: Float,
    onCommitDeltaUs: (Long) -> Unit
) {
    var offsetPx by remember { mutableFloatStateOf(0f) }
    val density = LocalDensity.current

    Box(
        modifier = Modifier
            .align(alignment)
            .fillMaxHeight()
            .width(TRIM_HANDLE_WIDTH)
            .offset(x = with(density) { offsetPx.toDp() })
            .background(ZarvimoElectricBlue.copy(alpha = 0.85f))
            .pointerInput(Unit) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { offsetPx = 0f },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        offsetPx += dragAmount.x
                    },
                    onDragEnd = {
                        val deltaUs = (offsetPx / pxPerUs).roundToInt().toLong()
                        offsetPx = 0f
                        if (deltaUs != 0L) onCommitDeltaUs(deltaUs)
                    },
                    onDragCancel = { offsetPx = 0f }
                )
            }
    )
}

private const val MIN_TRIM_US = 200_000L // 0.2s minimum clip length while trimming
